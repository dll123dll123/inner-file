# 技术服务需求记录规范

每条记录只描述一个与客户采购的网络安全技术服务直接相关的要求，目的是让后续专业设计和写作准确理解客户需要什么，而不是形成投标响应清单。

- requirement_id：稳定编号，如 R-001。
- requirement_type：explicit_requirement、technical_context 或 implementation_constraint。
- service_id / service_name：所属采购服务；无法归属时允许为空，但需说明原因。
- original_text：精确原文摘录，不跨越无关段落。
- normalized_requirement：忠实于原文的简明表达。
- conditions：对象、范围、数量、频率、时间、条件、例外和交付要求。
- source_ref：来源文件、页码、章节/条款、表格位置。
- related_scoring_ids：直接相关的技术服务方案评分编号；无关联时为空。
- notes：必要解释、专业建议或假设，并明确标记其性质。

不记录人员姓名、学历、证书、工作年限、个人业绩、社保、人员匹配结果、企业资质、企业业绩、报价、付款、保证金、合同违约责任、投标有效期和递交程序。

不设置 response_priority、writing_depth、response_form、chapter_id 或 chapter_mapping 等优先级或目录规划字段。混合条款只摘录直接影响技术服务的部分。

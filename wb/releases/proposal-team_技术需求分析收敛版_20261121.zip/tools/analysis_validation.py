from __future__ import annotations
import json
from pathlib import Path
from typing import Any

def _load_json(path: Path, errors: list[str]) -> dict[str, Any] | None:
    try:
        data=json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data,dict): errors.append(f"{path.name}: root must be a JSON object"); return None
        return data
    except Exception as exc:
        errors.append(f"{path.name}: invalid/unreadable JSON: {exc}"); return None

def validate_project_identity(path: Path, errors: list[str], warnings: list[str]) -> dict | None:
    data=_load_json(path,errors)
    if data is None:return None
    if not str(data.get("workspace_id","")).strip():errors.append("project_identity: workspace_id must be non-empty")
    if not str(data.get("document_version","")).strip():errors.append("project_identity: document_version must be non-empty")
    seen=set()
    for i,f in enumerate(data.get("fields",[])):
        k=f.get("field_key")
        if not k:errors.append(f"project_identity.fields[{i}]: field_key is required")
        elif k in seen:errors.append(f"project_identity: duplicate field_key {k}")
        seen.add(k);st=f.get("status");locked=f.get("locked")
        if st not in {"confirmed","conflict","unclear","not_found"}:errors.append(f"project_identity.{k}: invalid status {st!r}");continue
        if st=="confirmed":
            if locked is not True:errors.append(f"project_identity.{k}: confirmed field must be locked=true")
            for req in ("verbatim_value","source_file","source_location"):
                if f.get(req) in (None,""):errors.append(f"project_identity.{k}: confirmed field missing {req}")
        else:
            if locked is not False:errors.append(f"project_identity.{k}: {st} field must be locked=false")
            if st=="not_found" and any(f.get(x) not in (None,"") for x in ("verbatim_value","normalized_value")):warnings.append(f"project_identity.{k}: not_found field contains a value; verify provenance")
    return data

def validate_project_markdown_identity(project_dir: Path,identity: dict|None,errors:list[str],warnings:list[str])->None:
    md=project_dir/"00_control"/"PROJECT.md"
    if not md.exists():return
    text=md.read_text(encoding="utf-8");labels={"tender_project_code":"招标项目编号（原文锁定）","tender_project_name":"招标项目名称（原文锁定）","workspace_id":"内部 workspace_id","document_version":"文档版本"};vals={}
    for line in text.splitlines():
        st=line.strip()
        for k,label in labels.items():
            p=f"- {label}："
            if st.startswith(p):vals[k]=st[len(p):].strip()
    if identity is None:warnings.append("PROJECT.md exists but canonical project_identity.json could not be loaded");return
    if vals.get("workspace_id") and vals["workspace_id"]!=identity.get("workspace_id"):errors.append("PROJECT.md internal workspace_id differs from project_identity.json")
    if vals.get("document_version") and vals["document_version"]!=identity.get("document_version"):errors.append("PROJECT.md document_version differs from project_identity.json")
    for f in identity.get("fields",[]):
        k=f.get("field_key");label=labels.get(k)
        if not label:continue
        shown=vals.get(k,"");st=f.get("status");canonical=str(f.get("verbatim_value") or "").strip()
        if st=="confirmed" and (not shown or shown!=canonical):errors.append(f"PROJECT.md {label} differs from confirmed project_identity.json value")
        elif st in {"not_found","unclear","conflict"} and shown and shown not in {"待从招标原文提取","待确认","存在冲突","未找到"}:errors.append(f"PROJECT.md {label} contains a value while canonical project_identity.json status is {st}")

def _unique(items:list,key:str,label:str,errors:list[str])->set[str]:
    vals=[]
    for i,x in enumerate(items):
        if not isinstance(x,dict):errors.append(f"{label}[{i}] must be an object");continue
        v=x.get(key)
        if not isinstance(v,str) or not v.strip():errors.append(f"{label}[{i}].{key} must be non-empty")
        else:vals.append(v)
    if len(vals)!=len(set(vals)):errors.append(f"{label}: duplicate {key}")
    return set(vals)

def _source_ref(ref:Any,label:str,source_ids:set[str],errors:list[str])->None:
    if not isinstance(ref,dict):errors.append(f"{label}.source_ref must be an object");return
    if not str(ref.get("file","")).strip() or not str(ref.get("location","")).strip():errors.append(f"{label}.source_ref requires file and location")
    sid=ref.get("source_id")
    if sid and sid not in source_ids:errors.append(f"{label}.source_ref references unknown source_id {sid}")

def validate_analysis_baseline(project_dir:Path,errors:list[str],warnings:list[str])->dict|None:
    folder=project_dir/"02_requirements";path=folder/"analysis_baseline.json";md=folder/"technical_analysis.md"
    if not path.exists():errors.append("analysis_baseline.json is missing");return None
    data=_load_json(path,errors)
    if data is None:return None
    if data.get("schema_version")!="2.0":errors.append("schema_version must be 2.0")
    if data.get("analysis_scope")!="technical_service_only":errors.append("analysis_scope must be technical_service_only")
    if data.get("scoring_scope")!="technical_service_solution_only":errors.append("scoring_scope must be technical_service_solution_only")
    for k in ("services","requirements","scoring_items","implementation_constraints","design_notes","source_manifest"):
        if not isinstance(data.get(k),list):errors.append(f"{k} must be an array");data[k]=[]
    ctx=data.get("project_context")
    if not isinstance(ctx,dict):errors.append("project_context must be an object")
    else:
        if not isinstance(ctx.get("background"),str):errors.append("project_context.background must be a string")
        if not isinstance(ctx.get("project_objectives"),list):errors.append("project_context.project_objectives must be an array")
    services=data["services"];reqs=data["requirements"];scores=data["scoring_items"];constraints=data["implementation_constraints"];notes=data["design_notes"];manifest=data["source_manifest"]
    service_ids=_unique(services,"service_id","services",errors);req_ids=_unique(reqs,"requirement_id","requirements",errors);score_ids=_unique(scores,"scoring_id","scoring_items",errors);source_ids=_unique(manifest,"source_id","source_manifest",errors)
    _unique(constraints,"constraint_id","implementation_constraints",errors);_unique(notes,"note_id","design_notes",errors)
    for i,x in enumerate(manifest):
        if not isinstance(x,dict):continue
        if not str(x.get("file","")).strip():errors.append(f"source_manifest[{i}].file is empty")
        if x.get("parse_status") not in {"complete","partial","failed","not_applicable"}:errors.append(f"source_manifest[{i}].parse_status is invalid")
        if not isinstance(x.get("technical_sections_reviewed"),list):errors.append(f"source_manifest[{i}].technical_sections_reviewed must be an array")
        if x.get("parse_status") in {"partial","failed"}:warnings.append(f"technical source {x.get('file',x.get('source_id'))} was not fully parsed")
    for i,x in enumerate(services):
        if not isinstance(x,dict):continue
        if not str(x.get("service_name","")).strip():errors.append(f"services[{i}].service_name is empty")
        for r in x.get("source_refs",[]):_source_ref(r,f"services[{i}]",source_ids,errors)
    for i,x in enumerate(reqs):
        if not isinstance(x,dict):continue
        if x.get("requirement_type") not in {"explicit_requirement","technical_context","implementation_constraint"}:errors.append(f"requirements[{i}].requirement_type is invalid")
        if not str(x.get("original_text","")).strip() or not str(x.get("normalized_requirement","")).strip():errors.append(f"requirements[{i}] requires original_text and normalized_requirement")
        sid=x.get("service_id")
        if sid and sid not in service_ids:errors.append(f"requirements[{i}] references unknown service_id {sid}")
        _source_ref(x.get("source_ref"),f"requirements[{i}]",source_ids,errors)
        for score in x.get("related_scoring_ids",[]):
            if score not in score_ids:errors.append(f"requirements[{i}] references unknown scoring_id {score}")
    for i,x in enumerate(scores):
        if not isinstance(x,dict):continue
        if x.get("kind") not in {"scored","descriptive_tier","ranking_only"}:errors.append(f"scoring_items[{i}].kind is invalid")
        if x.get("counts_toward_total") is True and x.get("kind")!="scored":errors.append(f"scoring_items[{i}] non-scored item cannot count toward total")
        if x.get("counts_toward_total") is True and not isinstance(x.get("max_score"),(int,float)):errors.append(f"scoring_items[{i}].max_score must be numeric")
        if x.get("parent_scoring_id") and x["parent_scoring_id"] not in score_ids:errors.append(f"scoring_items[{i}] references unknown parent_scoring_id")
        _source_ref(x.get("source_ref"),f"scoring_items[{i}]",source_ids,errors)
        for rid in x.get("related_requirement_ids",[]):
            if rid not in req_ids:errors.append(f"scoring_items[{i}] references unknown requirement_id {rid}")
    for i,x in enumerate(constraints):
        if not isinstance(x,dict):continue
        _source_ref(x.get("source_ref"),f"implementation_constraints[{i}]",source_ids,errors)
        for sid in x.get("affected_service_ids",[]):
            if sid not in service_ids:errors.append(f"implementation_constraints[{i}] references unknown service_id {sid}")
    for i,x in enumerate(notes):
        if not isinstance(x,dict):continue
        if x.get("note_type") not in {"professional_suggestion","assumption","user_confirmation"}:errors.append(f"design_notes[{i}].note_type is invalid")
        for sid in x.get("affected_service_ids",[]):
            if sid not in service_ids:errors.append(f"design_notes[{i}] references unknown service_id {sid}")
    if not md.exists():errors.append("technical_analysis.md is missing")
    elif not md.read_text(encoding="utf-8").strip():errors.append("technical_analysis.md is empty")
    summary=data.get("validation_summary")
    if not isinstance(summary,dict):errors.append("validation_summary must be an object")
    else:
        for k in ("technical_scope_review","source_traceability","markdown_consistency"):
            v=summary.get(k)
            if v not in {"pass","warning","fail"}:errors.append(f"validation_summary.{k} is invalid")
            elif v=="fail":errors.append(f"validation_summary.{k} is fail")
            elif v=="warning":warnings.append(f"validation_summary.{k} requires review")
        if not isinstance(summary.get("warnings"),list):errors.append("validation_summary.warnings must be an array")
        else:warnings.extend(str(v) for v in summary["warnings"])
    ref=data.get("project_identity_ref")
    if ref:
        p=Path(ref)
        if not p.is_absolute():p=project_dir/p
        if not p.exists():warnings.append(f"project_identity_ref does not resolve: {ref}")
        else:
            ctrl=project_dir/"00_control"/"project_identity.json"
            if ctrl.exists():
                a=_load_json(ctrl,errors);b=_load_json(p,errors)
                if a is not None and b is not None and a.get("workspace_id")!=b.get("workspace_id"):errors.append("project identity snapshot workspace_id differs from 00_control source")
    return data

def validate_project(project_dir:Path)->tuple[list[str],list[str]]:
    errors=[];warnings=[];identity_path=project_dir/"00_control"/"project_identity.json";identity=None
    if identity_path.exists():identity=validate_project_identity(identity_path,errors,warnings)
    else:warnings.append("00_control/project_identity.json not present")
    validate_project_markdown_identity(project_dir,identity,errors,warnings)
    validate_analysis_baseline(project_dir,errors,warnings)
    return errors,warnings

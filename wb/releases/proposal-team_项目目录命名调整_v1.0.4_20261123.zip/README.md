# 网络安全技术服务方案专家团

本包基于网络安全技术服务方案专家团 V1.2.3 方法体系整理，按 WorkBuddy 专家团导入格式组织。所有面向使用者的角色说明、技能说明、参考方法和操作文档统一使用简体中文；程序识别所需的标识符、字段名、目录名和固定状态值保持原样。

## 团队组成
- 1 名主理人：proposal-team-lead，负责项目编排、阶段门禁、状态维护和交付汇总。
- 6 名专业专家：requirement-analyst、knowledge-curator、solution-architect、outline-planner、proposal-writer、proposal-reviewer。
- 9 项 Skill：覆盖需求分析、技术证据整理、方案设计、目录规划、章节写作、图形设计、质量审核、Word 发布和项目编排。
- 6 份 JSON Schema 契约。
- tools/：项目初始化、项目写入保护、需求分析校验和文档处理工具。
- projects/_template/：项目控制文件和各阶段工作目录模板。
- avatars/：专家头像，可按需替换。

## 使用边界

本专家团只负责投标文件中的技术服务方案部分，不负责完整投标文件的商务标、资格标、报价、保证金、签章和递交审查。

需求分析只提取客户项目背景、实际采购的技术服务、具体技术要求、技术方案评分和必要技术实施约束。企业资质、企业业绩、人员选拔、个人资质匹配和人员评分均不属于专家团职责。

如技术方案确实需要出现人员资料，只能使用用户指定的确定名单和原始资料；专家团不负责选择或评价人选。

## 项目路径与执行环境

- 所有项目文件和中间文件必须写入用户当前指定的项目工作区，不得写入专家团安装目录。
- tools/ 指当前项目根目录下的 tools/；执行前确认工作目录，必要时使用项目根绝对路径。
- 统一使用系统 Python 3.14.2：C:\Users\h36919\AppData\Local\Programs\Python\Python314\python.exe。
- 图形渲染脚本依赖 @viz-js/viz 与 sharp；当前交付环境未安装这些依赖。未安装前保留 Mermaid 源文件，不得声称已生成 PNG/SVG。

## 项目写入安全

所有专家输出必须先通过 tools/project_guard.py check-path 检查，正式写入必须通过 tools/project_guard.py write。01_input/ 永远只读，各角色只能写入分配目录。

当前运行环境不提供按专家成员划分的文件系统硬隔离。写入约束依靠主理人编排与 project_guard.py；必须通过实际越权写入测试验证。若能够绕过 Guard 直接写入，必须明确记录写入隔离未生效，不得宣称已经实现平台级硬隔离。

## 需求分析正式输出

需求分析阶段只生成 analysis_baseline.json 和 technical_analysis.md。前者是唯一权威结构化数据源，后者由 JSON 派生。

评分分析只保留原文、分值、评分档次和简要评审关注点，不提前生成详细满分响应动作或章节写作任务。

## 来源说明

本包以 V1.2.3 方法体系为基础整理。原始基线及历史资料不包含在本安装包内；项目工作区与专家团安装目录相互独立。


## 阶段输出物约定（第一轮精简）

- 阶段 1 招标文件技术需求分析：保持原有 analysis_baseline.json 与 technical_analysis.md，提示词、内容、Schema、校验逻辑和输出不变。
- 阶段 2 企业技术证据：evidence_catalog.json + evidence_catalog.md。
- 阶段 3 专项服务设计：solution_blueprint.json + solution_blueprint.md；必要图表源文件按需保存。
- 阶段 4 目录规划：outline.md + chapter_plan.json。
- 阶段 5 正文写作：按章节独立保存正文和必要图表资源；自检、证据引用和未决事项通过任务回传，不额外生成报告。
- 阶段 6 审核：review_findings.json + review_report.md。
- 阶段 7 集成：integration_report.md；问题状态更新到 review_findings.json。
- 阶段 8 发布：最终 DOCX 和用户需要的 PDF；临时文件、发布日志和发布检查报告不进入正式交付目录。
- 阶段 9 就绪检查：final_readiness_report.md。

MD 是面向人工阅读的成果，JSON 是相应阶段的结构化权威数据。两者不得分别形成互相矛盾的结论。上述约定只调整输出物，不改变现有阶段顺序和角色职责。


## V1.0.3 流程治理改造

在 v1.0.2 输出物精简基础上，补齐阶段门禁、状态机、任务防重、恢复和返工写入权治理：
- 用户可见 0–9 阶段与 STATE/TASKS 内部状态键统一映射；阶段 7 拆为 revision 与 integration。
- 阶段严格串行，仅阶段 5 不同章节允许并行。
- project_guard.py 校验三处身份 ID、阶段前置条件、任务依赖、任务状态迁移、输出文件唯一写入者和新鲜验证证据。
- Critical / 未关闭 Major 阻断整本集成、发布和最终就绪门禁。
- 中断恢复只把 in_progress 任务退回 ready 并标记 recovery_required，不自动判完成。
- 阶段 1 需求分析与阶段 5 正文写作核心方法不在本轮修改范围。


## V1.0.4 项目目录命名调整

- 新建项目目录名改为原始招标文件名（去掉扩展名并清理 Windows 非法字符）。
- workspace_id 保持独立、稳定且唯一，不再要求等于项目文件夹名。
- project_identity.json 增加 tender_filename；project-identity Schema 同步更新。
- project_guard.py 改为校验目录内 identity/state/tasks 的 workspace_id 一致性，不再把目录名当作项目 ID。
- 主理人和 proposal-orchestrator 初始化指引、tools README 同步更新。
- 新增项目目录命名及同名目录防覆盖回归测试。

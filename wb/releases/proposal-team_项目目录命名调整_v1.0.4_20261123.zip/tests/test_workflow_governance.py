import importlib.util
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

MODULE = Path(__file__).resolve().parents[1] / "tools" / "project_guard.py"
SPEC = importlib.util.spec_from_file_location("project_guard_under_test", MODULE)
guard = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(guard)


class WorkflowGovernanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        (self.root / "projects").mkdir()
        self.project = self.root / "projects" / "PRJ-TEST"
        (self.project / "00_control").mkdir(parents=True)
        (self.project / "02_requirements").mkdir()
        (self.project / "07_reviews").mkdir()
        self.project_id = "PRJ-TEST"
        (self.project / "00_control" / "project_identity.json").write_text(
            json.dumps({"workspace_id": self.project_id}), encoding="utf-8")
        self.state = {
            "project_id": self.project_id, "current_phase": "intake",
            "overall_status": "in_progress",
            "phase_status": {k: "pending" for k in guard.PHASES},
            "blocked_tasks": [], "approved_decision_refs": []
        }
        self.tasks = {"project_id": self.project_id, "tasks": []}
        self.save_state()
        self.save_tasks()
        guard.REPO_ROOT = self.root

    def tearDown(self):
        self.tmp.cleanup()

    def save_state(self):
        (self.project / "00_control" / "STATE.json").write_text(
            json.dumps(self.state), encoding="utf-8")

    def save_tasks(self):
        (self.project / "00_control" / "TASKS.json").write_text(
            json.dumps(self.tasks), encoding="utf-8")

    def phase(self, phase, status, output=None, validation="test evidence"):
        args = SimpleNamespace(project_dir=str(self.project),
            expected_project_id=self.project_id, phase=phase, status=status,
            output=[output] if output else None, validation=validation, task_id=None)
        return guard.cmd_phase(args)

    def test_phase_prerequisite_blocks_skipping(self):
        with self.assertRaises(ValueError):
            self.phase("requirements", "in_progress")

    def test_phase_must_start_before_completion(self):
        self.state["phase_status"]["intake"] = "completed"
        self.save_state()
        with self.assertRaises(ValueError):
            self.phase("requirements", "completed", "02_requirements/technical_analysis.md")

    def test_duplicate_task_id_is_rejected(self):
        self.state["phase_status"]["requirements"] = "in_progress"
        self.save_state()
        task = {"task_id":"T1","phase":"requirements","title":"test",
            "agent_role":"requirement_analyst","status":"ready","inputs":[],
            "outputs":["02_requirements/test.md"],"dependencies":[],
            "acceptance_criteria":["exists"]}
        args = SimpleNamespace(project_dir=str(self.project),
            expected_project_id=self.project_id, task_json=json.dumps(task))
        guard.cmd_task_upsert(args)
        with self.assertRaises(ValueError):
            guard.cmd_task_upsert(args)

    def test_critical_or_open_major_blocks_integration_gate(self):
        (self.project / "07_reviews" / "review_findings.json").write_text(
            json.dumps({"findings":[{"finding_id":"F1","severity":"Major","status":"open"}]}),
            encoding="utf-8")
        with self.assertRaises(ValueError):
            guard.review_gate(self.project)

    def test_recovery_requires_new_validation(self):
        self.state["phase_status"]["requirements"] = "in_progress"
        self.save_state()
        task = {"task_id":"T2","phase":"requirements","title":"test",
            "agent_role":"requirement_analyst","status":"in_progress","inputs":[],
            "outputs":["02_requirements/test.md"],"dependencies":[],
            "acceptance_criteria":["exists"],"validation":["old validation"]}
        self.tasks["tasks"].append(task); self.save_tasks()
        args = SimpleNamespace(project_dir=str(self.project),
            expected_project_id=self.project_id)
        guard.cmd_recover(args)
        self.save_tasks()
        recovered = self.tasks["tasks"][0]
        self.assertEqual(recovered["status"], "ready")
        self.assertTrue(recovered["recovery_required"])
        self.assertEqual(recovered["validation"], ["old validation"])


if __name__ == "__main__":
    unittest.main()

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import init_project
import project_guard


class ProjectFolderNamingTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)
        self.projects = self.root / "projects"
        self.template = self.projects / "_template"
        (self.template / "00_control").mkdir(parents=True)
        (self.template / "00_control" / "STATE.json").write_text(json.dumps({"phase_status": {}, "project_id": "PLACEHOLDER"}), encoding="utf-8")
        (self.template / "00_control" / "TASKS.json").write_text(json.dumps({"project_id": "PLACEHOLDER", "tasks": []}), encoding="utf-8")
        (self.template / "00_control" / "project_identity.json").write_text(json.dumps({"schema_version": "1.2.2", "workspace_id": "PLACEHOLDER", "document_version": "V1.0", "fields": []}), encoding="utf-8")
        (self.template / "00_control" / "PROJECT.md").write_text("- 招标项目编号（原文锁定）：\n- 招标项目名称（原文锁定）：\n- 内部 workspace_id：\n- 文档版本：\n- 原始招标文件：\n- 项目工作区目录：\n", encoding="utf-8")
        self.tender = self.root / "2026年 网络安全服务项目（公开招标）.docx"
        self.tender.write_bytes(b"test")
        self.old_root, self.old_template = init_project.ROOT, init_project.TEMPLATE
        self.old_guard_root = project_guard.REPO_ROOT
        init_project.ROOT, init_project.TEMPLATE = self.root, self.template
        project_guard.REPO_ROOT = self.root

    def tearDown(self):
        init_project.ROOT, init_project.TEMPLATE = self.old_root, self.old_template
        project_guard.REPO_ROOT = self.old_guard_root
        self.tmp.cleanup()

    def test_folder_uses_tender_filename_and_guard_uses_stable_id(self):
        with patch.object(sys, "argv", ["init_project.py", "PRJ-2026-001", "--tender-file", str(self.tender), "--name", "正式项目名称"]):
            init_project.main()
        folder = self.projects / "2026年 网络安全服务项目（公开招标）"
        self.assertTrue(folder.is_dir())
        identity = json.loads((folder / "00_control/project_identity.json").read_text(encoding="utf-8"))
        self.assertEqual(identity["workspace_id"], "PRJ-2026-001")
        self.assertEqual(identity["tender_filename"], self.tender.name)
        resolved = project_guard.project_root(folder, "PRJ-2026-001")
        self.assertEqual(resolved.name, folder.name)

    def test_existing_folder_is_not_overwritten(self):
        folder = self.projects / "2026年 网络安全服务项目（公开招标）"
        folder.mkdir()
        with patch.object(sys, "argv", ["init_project.py", "PRJ-2026-001", "--tender-file", str(self.tender)]):
            with self.assertRaises(SystemExit):
                init_project.main()
        self.assertTrue(folder.is_dir())

    def test_windows_reserved_names_are_safened(self):
        self.assertEqual(init_project.tender_folder_name(Path("CON.docx")), "_CON")


if __name__ == "__main__":
    unittest.main()

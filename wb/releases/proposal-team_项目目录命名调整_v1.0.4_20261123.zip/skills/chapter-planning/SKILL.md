---
name: chapter-planning
description: "用于在专项技术服务设计获批后，规划技术服务方案目录、章节结构和章节任务书；当用户要求编制目录、拆分章节或检查需求与章节覆盖关系时使用。"
---

# 执行要求

- 开始任务前，按当前任务范围读取以下参考资料，不得只依赖本文件摘要：chapter-brief-template.md、outline-review.md。
- 正文中的 tools/xxx.py 或 tools/xxx.mjs 均指当前项目根目录下的 tools/。执行前确认工作目录；若不在项目根目录，使用项目根绝对路径。
- 严格遵循本 Skill 的专业方法、输入输出约定、写入边界和验收标准，不得跳过必要验证。

# 目标
根据客户需求理解和已批准的专业服务设计，规划一份逻辑清晰、重点突出、内容充分的**技术服务方案**。目录必须围绕客户采购的服务组织，而不是套用通用项目管理目录或完整投标文件目录。

# 输入
- 唯一需求分析输入：`02_requirements/analysis_baseline.json`（项目背景、采购服务、技术要求、技术方案评分、实施约束及设计备注）。不得依赖旧版多份 CSV/分析报告。
- 已批准的 `04_design/solution_blueprint.md` 及相关服务设计、流程和设计决策
- 用户指定的模板、目录、篇幅或格式要求

不得把旧版 `proposal_content_plan.md` 中的商务文件结构或章节编号直接当作正式目录。

# 目录组织原则

默认从以下逻辑思考，但必须按实际项目调整，不是固定模板：

1. **前部：项目理解与总体思路**——简要说明客户背景、采购目标、需求理解、服务目标和总体服务思路。只保留有助于理解技术方案的内容。
2. **主体：逐项展开客户采购的服务**——每项核心服务应有清晰的方案章节或完整内容单元，依据服务复杂度决定层级。章节内容来自已批准的专业设计，充分呈现技术工作项、方法、流程、场景、实施控制和交付成果。
3. **后部：其他必要支撑内容**——根据项目实际需要组织技术团队与职责、服务实施安排、质量保障、沟通协同、保密安全、交付验收等内容。

不得默认将“项目启动、项目实施、项目管理、项目验收”分别设为主体章节。这些通常是支撑安排，可以放入对应服务章节或后部保障章节。只有招标明确单独采购，或其内容足以构成独立且有实质价值的技术服务时，才单独成章。

不得为了目录整齐强行让每项服务章节数量相同；不得把所有服务压缩为一个笼统章节；也不得将每个通用管理动作拆成独立章节。

# 规划步骤
1. 确认文档定位是技术服务方案，而非完整投标文件。
2. 提取客户采购的各项服务及已批准设计的工作项。
3. 先确定主体服务章节的组织方式，再安排项目理解和支撑内容。
4. 为每章明确唯一目的、范围、排除内容和与其他章节的边界。
5. 将需求和技术评分映射到主要响应章节；评分项不能机械地直接变成目录标题。
6. 将设计蓝图中的具体工作项分配到章节，标明不能遗漏的内容。
7. 识别重复内容、依赖关系和跨章节统一口径。
8. 根据技术内容量规划篇幅，不以压缩为目标，也不得机械凑页数。
9. 生成正式目录、章节任务书和覆盖映射。

# 每章任务书必须包含
- `chapter_id` / `parent_id`
- `title`
- `purpose`
- `scope` / `excluded_content`
- `required_content`：具体到已设计的技术工作项，不得只写“详细介绍服务内容”
- `requirement_ids` / `scoring_ids`
- `design_refs`
- `dependencies`
- `expected_tables` / `expected_diagrams`
- `target_length`：建议值及内容量依据
- `acceptance_criteria`
- `output_path` / `writer_notes`

# 输出与交付

只生成两份正式成果：
1. `05_outline/outline.md`：正式目录、组织理由、章节层级、主要内容安排和必要的覆盖/依赖说明。
2. `05_outline/chapter_plan.json`：唯一权威结构化任务书，供主理人和撰写专家使用。

JSON 根对象至少包含 project_id、source_analysis_ref、solution_blueprint_ref、generated_at、outline、chapters、coverage、dependencies 和 consistency_rules。chapters 逐章沿用 chapter-brief-template.md 字段：chapter_id、parent_id、title、purpose、scope、excluded_content、required_content、requirement_ids、scoring_ids、design_refs、dependencies、expected_tables、expected_diagrams、target_length、acceptance_criteria、output_path 和 writer_notes。所有关联使用稳定 ID；required_content 必须具体到已批准设计中的工作项。

outline.md 清楚展示正式目录、章节目的和主要内容安排，并说明核心需求/评分的主要响应位置及必要章节依赖。该文件由 JSON 派生，不得形成另一套目录或覆盖结论。

不得再生成 coverage_map.csv 或 dependency_map.md；覆盖和依赖信息完整保留在 chapter_plan.json，并在 outline.md 中呈现必要摘要。任务摘要和校验结果通过任务回传，不另建过程报告。

# 验收
- 结构体现“项目理解与总体思路—各项专项服务方案—其他必要支撑内容”的逻辑（如项目实际适用）。
- 主体章节围绕客户采购的具体服务，而非通用项目生命周期。
- 每个核心服务的专业设计工作项均有明确写作位置。
- 每章任务书具体到内容和工作项，撰写专家 无需重新发明方案。
- 评分覆盖完整，证据和技术内容不混淆。
- 没有无价值的独立管理章节、重复章节或无依据扩展。

# 禁止事项
不设计技术方案；不擅自更改已批准设计；不规划企业资质、投标保证金、投标有效期、报价和递交格式等完整投标文件内容；不为凑篇幅创建空泛章节；不把通用项目管理活动凌驾于专项服务内容之上。

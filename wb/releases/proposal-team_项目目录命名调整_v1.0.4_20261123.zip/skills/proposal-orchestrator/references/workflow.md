# 技术服务方案工作流与阶段门槛 V1.0.3

系统只负责投标文件中的技术服务方案部分，不负责完整投标文件的商务、资格、报价、保证金、签章和递交审查。用户可见阶段 0–9；内部状态键将阶段 7 拆为 revision 与 integration。

| 用户阶段 | 内部状态键 | 负责人 | 调度 | 核心门槛 |
|---|---|---|---|---|
| 0 项目初始化 | intake | 主理人 | 单独执行 | 身份/状态/任务文件一致 |
| 1 技术需求分析 | requirements | requirement_analyst | 串行 | validate_analysis.py 无 ERROR；原分析能力保持不变 |
| 2 企业技术证据 | knowledge | knowledge_curator | 串行 | 证据可回指来源，区分已验证与待核验 |
| 3 专项服务设计 | design | solution_architect | 串行 | 各服务均有具体工作项、方法与闭环 |
| 4 正式目录 | outline | outline_planner | 串行 | 目录任务书与批准设计逐项对应 |
| 5 正文写作 | writing | proposal_writer | 仅不同章节并行 | 每章唯一写入者，章节任务书完整 |
| 6 独立审核 | review | proposal_reviewer | 串行只读 | Critical/Major 问题完整记录，不得降级 |
| 7a 定向返工 | revision | 原 writer + 主理人 | 定向执行 | 每个问题有处理状态及复核证据 |
| 7b 整本集成 | integration | 主理人 | revision 之后 | 跨章一致性检查；Critical/未关闭 Major 阻断 |
| 8 文档发布 | publishing | 主理人 + word-publishing | integration 之后 | DOCX/PDF 实际可打开且版式检查通过 |
| 9 交付就绪 | final_gate | 主理人 | publishing 之后 | 技术方案就绪结论可追溯，不声称完整投标包就绪 |

## 全局调度红线
- 除阶段 5 不同章节写作外，所有阶段严格串行；不得并行上下游阶段。
- 专业成员只执行主理人分配的当前任务；不得扩展范围、跳阶段、派发子任务或直接联系其他成员。
- 所有跨成员信息流经主理人；交接包含上游正式成果原文/文件和来源，不以摘要替代。
- 主理人是唯一阶段状态写入者和阶段门禁执行者；成员只回传结果，不自行宣布阶段通过。
- 每次阶段切换前核对 project_identity.json、STATE.json、TASKS.json 和 EXECUTION_AUDIT.jsonl。
- ERROR、输出缺失、校验未执行、任务未完成或输入冲突均阻断阶段完成；not_run 不得当作 passed。

## 阶段 0：项目初始化
锁定唯一 project_dir/project_id；初始化身份、状态、任务文件、PROJECT.md 和输入索引。原始输入只读，三处 ID 必须一致。

## 阶段 1：技术服务需求理解
委派 requirement_analyst。只提取客户背景、实际采购技术服务、明确技术要求、技术方案评分和必要技术实施约束；排除商务、企业资格/业绩、人员选择/个人资质/人员评分及投标程序。保持已调试的 requirement-analysis Skill、Agent 提示词、Schema、校验脚本、输出结构和内容规则原样不动。主理人运行现有 validate_analysis.py；任何 ERROR 阻断。不得在此阶段设计服务、规划最终目录或编写章节。

## 阶段 2：企业技术能力与证据整理
委派 knowledge_curator。只整理与拟提供技术服务相关的已验证能力、工具/产品、技术团队整体能力和技术案例。排除公司资质、商务业绩和具体人员选择/评分。正式成果仅 evidence_catalog.json + 派生 evidence_catalog.md；缺口保留在 JSON，不另建重复台账。

## 阶段 3：专项服务专业设计
委派 solution_architect。基于已验收需求基线和企业证据，逐项设计采购服务的具体工作项、技术方法、对象、步骤、判断依据、数据/权限/工具条件、角色协作、风险控制、输出和验证闭环。先设计专业服务，再补支撑流程。成果仅 solution_blueprint.json + 派生 solution_blueprint.md，必要图表源文件按需保存。

## 阶段 4：正式目录与章节任务规划
委派 outline_planner。只能使用已批准的服务设计蓝图规划目录。每章任务书明确 purpose、scope、required_content、excluded_content、requirement_ids、scoring_ids、design_refs、dependencies、验收标准和唯一 output_path。成果仅 outline.md + chapter_plan.json。

## 阶段 5：技术正文写作
依据批准的 chapter_plan.json 分配章节任务。不同章节可并行，同一章节唯一写入者。每个 writer 只读取本章任务书、相关原文需求、相关设计、证据引用、术语和必要相邻章节上下文。保留 chapter-writing Skill 与 proposal-writer Agent 的写作方法、技术展开要求和内容质量规则，不因流程治理改造而压缩正文。所有章节完成并验收后才能结束阶段。

## 阶段 6：独立技术审核
proposal_reviewer 只读方案正文，独立检查需求/评分覆盖、专业设计落实、技术深度、证据真实性、服务边界、重复、术语和跨章一致性。正式成果为 review_findings.json + 派生 review_report.md。Critical 或 Major 不得降级；无问题也必须有 findings=[] 的审核记录。

## 阶段 7a：定向返工
对每条 Critical/Major/Minor 按需建立返工任务。由原章节写入者负责修改对应章节；返工任务使用新 task_id 并通过 revision_of 关联原写作任务。只修改问题涉及范围和必要关联内容。Critical/Major 更新为 resolved/closed 前必须有 resolution_evidence、recheck_result 或 verification_evidence。未清零前不得通过整本集成门禁。

## 阶段 7b：整本集成验收
主理人检查章节顺序、标题层级、服务边界、范围、流程、术语、团队配置、时间、交付物、图表引用、需求/评分映射和跨章一致性。只生成 integration_report.md；问题状态在 review_findings.json 原位更新。Critical 或未关闭 Major 存在时阻断阶段完成。

## 阶段 8：文档发布
调用 word-publishing Skill，生成最终 DOCX 和用户需要的 PDF。只保留正式交付物；临时文件、发布日志和单独发布检查报告不进入交付目录。主理人实际打开/解析文件，检查目录、标题、表格、图片、页眉页脚、分页和字体。失败则标记 blocked/failed。

## 阶段 9：技术方案交付就绪
主理人核对阶段 1–8 状态、正式输出、审核 finding、集成报告、文档发布验证和未决技术事项，生成 final_readiness_report.md。该结论只覆盖技术服务方案。

## 单步执行与变更重跑
用户要求只分析、只设计、只规划目录或只写指定章节时，只执行对应任务并保存状态，完成后停止。完整流程只有用户明确要求时才继续。
招标澄清/补遗、需求变更或用户修改已批准设计时，主理人建立影响分析任务，定位受影响下游阶段与章节；只重跑受影响分支，不无差别重跑全部阶段。阶段一输入未变化时复用已验收结果，不重复完整分析。

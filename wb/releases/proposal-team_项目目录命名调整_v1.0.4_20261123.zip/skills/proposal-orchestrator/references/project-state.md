# 项目状态文件与阶段机规范

## 唯一事实源
- project_identity.json：项目工作区身份与可追溯招标原文事实。
- STATE.json：当前阶段、阶段状态、总体状态和阻塞信息。
- TASKS.json：任务依赖、唯一写入者、输入输出、验收与执行状态。
- EXECUTION_AUDIT.jsonl：Guard 追加的状态变更、受控写入和恢复审计事件；不得由 Agent 覆盖或删除。

每次任务开始、写入、状态更新前，核对 project_identity.json.workspace_id、STATE.json.project_id、TASKS.json.project_id 与项目目录名完全一致。

## 阶段编号映射
用户可见阶段为 0–9；STATE/TASKS 内部保留可区分阶段 7 两个子步骤的键：

| 用户阶段 | 内部状态键 | 含义 |
|---|---|---|
| 0 | intake | 初始化与材料定位 |
| 1 | requirements | 技术需求分析 |
| 2 | knowledge | 企业技术证据 |
| 3 | design | 专项服务设计 |
| 4 | outline | 目录与章节任务规划 |
| 5 | writing | 章节写作（仅此阶段允许不同章节并行） |
| 6 | review | 独立技术审核 |
| 7a | revision | 按问题定向返工 |
| 7b | integration | 整本一致性集成验收 |
| 8 | publishing | DOCX/PDF 发布 |
| 9 | final_gate | 技术方案交付就绪检查 |

阶段状态：pending、in_progress、blocked、completed、skipped。仅 intake（明确无需初始化）或 revision（无 actionable findings）可按规则 skipped；不得用 skipped 绕过门禁。

## TASKS.json 与状态机
每项任务必须包含 task_id、phase、title、agent_role、status、inputs、outputs、dependencies、acceptance_criteria、validation、owner、created_at、updated_at。返工任务增加 revision_of；恢复任务标记 recovery_required。task_id 全项目唯一、不可复用。
- pending → ready → in_progress → completed / completed_with_warnings。
- 执行中也可进入 blocked 或 failed；blocked/failed 解除后才可回 ready。
- completed/completed_with_warnings 为终态。重试或返工必须新建 task_id。
- 修改既有章节文件时，revision_of 指向原任务，且 agent_role 必须与原写入者相同。
- 任务完成必须有真实输出文件、依赖完成记录和本次新鲜 validation 证据。

## 阶段依赖与门禁
intake → requirements → knowledge → design → outline → writing → review → revision → integration → publishing → final_gate。
阶段 5 内不同章节可并行，但每章文件唯一写入者；其他阶段严格串行。
阶段开始前必须确认前置阶段 completed（revision 可在无 actionable findings 时 skipped），并先将本阶段设为 in_progress。阶段完成前主理人核验本阶段任务均为终态、正式输出真实存在、必要脚本/Schema/内容验收实际运行、未决事项已记录、身份三处 ID 一致。
阶段 1 的 validate_analysis.py 出现任何 ERROR 必须阻断；阶段 6 的 Critical 或未关闭 Major 必须阻断阶段 7b 集成通过、阶段 8 发布和阶段 9 就绪检查。Critical/Major 解除时必须附 resolution_evidence、recheck_result 或 verification_evidence。未关闭 Minor 可记录为警告。

## 状态更新与恢复
只有主理人更新 STATE/TASKS 阶段与任务状态。恢复前读取身份、STATE、TASKS 和审计日志，再运行 project_guard.py recover。recover 只把遗留 in_progress 任务退回 ready 并标记 recovery_required；不会认定完成。恢复任务必须重新检查输出并执行新验证。禁止删除历史任务、复用 task_id、静默覆盖已批准成果或仅凭聊天记录恢复项目状态。
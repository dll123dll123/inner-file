# 专家委派与结果交付协议

## 委派任务必须提供
task_id（全项目唯一）、project_id、phase、agent_role、objective、精确 inputs、constraints、唯一 output_files、dependencies、acceptance_criteria 和 project_dir。输入交接提供必要的上游正式成果原文/文件和来源定位，不以主理人摘要替代原始依据。

## 成员回传必须包含
task_id、project_id、phase、agent_role、status、真实 output_files、summary、evidence_refs、unresolved_issues、validation_results（check/status/details）和 next_actions。成员的 next_actions 不代表其可以自行启动下一阶段。

## 唯一写入者与返工
同一时刻同一正式文件只能有一个写入任务。不同章节可并行；同一章节不得并行。审核成员只读正文，只写 review_findings.json 和 review_report.md。
返工必须由原章节写入者承担，使用新 task_id 并在 revision_of 指向原写作 task_id；禁止换 writer 与原任务并发修改同一文件。

## 防重复与状态迁移
委派前检查 TASKS.json：task_id 不存在、输出文件未被其他任务占用、依赖均已完成。创建后登记 ready；开始执行前改为 in_progress。已完成任务不得重派。重试必须创建新 task_id，不能通过 task-upsert 覆盖旧任务。
成员返回后主理人检查真实文件、路径白名单、验收项和实际校验；只有本次验证完成后才能标记 completed。
缺少输入标记 blocked 并列明解除条件；输入冲突列出冲突证据；失败不允许自动推进。恢复任务必须重新检查输出并提供新验证，不能沿用旧 validation。
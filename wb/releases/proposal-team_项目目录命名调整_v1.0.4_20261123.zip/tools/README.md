# 工具层

本版本包含项目初始化和基础架构校验工具，不包含完整 PDF/DOCX 解析、企业语义检索、图形渲染或 Word 发布引擎。

## validate_scaffold.py
使用 Python 标准库检查关键目录、Agent TOML、Skill frontmatter、JSON 文件和项目模板。
运行：`python tools/validate_scaffold.py`

## init_project.py
从 `projects/_template/` 创建新的项目工作区。目录名取原始招标文件文件名（去掉扩展名、清理非法字符）；内部 workspace_id 独立保存，不要求与目录名相同。必须提供真实存在的 `--tender-file` 路径；同名目录存在时拒绝覆盖。
运行：`python tools/init_project.py PRJ-2026-001 --tender-file "D:\\招标文件\\网络安全服务项目招标文件.docx" --name "招标项目正式名称"`。项目目录使用招标文件文件名（去扩展名），PRJ-2026-001 仅作为内部 workspace_id。

## 后续工具接口规划
- document-extract：解析 PDF/DOCX/XLSX 并保留来源位置；
- knowledge-search：按项目授权范围检索企业资料；
- project-state：校验和更新项目状态、任务状态；
- diagram-render：渲染 Mermaid 或其他可编辑图形源；
- word-publish：按指定 DOCX 模板合并章节和图形。

实现这些工具前，先检查当前环境、依赖和现有代码，避免重复建设。

## validate_analysis.py
校验指定项目的 project_identity.json、analysis_baseline.json 和 technical_analysis.md。读取 contracts/analysis-baseline.schema.json，检查字段类型、必填项、枚举、来源引用、编号关联和评分计分标记，并检查阅读版是否包含采购服务名称。真实计分项必须设置 counts_toward_total=true。新分析阶段不再生成或校验旧版 CSV、服务映射、优先级矩阵和独立分析报告。
运行：`python tools/validate_analysis.py projects/2026年网络安全服务项目招标文件`

## analysis_validation.py
供 `validate_analysis.py` 和自动化测试复用的校验逻辑，不建议直接作为命令运行。

## project_guard.py（V1.2.2）

项目级写入授权与状态持久化工具。所有 Agent 项目输出必须先执行 `check-path`，正式写入必须使用 `write`；主理人通过 `task-upsert`、`task-status`、`phase-status` 更新 TASKS/STATE，任务/阶段完成需要输出文件和验证证据。中断恢复使用 `recover`，遗留 in_progress 任务回到 ready 并要求重新验收。

示例：
```bash
python tools/project_guard.py check-path --project-dir projects/2026年网络安全服务项目招标文件 --expected-project-id PRJ-001 --role proposal_writer --path 06_chapters/C01.md
python tools/project_guard.py write --project-dir projects/PRJ-001 --expected-project-id PRJ-001 --role proposal_writer --path 06_chapters/C01.md --source /tmp/C01.md
python tools/project_guard.py recover --project-dir projects/PRJ-001 --expected-project-id PRJ-001
```

注意：Guard 是项目级授权层；Codex `workspace-write` 沙箱是进程级边界。两者必须同时启用。若运行环境允许绕过 Guard 的任意直接文件写入，不得宣称已经实现硬隔离。


## V1.0.3 阶段门禁与任务防重
project_guard.py 支持 11 个内部阶段键（用户可见 0–9，阶段 7 拆分为 revision/integration）。阶段按依赖顺序推进；阶段完成需要输出文件和本次验证证据；阶段任务未完成会阻断阶段完成。integration/publishing/final_gate 会读取 review_findings.json，Critical 或未关闭 Major 阻断门禁。
TASKS.json 任务必须声明 phase。task_id 不可复用；已存在任务不允许被 task-upsert 覆盖。任务输出路径不可重复占用；章节返工用新 task_id + revision_of，且必须由原 writer 角色执行。恢复会标记 recovery_required，必须提供新的 validation 才能完成。

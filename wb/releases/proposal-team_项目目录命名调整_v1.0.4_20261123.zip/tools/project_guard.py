#!/usr/bin/env python3
"""Project-scoped write guard and durable workflow state manager.

This guard is a mandatory preflight for every agent write. Codex workspace sandbox
must additionally be rooted at this repository; this script does not replace OS sandboxing.
"""
from __future__ import annotations
import argparse, json, os, sys, tempfile
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
ROLE_DIRS = {
    "coordinator": {"00_control", "02_requirements", "07_reviews", "08_delivery"},
    "requirement_analyst": {"02_requirements"},
    "knowledge_curator": {"03_knowledge"},
    "solution_architect": {"04_design"},
    "outline_planner": {"05_outline"},
    "proposal_writer": {"06_chapters"},
    "proposal_reviewer": {"07_reviews"},
    "word_publisher": {"08_delivery"},
}
PHASES = ["intake", "requirements", "knowledge", "design", "outline", "writing", "review", "revision", "integration", "publishing", "final_gate"]
TASK_STATUSES = {"pending", "ready", "in_progress", "blocked", "completed", "completed_with_warnings", "failed"}
PHASE_STATUSES = {"pending", "in_progress", "blocked", "completed", "skipped"}
PHASE_PREREQUISITES = {
    "intake": [], "requirements": ["intake"], "knowledge": ["requirements"],
    "design": ["knowledge"], "outline": ["design"], "writing": ["outline"],
    "review": ["writing"], "revision": ["review"], "integration": ["revision"],
    "publishing": ["integration"], "final_gate": ["publishing"],
}
TERMINAL_TASK_STATUSES = {"completed", "completed_with_warnings"}


def now():
    return datetime.now(timezone.utc).isoformat()


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def append_audit(project: Path, event: str, **details):
    audit = project / "00_control" / "EXECUTION_AUDIT.jsonl"
    audit.parent.mkdir(parents=True, exist_ok=True)
    identity = load_json(project / "00_control/project_identity.json")
    record = {"timestamp": now(), "event": event, "project_id": identity.get("workspace_id"), **details}
    with audit.open("a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
        f.flush(); os.fsync(f.fileno())


def atomic_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
            f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def project_root(project_dir: str, expected_project_id: str) -> Path:
    p = Path(project_dir).expanduser().absolute()
    # Resolve parent chain and reject a symlinked project root.
    if p.is_symlink():
        raise ValueError("project root must not be a symlink")
    resolved = p.resolve(strict=True)
    projects_root = (REPO_ROOT / "projects").resolve(strict=True)
    if resolved.parent != projects_root or resolved.name == "_template":
        raise ValueError(f"project must be a direct child of {projects_root}; got {resolved}")
    for required in ("00_control/STATE.json", "00_control/TASKS.json", "00_control/project_identity.json"):
        if not (resolved / required).is_file():
            raise ValueError(f"not a valid project workspace; missing {required}")
    identity = load_json(resolved / "00_control/project_identity.json")
    state = load_json(resolved / "00_control/STATE.json")
    tasks = load_json(resolved / "00_control/TASKS.json")
    workspace_id = identity.get("workspace_id")
    if workspace_id != expected_project_id:
        raise ValueError(f"selected workspace ID {workspace_id} does not match delegated project_id {expected_project_id}")
    if state.get("project_id") != workspace_id or tasks.get("project_id") != workspace_id:
        raise ValueError("project identity/state/tasks workspace IDs do not match")
    return resolved


def guarded_target(project: Path, role: str, rel: str) -> Path:
    if role not in ROLE_DIRS:
        raise ValueError(f"unknown role: {role}")
    raw = Path(rel)
    if raw.is_absolute() or ".." in raw.parts:
        raise ValueError("absolute paths and parent traversal are forbidden")
    if not raw.parts or raw.parts[0] not in ROLE_DIRS[role]:
        raise ValueError(f"role {role} may write only under: {', '.join(sorted(ROLE_DIRS[role]))}")
    # Reject symlink components, including dangling links, before resolving.
    cur = project
    for part in raw.parts:
        cur = cur / part
        if cur.exists() and cur.is_symlink():
            raise ValueError(f"symlink path component is forbidden: {cur}")
    target = (project / raw).resolve(strict=False)
    if target != project and project not in target.parents:
        raise ValueError("resolved output escapes project root")
    if target.parts[:len(project.parts)] != project.parts:
        raise ValueError("resolved output is outside selected project")
    return target



def existing_project_file(project: Path, rel: str) -> Path:
    raw = Path(rel)
    if raw.is_absolute() or ".." in raw.parts or not raw.parts:
        raise ValueError("phase output must be a project-relative path without parent traversal")
    cur = project
    for part in raw.parts:
        cur = cur / part
        if cur.exists() and cur.is_symlink():
            raise ValueError(f"symlink output path is forbidden: {cur}")
    target = (project / raw).resolve(strict=False)
    if target != project and project not in target.parents:
        raise ValueError("phase output resolves outside project root")
    return target

def cmd_check(args):
    project = project_root(args.project_dir, args.expected_project_id)
    target = guarded_target(project, args.role, args.path)
    print(f"ALLOW project_dir={project} role={args.role} path={target.relative_to(project)}")


def cmd_write(args):
    project = project_root(args.project_dir, args.expected_project_id)
    target = guarded_target(project, args.role, args.path)
    if target.exists() and not args.overwrite:
        raise ValueError("target exists; use --overwrite only when the assigned task authorizes replacement")
    content = Path(args.source).read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    # Re-check after directory creation to catch a newly introduced symlink.
    target = guarded_target(project, args.role, args.path)
    fd, tmp = tempfile.mkstemp(prefix=target.name + ".", suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(content); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, target)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise
    append_audit(project, "guarded_write", role=args.role, path=target.relative_to(project).as_posix(), bytes=len(content))
    print(f"WROTE {target.relative_to(project)} bytes={len(content)}")


def cmd_task_upsert(args):
    project = project_root(args.project_dir, args.expected_project_id)
    path = project / "00_control/TASKS.json"
    data = load_json(path)
    if data.get("project_id") != load_json(project / "00_control/project_identity.json").get("workspace_id"):
        raise ValueError("TASKS.json project_id mismatch")
    try: task = json.loads(args.task_json)
    except json.JSONDecodeError as e: raise ValueError(f"invalid --task-json: {e}")
    required = ["task_id", "phase", "title", "agent_role", "status", "inputs", "outputs", "dependencies", "acceptance_criteria"]
    missing = [k for k in required if k not in task]
    if missing: raise ValueError("task missing fields: " + ", ".join(missing))
    if task["phase"] not in PHASES: raise ValueError("invalid task phase")
    if task["status"] not in {"pending", "ready"}: raise ValueError("new tasks must start as pending or ready")
    state = load_json(project / "00_control/STATE.json")
    if task["status"] == "ready" and state.get("phase_status", {}).get(task["phase"]) != "in_progress":
        raise ValueError(f"phase {task['phase']} must be in_progress before tasks can be made ready")
    tasks = data.setdefault("tasks", [])
    if any(x.get("task_id") == task["task_id"] for x in tasks):
        raise ValueError(f"duplicate task_id is forbidden: {task['task_id']}; create a new task_id for retries")
    existing = {x.get("task_id"): x for x in tasks}
    missing_deps = [dep for dep in task.get("dependencies", []) if dep not in existing]
    if missing_deps: raise ValueError("unknown task dependencies: " + ", ".join(missing_deps))
    if task["status"] == "ready":
        incomplete = [dep for dep in task.get("dependencies", []) if existing[dep].get("status") not in TERMINAL_TASK_STATUSES]
        if incomplete: raise ValueError("dependencies are not complete: " + ", ".join(incomplete))
    for rel in task.get("outputs", []):
        guarded_target(project, task.get("agent_role"), rel)
        owners = [old for old in tasks if rel in old.get("outputs", [])]
        if owners:
            revision_source = task.get("revision_of")
            valid_revision = (
                revision_source in {old.get("task_id") for old in owners}
                and all(old.get("agent_role") == task.get("agent_role") and old.get("status") in (TERMINAL_TASK_STATUSES | {"failed", "blocked"}) for old in owners)
            )
            if not valid_revision:
                raise ValueError(f"output ownership conflict: {rel} already belongs to another task")
    task.setdefault("validation", [])
    task.setdefault("owner", None)
    task.setdefault("recovery_required", False)
    task.setdefault("created_at", now())
    task["updated_at"] = now()
    tasks.append(task)
    atomic_json(path, data)
    append_audit(project, "task_created", task_id=task["task_id"], phase=task["phase"], role=task.get("agent_role"), status=task["status"])
    print(f"TASK_CREATED {task['task_id']} phase={task['phase']} status={task['status']}")


def cmd_task_status(args):
    project = project_root(args.project_dir, args.expected_project_id)
    path = project / "00_control/TASKS.json"; data = load_json(path)
    task = next((x for x in data.get("tasks", []) if x.get("task_id") == args.task_id), None)
    if not task: raise ValueError(f"unknown task_id: {args.task_id}")
    if args.status not in TASK_STATUSES: raise ValueError("invalid task status")
    old_status = task.get("status")
    allowed = {
        "pending": {"ready", "blocked", "failed"},
        "ready": {"in_progress", "blocked", "failed"},
        "in_progress": {"ready", "completed", "completed_with_warnings", "blocked", "failed"},
        "blocked": {"ready", "failed"},
        "failed": {"ready"},
        "completed": set(),
        "completed_with_warnings": set(),
    }
    if args.status != old_status and args.status not in allowed.get(old_status, set()):
        raise ValueError(f"invalid task transition: {old_status} -> {args.status}")
    state = load_json(project / "00_control/STATE.json")
    if args.status == "in_progress" and state.get("phase_status", {}).get(task.get("phase")) != "in_progress":
        raise ValueError(f"task phase {task.get('phase')} is not in_progress")
    if args.status in {"completed", "completed_with_warnings"}:
        if not task.get("outputs") or not args.validation:
            raise ValueError("completion requires declared outputs and fresh validation evidence via --validation")
        for rel in task["outputs"]:
            out = guarded_target(project, task.get("agent_role"), rel)
            if not out.is_file(): raise ValueError(f"completed task output missing: {rel}")
        for dep in task.get("dependencies", []):
            parent = next((x for x in data.get("tasks", []) if x.get("task_id") == dep), None)
            if not parent or parent.get("status") not in TERMINAL_TASK_STATUSES:
                raise ValueError(f"task dependency is not complete: {dep}")
        task["recovery_required"] = False
    task["status"] = args.status; task["updated_at"] = now()
    if args.validation: task.setdefault("validation", []).append(args.validation)
    atomic_json(path, data)
    append_audit(project, "task_status", task_id=args.task_id, previous_status=old_status, status=args.status, validation=args.validation)
    print(f"TASK_UPDATED {args.task_id} status={args.status}")


def review_gate(project: Path):
    review_path = project / "07_reviews/review_findings.json"
    if not review_path.is_file():
        raise ValueError("review_findings.json is missing; cannot pass integration/publishing gate")
    try: report = load_json(review_path)
    except Exception as exc: raise ValueError(f"review_findings.json is invalid: {exc}")
    findings = report.get("findings")
    if not isinstance(findings, list):
        raise ValueError("review_findings.json must contain a findings array")
    unresolved = []
    resolved_states = {"closed", "resolved", "verified", "accepted", "wont_fix"}
    for item in findings:
        severity = str(item.get("severity", "")).strip().lower()
        status = str(item.get("status", "")).strip().lower()
        if severity in {"critical", "major"}:
            if status not in resolved_states:
                unresolved.append(f"{item.get('finding_id', 'unknown')}:{severity}:{status or 'no_status'}")
            elif not (item.get("resolution_evidence") or item.get("recheck_result") or item.get("verification_evidence")):
                unresolved.append(f"{item.get('finding_id', 'unknown')}:{severity}:missing_resolution_evidence")
    if unresolved:
        raise ValueError("Critical or unresolved Major findings block this gate: " + ", ".join(unresolved))


def cmd_phase(args):
    project = project_root(args.project_dir, args.expected_project_id)
    if args.phase not in PHASES: raise ValueError("invalid phase")
    if args.status not in PHASE_STATUSES: raise ValueError("invalid phase status")
    state_path = project / "00_control/STATE.json"; state = load_json(state_path)
    if state.get("project_id") != load_json(project / "00_control/project_identity.json").get("workspace_id"): raise ValueError("STATE.json project_id mismatch")
    phase_map = state.setdefault("phase_status", {})
    incomplete = [x for x in PHASE_PREREQUISITES[args.phase] if phase_map.get(x) not in {"completed", "skipped"}]
    if incomplete:
        raise ValueError(f"phase gate blocked; prerequisites not completed: {', '.join(incomplete)}")
    if args.status == "in_progress" and phase_map.get(args.phase) in {"completed", "skipped"}:
        raise ValueError(f"phase {args.phase} is already terminal; do not rerun without an explicit revision workflow")
    if args.status in {"completed", "skipped"} and phase_map.get(args.phase) != "in_progress":
        raise ValueError(f"phase {args.phase} must be in_progress before it can be completed or skipped")
    if args.status == "completed":
        outputs = [x for x in (args.output or []) if x.strip()]
        if not outputs: raise ValueError("completed phase requires at least one --output")
        if not args.validation: raise ValueError("completed phase requires --validation evidence")
        for rel in outputs:
            out = existing_project_file(project, rel)
            if not out.is_file(): raise ValueError(f"cannot complete phase; output missing: {rel}")
        tasks = load_json(project / "00_control/TASKS.json").get("tasks", [])
        unfinished = [t.get("task_id") for t in tasks if t.get("phase") == args.phase and t.get("status") not in TERMINAL_TASK_STATUSES]
        if unfinished:
            raise ValueError("phase has unfinished tasks: " + ", ".join(unfinished))
        if args.phase in {"integration", "publishing", "final_gate"}:
            review_gate(project)
    if args.status == "skipped":
        if not args.validation:
            raise ValueError("skipped phase requires explicit reason via --validation")
        if args.phase == "revision":
            review_path = project / "07_reviews/review_findings.json"
            if not review_path.is_file():
                raise ValueError("revision can only be skipped after a review report exists")
            findings = load_json(review_path).get("findings", [])
            actionable = any(str(x.get("severity", "")).lower() in {"critical", "major", "minor"} for x in findings)
            if actionable:
                raise ValueError("revision cannot be skipped while actionable findings remain")
        elif args.phase != "intake":
            raise ValueError("only intake (when unnecessary) or revision (when no actionable findings) may be skipped")
    phase_map[args.phase] = args.status
    state["current_phase"] = args.phase
    state["overall_status"] = "blocked" if args.status == "blocked" else ("completed" if args.phase == "final_gate" and args.status == "completed" else "in_progress")
    if args.phase == "final_gate" and args.status == "completed":
        state["current_phase"] = "completed"
    if args.status == "completed":
        state["last_completed_task"] = args.task_id or args.phase
    state["updated_at"] = now()
    atomic_json(state_path, state)
    append_audit(project, "phase_status", phase=args.phase, status=args.status, outputs=args.output or [], validation=args.validation)
    print(f"PHASE_UPDATED {args.phase} status={args.status}")


def cmd_recover(args):
    project = project_root(args.project_dir, args.expected_project_id)
    path = project / "00_control/TASKS.json"; data = load_json(path)
    recovered=[]
    for task in data.get("tasks", []):
        if task.get("status") == "in_progress":
            task["status"] = "ready"
            task["recovery_required"] = True
            task["updated_at"] = now(); recovered.append(task.get("task_id"))
    if recovered:
        atomic_json(path, data)
        append_audit(project, "interrupted_tasks_recovered", task_ids=recovered, requires_fresh_validation=True)
    state_path = project / "00_control/STATE.json"
    state = load_json(state_path)
    active = [t.get("phase") for t in data.get("tasks", []) if t.get("status") == "ready" and t.get("recovery_required")]
    if active:
        phase = active[0]
        state.setdefault("phase_status", {})[phase] = "in_progress"
        state["current_phase"] = phase
        state["overall_status"] = "in_progress"
        state["updated_at"] = now()
        atomic_json(state_path, state)
    print(json.dumps({"project_id": load_json(project / "00_control/project_identity.json").get("workspace_id"), "project_dir": str(project), "recovered_tasks": recovered, "count": len(recovered), "requires_revalidation": bool(recovered)}, ensure_ascii=False))


def main():
    ap=argparse.ArgumentParser(description="Project-scoped write guard and workflow state manager")
    sub=ap.add_subparsers(required=True)
    p=sub.add_parser("check-path"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.add_argument("--role",required=True); p.add_argument("--path",required=True); p.set_defaults(func=cmd_check)
    p=sub.add_parser("write"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.add_argument("--role",required=True); p.add_argument("--path",required=True); p.add_argument("--source",required=True); p.add_argument("--overwrite",action="store_true"); p.set_defaults(func=cmd_write)
    p=sub.add_parser("task-upsert"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.add_argument("--task-json",required=True); p.set_defaults(func=cmd_task_upsert)
    p=sub.add_parser("task-status"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.add_argument("--task-id",required=True); p.add_argument("--status",required=True); p.add_argument("--validation"); p.set_defaults(func=cmd_task_status)
    p=sub.add_parser("phase-status"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.add_argument("--phase",required=True); p.add_argument("--status",required=True); p.add_argument("--output",action="append"); p.add_argument("--validation"); p.add_argument("--task-id"); p.set_defaults(func=cmd_phase)
    p=sub.add_parser("recover"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.set_defaults(func=cmd_recover)
    args=ap.parse_args()
    try: args.func(args)
    except Exception as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr); sys.exit(2)

if __name__ == "__main__": main()

# 04_design

正式成果：solution_blueprint.json（唯一结构化数据源）和由其派生的 solution_blueprint.md。必要图表源文件放入 diagram_assets/。设计决策、假设风险、需求/评分追溯和服务间关系纳入主蓝图，不再默认拆分成独立报告或台账。
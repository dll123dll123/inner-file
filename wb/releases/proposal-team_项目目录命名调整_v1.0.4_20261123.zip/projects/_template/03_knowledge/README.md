# 03_knowledge

正式成果：evidence_catalog.json（唯一结构化数据源）和由其派生的 evidence_catalog.md。不再生成独立 CSV 台账或 evidence_gaps.md。
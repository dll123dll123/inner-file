# 05_outline

正式成果：outline.md（人工阅读版）和 chapter_plan.json（包含逐章任务、需求/评分覆盖、设计引用和章节依赖的唯一结构化数据源）。不再单独生成 coverage_map.csv 或 dependency_map.md。
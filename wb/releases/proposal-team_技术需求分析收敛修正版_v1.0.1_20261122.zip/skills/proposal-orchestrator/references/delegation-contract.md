# 智能体委派与结果交付协议

## 委派前必须提供
- task_id / project_id
- agent_role
- objective
- inputs：精确文件路径及用途
- constraints：不可改变的规则
- output_files：每个文件的唯一写入者
- dependencies：前置任务
- acceptance_criteria：可检查的验收项

## 委派任务模板
任务编号：
项目编号：
执行角色：
目标：
输入文件：
必须遵循的决策：
禁止事项：
允许写入的文件：
依赖任务：
验收标准：
完成后回报：

## 结果必须包含
- task_id
- agent_role
- status：completed / completed_with_warnings / blocked / failed
- output_files
- summary
- evidence_refs
- unresolved_issues
- validation_results
- next_actions

## 文件并发规则
同一正式输出文件只能有一个写入者。并行任务必须输出到不同文件。共享设计蓝图由方案架构师写入，其他专家只读。撰写专家只写自己被分配的章节。审核专家只写审核报告，不改正文。

## 失败处理
缺少输入标记 blocked；输入冲突列出冲突证据；无法满足验收标记 failed 或 completed_with_warnings。禁止虚报完成、虚构文件路径或将未执行检查写成通过。

## 写入授权与状态登记
委派前必须先将任务登记到当前项目 00_control/TASKS.json，状态 ready；开始执行前改为 in_progress。委派消息必须包含明确 project_dir、project_id、agent_role 和唯一 output_files。专家写入前必须通过 project_guard.py check-path，写入必须经 project_guard.py write。任务完成后由主理人核对文件与验收证据，再更新任务状态。禁止专家自行选择或推断项目目录。

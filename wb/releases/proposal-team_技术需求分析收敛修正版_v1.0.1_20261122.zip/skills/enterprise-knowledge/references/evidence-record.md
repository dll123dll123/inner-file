# 证据记录建议字段

## 必填字段
- evidence_id
- evidence_type：verified_capability / historical_delivery / product_or_tool / proposed_design / unverified
- verification_status：verified / provided_unverified / proposed_design / missing / not_applicable
- claim_supported
- source_file
- source_location
- source_date
- version
- confidence_grade：A / B / C / U
- permitted_use
- limitations
- related_requirement_ids
- related_scoring_ids
- owner_or_followup
- notes

## 状态与类别不得混淆
`evidence_type` 描述材料/主张的性质；`verification_status` 描述当前核验状态。例：一份产品说明书可以是 `product_or_tool`，但如果尚未核实产品版本、授权和项目适用范围，其状态应为 `provided_unverified`，不能直接当作已验证能力。

## 证据使用规则
每条证据只支持其实际能够证明的范围。证据不能自动外推到其他产品版本、其他地区、其他客户或更大服务范围。证据缺失时记录缺口，不得用模型常识或历史项目内容补造。

from pathlib import Path
import json
import re
import sys
import tomllib

ROOT = Path(__file__).resolve().parents[1]
errors, warnings = [], []

required_dirs = [
    ".codex/agents", ".agents/skills", "domain-packs",
    "enterprise-library", "projects/_template/00_control",
    "contracts", "tools", "docs", "tests"
]
for item in required_dirs:
    if not (ROOT / item).is_dir():
        errors.append(f"Missing directory: {item}")

required_agents = [
    "requirement-analyst.toml", "knowledge-curator.toml",
    "solution-architect.toml", "outline-planner.toml",
    "proposal-writer.toml", "proposal-reviewer.toml"
]
for name in required_agents:
    p = ROOT / ".codex/agents" / name
    if not p.is_file():
        errors.append(f"Missing agent: {p.relative_to(ROOT)}")
        continue
    try:
        data = tomllib.loads(p.read_text(encoding="utf-8"))
        for key in ("name", "description", "developer_instructions"):
            if not isinstance(data.get(key), str) or not data[key].strip():
                errors.append(f"{p.relative_to(ROOT)} missing non-empty {key}")
    except Exception as exc:
        errors.append(f"Invalid TOML {p.relative_to(ROOT)}: {exc}")

cfg = ROOT / ".codex/config.toml"
try:
    data = tomllib.loads(cfg.read_text(encoding="utf-8"))
    if data.get("agents", {}).get("enabled") is not True:
        errors.append("Codex agents.enabled must be true")
    if data.get("sandbox_mode") != "workspace-write":
        errors.append("Codex sandbox_mode must be workspace-write for project write isolation")
    if data.get("approval_policy") != "on-request":
        warnings.append("Codex approval_policy is not on-request; verify sensitive operations require approval")
    if data.get("agents", {}).get("max_concurrent_threads_per_session", 0) < 1:
        errors.append("Invalid max_concurrent_threads_per_session")
except Exception as exc:
    errors.append(f"Invalid config.toml: {exc}")

skill_root = ROOT / ".agents/skills"
skill_dirs = [p for p in skill_root.iterdir() if p.is_dir()] if skill_root.exists() else []
if len(skill_dirs) != 9:
    errors.append(f"Expected 9 skills, found {len(skill_dirs)}")
for folder in skill_dirs:
    p = folder / "SKILL.md"
    if not p.is_file():
        errors.append(f"Missing SKILL.md: {folder.name}")
        continue
    content = p.read_text(encoding="utf-8")
    match = re.match(r"\A---\s*\n(.*?)\n---\s*\n", content, re.S)
    if not match:
        errors.append(f"Invalid/missing YAML frontmatter: {p.relative_to(ROOT)}")
        continue
    front = match.group(1)
    name = re.search(r"(?m)^name:\s*([a-z0-9-]+)\s*$", front)
    desc = re.search(r"(?m)^description:\s*(.+)$", front)
    if not name or name.group(1) != folder.name:
        errors.append(f"Skill name mismatch: {p.relative_to(ROOT)}")
    if not desc or len(desc.group(1).strip()) < 30:
        errors.append(f"Skill description missing/too short: {p.relative_to(ROOT)}")
    if len(content) < 600:
        warnings.append(f"Skill body seems unusually short: {p.relative_to(ROOT)}")

for p in (ROOT / "contracts").glob("*.json"):
    try:
        json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"Invalid JSON {p.relative_to(ROOT)}: {exc}")

for p in [ROOT / "projects/_template/00_control/STATE.json",
          ROOT / "projects/_template/00_control/TASKS.json",
          ROOT / "projects/_template/00_control/project_identity.json"]:
    try:
        json.loads(p.read_text(encoding="utf-8"))
    except Exception as exc:
        errors.append(f"Invalid project state JSON {p.relative_to(ROOT)}: {exc}")


# V1.2 workflow integrity checks
identity_schema = ROOT / "contracts/project-identity.schema.json"
baseline_schema = ROOT / "contracts/analysis-baseline.schema.json"
if not identity_schema.is_file():
    errors.append("Missing project identity schema")
if not baseline_schema.is_file():
    errors.append("Missing analysis baseline schema")
try:
    state = json.loads((ROOT / "projects/_template/00_control/STATE.json").read_text(encoding="utf-8"))
    required_phases = {"intake", "requirements", "knowledge", "design", "outline", "writing", "review", "revision", "integration", "publishing", "final_gate"}
    missing_phases = required_phases - set(state.get("phase_status", {}))
    if missing_phases:
        errors.append("STATE.json missing V1.2 phases: " + ", ".join(sorted(missing_phases)))
except Exception as exc:
    errors.append(f"Could not validate V1.2 phase map: {exc}")
for rel in [".agents/skills/proposal-orchestrator/SKILL.md", ".agents/skills/proposal-orchestrator/references/workflow.md"]:
    try:
        content = (ROOT / rel).read_text(encoding="utf-8")
        headings = re.findall(r"(?m)^## 阶段 (\d+)：", content)
        if headings != [str(i) for i in range(10)]:
            errors.append(f"{rel} must define phases 0-9 exactly once; found {headings}")
    except Exception as exc:
        errors.append(f"Could not validate workflow phases in {rel}: {exc}")

for required in ["AGENTS.md", "docs/ARCHITECTURE.md", "docs/INSTALL.md",
                 "docs/OPERATING-GUIDE.md", "domain-packs/README.md",
                 "enterprise-library/README.md"]:
    if not (ROOT / required).is_file():
        errors.append(f"Missing required file: {required}")


# V1.2.1 corrective integrity checks
review_skill = ROOT / ".agents/skills/quality-review/SKILL.md"
review_checklist = ROOT / ".agents/skills/quality-review/references/review-checklist.md"
try:
    review_text = review_skill.read_text(encoding="utf-8")
    if "references/review-checklist.md" not in review_text:
        errors.append("quality-review Skill must explicitly require reading references/review-checklist.md")
except Exception as exc:
    errors.append(f"Could not inspect quality-review Skill: {exc}")

if not (ROOT / "tools/analysis_validation.py").is_file():
    errors.append("Missing tools/analysis_validation.py")
if not (ROOT / "tools/validate_analysis.py").is_file():
    errors.append("Missing tools/validate_analysis.py")
if not (ROOT / "tools/project_guard.py").is_file():
    errors.append("Missing tools/project_guard.py")

try:
    identity = json.loads((ROOT / "projects/_template/00_control/project_identity.json").read_text(encoding="utf-8"))
    if identity.get("workspace_id") != "PROJECT-PLACEHOLDER":
        errors.append("Template project_identity workspace_id must remain the placeholder")
    for field in identity.get("fields", []):
        if field.get("status") == "not_found" and field.get("locked") is not False:
            errors.append(f"Template identity field {field.get('field_key')} must not lock not_found values")
except Exception as exc:
    errors.append(f"Could not validate project identity template semantics: {exc}")

try:
    import py_compile
    for script in [ROOT / "tools/init_project.py", ROOT / "tools/analysis_validation.py",
                   ROOT / "tools/validate_analysis.py", ROOT / "tools/validate_scaffold.py",
                   ROOT / "tools/project_guard.py"]:
        py_compile.compile(str(script), doraise=True)
except Exception as exc:
    errors.append(f"Python tool syntax check failed: {exc}")

try:
    if not review_checklist.is_file():
        errors.append("Missing quality review checklist")
except Exception as exc:
    errors.append(f"Could not validate review checklist: {exc}")

print(f"Root: {ROOT}")
print(f"Skills found: {len(skill_dirs)}")
print(f"Agent files checked: {len(required_agents)}")
print(f"Errors: {len(errors)}")
print(f"Warnings: {len(warnings)}")
for item in errors:
    print("ERROR:", item)
for item in warnings:
    print("WARNING:", item)
sys.exit(1 if errors else 0)

# V1.2.2 write-guard and state-persistence wiring
for rel in [".agents/skills/proposal-orchestrator/SKILL.md", "AGENTS.md"]:
    try:
        txt = (ROOT / rel).read_text(encoding="utf-8")
        if "project_guard.py check-path" not in txt or "project_guard.py write" not in txt:
            errors.append(f"{rel} missing mandatory project_guard write instructions")
        if "TASKS.json" not in txt or "STATE.json" not in txt or "recover" not in txt:
            errors.append(f"{rel} missing durable task/phase recovery instructions")
    except Exception as exc:
        errors.append(f"Could not validate V1.2.2 instructions in {rel}: {exc}")
for name in ["requirement-analyst.toml", "knowledge-curator.toml", "solution-architect.toml", "outline-planner.toml", "proposal-writer.toml", "proposal-reviewer.toml"]:
    p = ROOT / ".codex/agents" / name
    if p.exists() and "MANDATORY WRITE SAFETY" not in p.read_text(encoding="utf-8"):
        errors.append(f"{name} missing mandatory write safety instruction")

# V1.2.3 technical-only requirement analysis contract
try:
    analyst_skill = (ROOT / ".agents/skills/requirement-analysis/SKILL.md").read_text(encoding="utf-8")
    for required_text in ["service_requirements.csv", "technical_scoring.csv", "service_requirement_map.md", "service_mappings", "不分析整本招标文件"]:
        if required_text not in analyst_skill:
            errors.append(f"requirement-analysis Skill missing V1.2.3 scope/output rule: {required_text}")
    if "proposal_content_plan_matrix.csv" in analyst_skill or "正式章节编号" not in analyst_skill:
        errors.append("requirement-analysis Skill must not create final chapter mapping")
except Exception as exc:
    errors.append(f"Could not validate V1.2.3 requirement-analysis contract: {exc}")

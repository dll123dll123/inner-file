from pathlib import Path
import argparse
import sys
from analysis_validation import validate_project

def main() -> int:
    parser = argparse.ArgumentParser(description="校验技术服务需求分析基线和项目身份信息。")
    parser.add_argument("project_dir", type=Path, help="项目工作区目录")
    args = parser.parse_args()
    project_dir = args.project_dir.resolve()
    if not project_dir.is_dir():
        raise SystemExit(f"项目目录不存在：{project_dir}")
    errors, warnings = validate_project(project_dir)
    print(f"项目目录：{project_dir}")
    print(f"错误数量：{len(errors)}")
    print(f"警告数量：{len(warnings)}")
    for item in errors: print("错误：", item)
    for item in warnings: print("警告：", item)
    return 1 if errors else 0

if __name__ == "__main__":
    sys.exit(main())

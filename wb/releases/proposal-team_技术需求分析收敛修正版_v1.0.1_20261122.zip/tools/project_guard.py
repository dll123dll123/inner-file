#!/usr/bin/env python3
"""Project-scoped write guard and durable workflow state manager.

This guard is a mandatory preflight for every agent write. Codex workspace sandbox
must additionally be rooted at this repository; this script does not replace OS sandboxing.
"""
from __future__ import annotations
import argparse, json, os, sys, tempfile
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
ROLE_DIRS = {
    "coordinator": {"00_control", "02_requirements", "07_reviews", "08_delivery"},
    "requirement_analyst": {"02_requirements"},
    "knowledge_curator": {"03_knowledge"},
    "solution_architect": {"04_design"},
    "outline_planner": {"05_outline"},
    "proposal_writer": {"06_chapters"},
    "proposal_reviewer": {"07_reviews"},
    "word_publisher": {"08_delivery"},
}
PHASES = ["intake", "requirements", "knowledge", "design", "outline", "writing", "review", "revision", "integration", "publishing", "final_gate"]
TASK_STATUSES = {"pending", "ready", "in_progress", "blocked", "completed", "completed_with_warnings", "failed"}
PHASE_STATUSES = {"pending", "in_progress", "blocked", "completed", "skipped"}


def now():
    return datetime.now(timezone.utc).isoformat()


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def append_audit(project: Path, event: str, **details):
    audit = project / "00_control" / "EXECUTION_AUDIT.jsonl"
    audit.parent.mkdir(parents=True, exist_ok=True)
    record = {"timestamp": now(), "event": event, "project_id": project.name, **details}
    with audit.open("a", encoding="utf-8", newline="\n") as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")
        f.flush(); os.fsync(f.fileno())


def atomic_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
            f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise


def project_root(project_dir: str, expected_project_id: str) -> Path:
    p = Path(project_dir).expanduser().absolute()
    # Resolve parent chain and reject a symlinked project root.
    if p.is_symlink():
        raise ValueError("project root must not be a symlink")
    resolved = p.resolve(strict=True)
    projects_root = (REPO_ROOT / "projects").resolve(strict=True)
    if resolved.parent != projects_root or resolved.name == "_template":
        raise ValueError(f"project must be a direct child of {projects_root}; got {resolved}")
    for required in ("00_control/STATE.json", "00_control/TASKS.json", "00_control/project_identity.json"):
        if not (resolved / required).is_file():
            raise ValueError(f"not a valid project workspace; missing {required}")
    identity = load_json(resolved / "00_control/project_identity.json")
    state = load_json(resolved / "00_control/STATE.json")
    if resolved.name != expected_project_id:
        raise ValueError(f"selected workspace {resolved.name} does not match delegated project_id {expected_project_id}")
    if identity.get("workspace_id") != resolved.name or state.get("project_id") != resolved.name:
        raise ValueError("project identity/state does not match selected workspace directory")
    return resolved


def guarded_target(project: Path, role: str, rel: str) -> Path:
    if role not in ROLE_DIRS:
        raise ValueError(f"unknown role: {role}")
    raw = Path(rel)
    if raw.is_absolute() or ".." in raw.parts:
        raise ValueError("absolute paths and parent traversal are forbidden")
    if not raw.parts or raw.parts[0] not in ROLE_DIRS[role]:
        raise ValueError(f"role {role} may write only under: {', '.join(sorted(ROLE_DIRS[role]))}")
    # Reject symlink components, including dangling links, before resolving.
    cur = project
    for part in raw.parts:
        cur = cur / part
        if cur.exists() and cur.is_symlink():
            raise ValueError(f"symlink path component is forbidden: {cur}")
    target = (project / raw).resolve(strict=False)
    if target != project and project not in target.parents:
        raise ValueError("resolved output escapes project root")
    if target.parts[:len(project.parts)] != project.parts:
        raise ValueError("resolved output is outside selected project")
    return target



def existing_project_file(project: Path, rel: str) -> Path:
    raw = Path(rel)
    if raw.is_absolute() or ".." in raw.parts or not raw.parts:
        raise ValueError("phase output must be a project-relative path without parent traversal")
    cur = project
    for part in raw.parts:
        cur = cur / part
        if cur.exists() and cur.is_symlink():
            raise ValueError(f"symlink output path is forbidden: {cur}")
    target = (project / raw).resolve(strict=False)
    if target != project and project not in target.parents:
        raise ValueError("phase output resolves outside project root")
    return target

def cmd_check(args):
    project = project_root(args.project_dir, args.expected_project_id)
    target = guarded_target(project, args.role, args.path)
    print(f"ALLOW project={project.name} role={args.role} path={target.relative_to(project)}")


def cmd_write(args):
    project = project_root(args.project_dir, args.expected_project_id)
    target = guarded_target(project, args.role, args.path)
    if target.exists() and not args.overwrite:
        raise ValueError("target exists; use --overwrite only when the assigned task authorizes replacement")
    content = Path(args.source).read_bytes()
    target.parent.mkdir(parents=True, exist_ok=True)
    # Re-check after directory creation to catch a newly introduced symlink.
    target = guarded_target(project, args.role, args.path)
    fd, tmp = tempfile.mkstemp(prefix=target.name + ".", suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(content); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, target)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise
    append_audit(project, "guarded_write", role=args.role, path=target.relative_to(project).as_posix(), bytes=len(content))
    print(f"WROTE {target.relative_to(project)} bytes={len(content)}")


def cmd_task_upsert(args):
    project = project_root(args.project_dir, args.expected_project_id)
    path = project / "00_control/TASKS.json"
    data = load_json(path)
    if data.get("project_id") != project.name:
        raise ValueError("TASKS.json project_id mismatch")
    try: task = json.loads(args.task_json)
    except json.JSONDecodeError as e: raise ValueError(f"invalid --task-json: {e}")
    required = ["task_id", "title", "agent_role", "status", "inputs", "outputs", "dependencies", "acceptance_criteria"]
    missing = [k for k in required if k not in task]
    if missing: raise ValueError("task missing fields: " + ", ".join(missing))
    if task["status"] not in TASK_STATUSES: raise ValueError("invalid task status")
    for rel in task.get("outputs", []): guarded_target(project, task.get("agent_role"), rel)
    task.setdefault("validation", []); task.setdefault("owner", None)
    task.setdefault("created_at", now()); task["updated_at"] = now()
    if task["status"] in {"completed", "completed_with_warnings"}:
        if not task.get("outputs") or not task.get("validation"):
            raise ValueError("completed task requires outputs and validation evidence")
        role = task.get("agent_role")
        for rel in task["outputs"]:
            out = guarded_target(project, role, rel)
            if not out.is_file(): raise ValueError(f"completed task output missing: {rel}")
    tasks = data.setdefault("tasks", [])
    old = next((x for x in tasks if x.get("task_id") == task["task_id"]), None)
    if old:
        task["created_at"] = old.get("created_at") or task["created_at"]
        tasks[tasks.index(old)] = task
    else: tasks.append(task)
    atomic_json(path, data)
    append_audit(project, "task_upsert", task_id=task["task_id"], role=task.get("agent_role"), status=task["status"])
    print(f"TASK_SAVED {task['task_id']} status={task['status']}")


def cmd_task_status(args):
    project = project_root(args.project_dir, args.expected_project_id)
    path = project / "00_control/TASKS.json"; data = load_json(path)
    task = next((x for x in data.get("tasks", []) if x.get("task_id") == args.task_id), None)
    if not task: raise ValueError(f"unknown task_id: {args.task_id}")
    if args.status not in TASK_STATUSES: raise ValueError("invalid task status")
    if args.status in {"completed", "completed_with_warnings"}:
        if not task.get("outputs") or not task.get("validation") and not args.validation:
            raise ValueError("completed task requires declared outputs and validation evidence")
        role = task.get("agent_role")
        for rel in task["outputs"]:
            out = guarded_target(project, role, rel)
            if not out.is_file(): raise ValueError(f"completed task output missing: {rel}")
    task["status"] = args.status; task["updated_at"] = now()
    if args.validation: task.setdefault("validation", []).append(args.validation)
    atomic_json(path, data)
    append_audit(project, "task_status", task_id=args.task_id, status=args.status)
    print(f"TASK_UPDATED {args.task_id} status={args.status}")


def cmd_phase(args):
    project = project_root(args.project_dir, args.expected_project_id)
    if args.phase not in PHASES: raise ValueError("invalid phase")
    if args.status not in PHASE_STATUSES: raise ValueError("invalid phase status")
    # Completion requires concrete outputs and validation evidence.
    outputs = [x for x in (args.output or []) if x.strip()]
    if args.status == "completed":
        if not outputs: raise ValueError("completed phase requires at least one --output")
        if not args.validation: raise ValueError("completed phase requires --validation evidence")
        for rel in outputs:
            p = existing_project_file(project, rel)
            if not p.is_file(): raise ValueError(f"cannot complete phase; output missing: {rel}")
    state_path = project / "00_control/STATE.json"; state = load_json(state_path)
    if state.get("project_id") != project.name: raise ValueError("STATE.json project_id mismatch")
    state.setdefault("phase_status", {})[args.phase] = args.status
    state["current_phase"] = args.phase
    state["overall_status"] = "blocked" if args.status == "blocked" else ("in_progress" if args.status != "completed" else ("completed" if args.phase == "final_gate" else "in_progress"))
    if args.status == "completed": state["last_completed_task"] = args.task_id or args.phase
    if args.phase == "final_gate" and args.status == "completed": state["current_phase"] = "completed"
    state["updated_at"] = now()
    atomic_json(state_path, state)
    append_audit(project, "phase_status", phase=args.phase, status=args.status, outputs=outputs, validation=args.validation)
    print(f"PHASE_UPDATED {args.phase} status={args.status}")


def cmd_recover(args):
    project = project_root(args.project_dir, args.expected_project_id)
    path = project / "00_control/TASKS.json"; data = load_json(path)
    recovered=[]
    for task in data.get("tasks", []):
        if task.get("status") == "in_progress":
            task["status"] = "ready"
            task.setdefault("validation", []).append(f"Recovered after interrupted session at {now()}; previous status was in_progress. Revalidate outputs before completion.")
            task["updated_at"] = now(); recovered.append(task.get("task_id"))
    if recovered:
        atomic_json(path, data)
        append_audit(project, "interrupted_tasks_recovered", task_ids=recovered)
    print(json.dumps({"project_id": project.name, "recovered_tasks": recovered, "count": len(recovered)}, ensure_ascii=False))


def main():
    ap=argparse.ArgumentParser(description="Project-scoped write guard and workflow state manager")
    sub=ap.add_subparsers(required=True)
    p=sub.add_parser("check-path"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.add_argument("--role",required=True); p.add_argument("--path",required=True); p.set_defaults(func=cmd_check)
    p=sub.add_parser("write"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.add_argument("--role",required=True); p.add_argument("--path",required=True); p.add_argument("--source",required=True); p.add_argument("--overwrite",action="store_true"); p.set_defaults(func=cmd_write)
    p=sub.add_parser("task-upsert"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.add_argument("--task-json",required=True); p.set_defaults(func=cmd_task_upsert)
    p=sub.add_parser("task-status"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.add_argument("--task-id",required=True); p.add_argument("--status",required=True); p.add_argument("--validation"); p.set_defaults(func=cmd_task_status)
    p=sub.add_parser("phase-status"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.add_argument("--phase",required=True); p.add_argument("--status",required=True); p.add_argument("--output",action="append"); p.add_argument("--validation"); p.add_argument("--task-id"); p.set_defaults(func=cmd_phase)
    p=sub.add_parser("recover"); p.add_argument("--project-dir",required=True); p.add_argument("--expected-project-id",required=True); p.set_defaults(func=cmd_recover)
    args=ap.parse_args()
    try: args.func(args)
    except Exception as exc:
        print(f"BLOCKED: {exc}", file=sys.stderr); sys.exit(2)

if __name__ == "__main__": main()

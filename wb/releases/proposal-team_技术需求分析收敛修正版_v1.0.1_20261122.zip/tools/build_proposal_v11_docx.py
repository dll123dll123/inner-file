from __future__ import annotations

import argparse
import re
from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor
from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "projects" / "XM26DEMO000001"
CHAPTER_DIR = PROJECT / "06_chapters"
OUTPUT_DIR = PROJECT / "08_delivery"
OUTPUT = OUTPUT_DIR / "示例财险示例省分公司2026年度信息安全服务采购项目_技术服务方案_V1.0.docx"

PROJECT_TITLE = "示例财险示例省分公司2026年度信息安全服务采购项目"
DOCUMENT_TITLE = "技术服务方案"
PROJECT_ID = "XM26DEMO000001"
VERSION = "V1.0"

BLACK = RGBColor(0, 0, 0)
DARK = RGBColor(31, 41, 55)
MUTED = RGBColor(75, 85, 99)
WHITE = RGBColor(255, 255, 255)
HEADER_FILL = "1F4E79"
ALT_FILL = "F2F5F9"
BORDER = "D9D9D9"


def set_run_font(
    run,
    *,
    ascii_font: str = "Times New Roman",
    east_asia_font: str = "宋体",
    size: float | None = None,
    bold: bool | None = None,
    color: RGBColor | None = None,
) -> None:
    run.font.name = ascii_font
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), ascii_font)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), ascii_font)
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), east_asia_font)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.bold = bold
    if color is not None:
        run.font.color.rgb = color


def set_paragraph_spacing(paragraph, *, before=0, after=6, line=1.5) -> None:
    fmt = paragraph.paragraph_format
    fmt.space_before = Pt(before)
    fmt.space_after = Pt(after)
    fmt.line_spacing = line


def set_cell_shading(cell, fill: str) -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)
    shd.set(qn("w:val"), "clear")


def set_cell_margins(cell, top=80, start=100, bottom=80, end=100) -> None:
    tc = cell._tc
    tc_pr = tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin, value in (("top", top), ("start", start), ("bottom", bottom), ("end", end)):
        node = tc_mar.find(qn(f"w:{margin}"))
        if node is None:
            node = OxmlElement(f"w:{margin}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_borders(table) -> None:
    tbl_pr = table._tbl.tblPr
    borders = tbl_pr.first_child_found_in("w:tblBorders")
    if borders is None:
        borders = OxmlElement("w:tblBorders")
        tbl_pr.append(borders)
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        tag = f"w:{edge}"
        element = borders.find(qn(tag))
        if element is None:
            element = OxmlElement(tag)
            borders.append(element)
        element.set(qn("w:val"), "single")
        element.set(qn("w:sz"), "6")
        element.set(qn("w:space"), "0")
        element.set(qn("w:color"), BORDER)


def set_repeat_table_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def prevent_row_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)


def add_field(paragraph, instruction: str, placeholder: str = "") -> None:
    run = paragraph.add_run()
    begin = OxmlElement("w:fldChar")
    begin.set(qn("w:fldCharType"), "begin")
    instr = OxmlElement("w:instrText")
    instr.set(qn("xml:space"), "preserve")
    instr.text = instruction
    separate = OxmlElement("w:fldChar")
    separate.set(qn("w:fldCharType"), "separate")
    text = OxmlElement("w:t")
    text.text = placeholder
    end = OxmlElement("w:fldChar")
    end.set(qn("w:fldCharType"), "end")
    run._r.extend([begin, instr, separate, text, end])
    set_run_font(run, size=9, color=MUTED)


def configure_document(doc: Document) -> None:
    section = doc.sections[0]
    section.page_width = Inches(8.5)
    section.page_height = Inches(11)
    section.top_margin = Inches(0.85)
    section.bottom_margin = Inches(0.8)
    section.left_margin = Inches(1.0)
    section.right_margin = Inches(1.0)
    section.header_distance = Inches(0.4)
    section.footer_distance = Inches(0.4)
    section.different_first_page_header_footer = True

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Times New Roman"
    normal._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "宋体")
    normal.font.size = Pt(11)
    normal.font.color.rgb = DARK
    normal.paragraph_format.line_spacing = 1.5
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.widow_control = True

    title = styles["Title"]
    title.font.name = "Microsoft YaHei"
    title._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "微软雅黑")
    title.font.size = Pt(23)
    title.font.bold = True
    title.font.color.rgb = BLACK
    title.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title.paragraph_format.space_before = Pt(0)
    title.paragraph_format.space_after = Pt(20)
    title.paragraph_format.keep_with_next = True

    heading_sizes = {1: 18, 2: 14, 3: 12}
    for level, size in heading_sizes.items():
        style = styles[f"Heading {level}"]
        style.font.name = "Microsoft YaHei"
        style._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), "微软雅黑")
        style.font.size = Pt(size)
        style.font.bold = True
        style.font.color.rgb = BLACK
        style.paragraph_format.space_before = Pt(16 if level == 1 else 12 if level == 2 else 9)
        style.paragraph_format.space_after = Pt(8 if level == 1 else 6 if level == 2 else 4)
        style.paragraph_format.keep_with_next = True
        style.paragraph_format.widow_control = True

    for name, size, bold in (
        ("Front Matter Heading", 16, True),
        ("TOC Title", 18, True),
        ("Table Caption", 9.5, False),
        ("Figure Caption", 9.5, False),
        ("Cover Meta", 11.5, False),
    ):
        style = styles.add_style(name, 1)
        style.font.name = "Microsoft YaHei" if bold else "Times New Roman"
        style._element.get_or_add_rPr().rFonts.set(
            qn("w:eastAsia"), "微软雅黑" if bold else "宋体"
        )
        style.font.size = Pt(size)
        style.font.bold = bold
        style.font.color.rgb = BLACK if bold else MUTED
        style.paragraph_format.alignment = (
            WD_ALIGN_PARAGRAPH.CENTER if bold else WD_ALIGN_PARAGRAPH.CENTER
        )
        style.paragraph_format.space_before = Pt(12 if bold else 3)
        style.paragraph_format.space_after = Pt(8 if bold else 3)
        style.paragraph_format.line_spacing = 1.2
        style.paragraph_format.keep_with_next = bold

    header = section.header
    hp = header.paragraphs[0]
    hp.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    set_paragraph_spacing(hp, before=0, after=0, line=1.0)
    hr = hp.add_run(f"{PROJECT_TITLE}  |  技术服务方案")
    set_run_font(hr, size=8.5, color=MUTED)

    footer = section.footer
    fp = footer.paragraphs[0]
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_paragraph_spacing(fp, before=0, after=0, line=1.0)
    set_run_font(fp.add_run("第 "), size=9, color=MUTED)
    add_field(fp, " PAGE ", "1")
    set_run_font(fp.add_run(" 页"), size=9, color=MUTED)

    props = doc.core_properties
    props.title = f"{PROJECT_TITLE}技术服务方案"
    props.subject = "日常安全驻场服务、重保服务和安全培训"
    props.author = "项目方案组"
    props.keywords = f"{PROJECT_ID} 信息安全服务 技术服务方案"


def add_cover(doc: Document) -> None:
    for _ in range(3):
        doc.add_paragraph()
    p = doc.add_paragraph(style="Cover Meta")
    p.add_run("技术文件")
    p = doc.add_paragraph(style="Title")
    p.add_run(DOCUMENT_TITLE)
    p = doc.add_paragraph(style="Cover Meta")
    set_run_font(p.add_run(PROJECT_TITLE), size=14, bold=True, color=BLACK)
    doc.add_paragraph()
    p = doc.add_paragraph(style="Cover Meta")
    set_run_font(p.add_run("日常安全驻场服务  |  重保服务  |  安全培训"), size=12, color=MUTED)
    for _ in range(6):
        doc.add_paragraph()
    for text in (
        f"项目编号  {PROJECT_ID}",
        f"文档版本  {VERSION}",
        "编制日期  2026年11月",
    ):
        p = doc.add_paragraph(style="Cover Meta")
        set_run_font(p.add_run(text), size=11.5, color=DARK)
    doc.add_page_break()


def add_front_matter(doc: Document) -> None:
    doc.add_paragraph("文档说明", style="Front Matter Heading")
    intro = (
        "本技术方案围绕示例财险示例省分公司2026年度信息安全服务采购项目编写，"
        "用于说明日常安全驻场服务、重保服务和安全培训的服务目标、技术方法、运行机制、"
        "组织保障、质量控制、交付验收和风险边界。方案以客户授权、现有平台复用、"
        "生产操作可审批、过程记录可追溯和问题闭环为基本要求。"
    )
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.first_line_indent = Pt(22)
    p.add_run(intro)

    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.first_line_indent = Pt(22)
    p.add_run(
        "本方案为技术响应文件。资格证明、商务文件、正式报价、投标函和承诺书按招标文件"
        "另册编制。服务人员数量、驻场地点、平台接口、响应目标、培训场次和赛事规模等"
        "未在招标文件中明确的内容，在合同或任务单中确认后执行。"
    )

    rows = [
        ["项目", "内容"],
        ["项目编号", PROJECT_ID],
        ["项目名称", PROJECT_TITLE],
        ["文档名称", DOCUMENT_TITLE],
        ["文档版本", VERSION],
        ["编制日期", "2026年11月"],
        ["适用范围", "日常安全驻场服务、重保服务、安全培训"],
        ["文档状态", "技术方案"],
    ]
    add_table(doc, rows, caption="文档控制信息")
    doc.add_page_break()

    p = doc.add_paragraph("目录", style="TOC Title")
    p.paragraph_format.space_after = Pt(10)
    toc = doc.add_paragraph()
    add_field(toc, ' TOC \\o "1-2" \\h \\z \\u ', "目录将在打开文档后更新")
    doc.add_page_break()


def add_table(doc: Document, rows: list[list[str]], caption: str | None = None) -> None:
    if not rows:
        return
    if len(rows) > 1 and all(re.fullmatch(r":?-{3,}:?", c.strip()) for c in rows[1] if c):
        rows = [rows[0], *rows[2:]]
    cols = max(len(r) for r in rows)
    rows = [r + [""] * (cols - len(r)) for r in rows]
    if caption is None:
        header = [c.strip() for c in rows[0][:3] if c.strip()]
        caption = "、".join(header) + "对照" if header else "服务要素对照"
    table_index = sum(1 for p in doc.paragraphs if p.style.name == "Table Caption") + 1
    cap = doc.add_paragraph(style="Table Caption")
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_paragraph_spacing(cap, before=6, after=4, line=1.0)
    set_run_font(cap.add_run(f"表 {table_index}  {caption}"), size=9.5, color=MUTED)
    cap.paragraph_format.keep_with_next = True

    table = doc.add_table(rows=len(rows), cols=cols)
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = True
    set_table_borders(table)

    max_lengths = []
    for col in range(cols):
        values = [r[col] for r in rows]
        max_lengths.append(max(len(v) for v in values))
    weights = [max(6, min(30, n)) for n in max_lengths]
    total_weight = sum(weights)
    usable_width = 6.3
    widths = [Inches(usable_width * w / total_weight) for w in weights]

    for row_index, row in enumerate(rows):
        tr = table.rows[row_index]
        prevent_row_split(tr)
        if row_index == 0:
            set_repeat_table_header(tr)
        for col_index, value in enumerate(row):
            cell = table.cell(row_index, col_index)
            cell.width = widths[col_index]
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            set_cell_margins(cell)
            if row_index == 0:
                set_cell_shading(cell, HEADER_FILL)
            elif row_index % 2 == 0:
                set_cell_shading(cell, ALT_FILL)
            paragraph = cell.paragraphs[0]
            paragraph.alignment = (
                WD_ALIGN_PARAGRAPH.CENTER
                if row_index == 0 or len(value.strip()) <= 8
                else WD_ALIGN_PARAGRAPH.LEFT
            )
            set_paragraph_spacing(paragraph, before=0, after=0, line=1.15)
            add_inline_text(
                paragraph,
                value.strip(),
                size=9.0,
                bold=row_index == 0,
                color=WHITE if row_index == 0 else DARK,
            )
    spacer = doc.add_paragraph()
    set_paragraph_spacing(spacer, before=0, after=4, line=1.0)


def add_inline_text(
    paragraph,
    text: str,
    *,
    size: float = 11,
    bold: bool = False,
    color: RGBColor = DARK,
) -> None:
    pattern = re.compile(r"(\*\*.*?\*\*|`.*?`)")
    positions = 0
    for match in pattern.finditer(text):
        if match.start() > positions:
            run = paragraph.add_run(text[positions : match.start()])
            set_run_font(run, size=size, bold=bold, color=color)
        token = match.group(0)
        if token.startswith("**"):
            run = paragraph.add_run(token[2:-2])
            set_run_font(run, size=size, bold=True, color=color)
        else:
            run = paragraph.add_run(token[1:-1])
            set_run_font(
                run,
                ascii_font="Consolas",
                east_asia_font="宋体",
                size=max(8.5, size - 0.5),
                bold=bold,
                color=color,
            )
        positions = match.end()
    if positions < len(text):
        run = paragraph.add_run(text[positions:])
        set_run_font(run, size=size, bold=bold, color=color)


def add_body_paragraph(doc: Document, text: str, *, first_line: bool = True) -> None:
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    set_paragraph_spacing(p, before=0, after=6, line=1.5)
    p.paragraph_format.first_line_indent = Pt(22) if first_line else Pt(0)
    add_inline_text(p, text)


def add_list_item(doc: Document, text: str, ordered: bool) -> None:
    p = doc.add_paragraph(style="List Number" if ordered else "List Bullet")
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    set_paragraph_spacing(p, before=0, after=3, line=1.3)
    p.paragraph_format.left_indent = Inches(0.3)
    p.paragraph_format.first_line_indent = Inches(-0.15)
    add_inline_text(p, text)


def add_diagram(doc: Document, source: str, caption: str) -> None:
    image_path = PROJECT / source
    image_path = image_path.with_suffix(".png")
    if not image_path.exists():
        raise FileNotFoundError(f"Diagram not found: {image_path}")
    with Image.open(image_path) as image:
        width_px, height_px = image.size
    width_in = 6.25
    height_in = width_in * height_px / width_px
    if height_in > 8.4:
        height_in = 8.4
        width_in = height_in * width_px / height_px
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_paragraph_spacing(p, before=8, after=2, line=1.0)
    p.paragraph_format.keep_with_next = True
    run = p.add_run()
    inline = run.add_picture(str(image_path), width=Inches(width_in), height=Inches(height_in))
    try:
        inline._inline.docPr.set("descr", caption)
        inline._inline.docPr.set("title", caption)
    except Exception:
        pass
    cap = doc.add_paragraph(style="Figure Caption")
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_paragraph_spacing(cap, before=0, after=10, line=1.0)
    set_run_font(cap.add_run(caption), size=9.5, color=MUTED)


def parse_table(lines: list[str], start: int) -> tuple[list[list[str]], int]:
    rows: list[list[str]] = []
    index = start
    while index < len(lines) and "|" in lines[index]:
        raw = lines[index].strip()
        if raw.startswith("|"):
            raw = raw[1:]
        if raw.endswith("|"):
            raw = raw[:-1]
        cells = [cell.strip() for cell in raw.split("|")]
        if not all(re.fullmatch(r":?-{3,}:?", c) for c in cells if c):
            rows.append(cells)
        index += 1
    return rows, index


def add_markdown_file(doc: Document, path: Path, chapter_no: int) -> None:
    text = path.read_text(encoding="utf-8")
    text = re.sub(r"<!--\s*INTERNAL.*?-->", "", text, flags=re.S)
    lines = text.splitlines()
    h2_no = 0
    h3_no = 0
    h4_no = 0
    para_buffer: list[str] = []
    table_no = 0

    def flush_paragraph() -> None:
        nonlocal para_buffer
        if para_buffer:
            joined = " ".join(line.strip() for line in para_buffer).strip()
            if joined:
                add_body_paragraph(doc, joined)
            para_buffer = []

    index = 0
    while index < len(lines):
        line = lines[index]
        stripped = line.strip()
        diagram = re.fullmatch(r"<!--\s*DIAGRAM:([^|]+)\|(.+?)\s*-->", stripped)
        if diagram:
            flush_paragraph()
            add_diagram(doc, diagram.group(1).strip(), diagram.group(2).strip())
            index += 1
            continue
        if stripped.startswith("<!--"):
            index += 1
            continue
        if not stripped:
            flush_paragraph()
            index += 1
            continue
        heading_match = re.match(r"^(#{1,4})\s+(.+?)\s*$", stripped)
        if heading_match:
            flush_paragraph()
            level = len(heading_match.group(1))
            raw_title = heading_match.group(2).strip()
            clean_title = re.sub(r"^\d+(?:\.\d+)*[\.、\s]+", "", raw_title).strip()
            if level == 1:
                chapter_heading = doc.add_paragraph(style="Heading 1")
                chapter_heading.paragraph_format.page_break_before = True
                set_run_font(
                    chapter_heading.add_run(
                        f"第{chapter_no}章（C{chapter_no:02d}）  {clean_title}"
                    ),
                    ascii_font="Microsoft YaHei",
                    east_asia_font="微软雅黑",
                    size=18,
                    bold=True,
                    color=BLACK,
                )
                h2_no = 0
                h3_no = 0
                h4_no = 0
            elif level == 2:
                h2_no += 1
                h3_no = 0
                h4_no = 0
                heading = doc.add_paragraph(style="Heading 2")
                set_run_font(
                    heading.add_run(f"{chapter_no}.{h2_no}  {clean_title}"),
                    ascii_font="Microsoft YaHei",
                    east_asia_font="微软雅黑",
                    size=14,
                    bold=True,
                    color=BLACK,
                )
            elif level == 3:
                h3_no += 1
                h4_no = 0
                heading = doc.add_paragraph(style="Heading 3")
                set_run_font(
                    heading.add_run(
                        f"{chapter_no}.{h2_no}.{h3_no}  {clean_title}"
                    ),
                    ascii_font="Microsoft YaHei",
                    east_asia_font="微软雅黑",
                    size=12,
                    bold=True,
                    color=BLACK,
                )
            else:
                h4_no += 1
                heading = doc.add_paragraph(style="Heading 3")
                set_run_font(
                    heading.add_run(
                        f"{chapter_no}.{h2_no}.{h3_no}.{h4_no}  {clean_title}"
                    ),
                    ascii_font="Microsoft YaHei",
                    east_asia_font="微软雅黑",
                    size=11.5,
                    bold=True,
                    color=BLACK,
                )
            index += 1
            continue
        if stripped.startswith("|"):
            flush_paragraph()
            rows, next_index = parse_table(lines, index)
            if rows:
                table_no += 1
                header = [cell for cell in rows[0][:3] if cell]
                caption = "、".join(header) + "对照" if header else f"第{table_no}组服务对照"
                add_table(doc, rows, caption=caption)
            index = max(next_index, index + 1)
            continue
        ordered = re.match(r"^\d+[.)、]\s+(.+)$", stripped)
        bullet = re.match(r"^[-*+]\s+(.+)$", stripped)
        if ordered:
            flush_paragraph()
            add_list_item(doc, ordered.group(1).strip(), ordered=True)
            index += 1
            continue
        if bullet:
            flush_paragraph()
            add_list_item(doc, bullet.group(1).strip(), ordered=False)
            index += 1
            continue
        if stripped in ("---", "***", "___"):
            flush_paragraph()
            index += 1
            continue
        if stripped.startswith(">"):
            flush_paragraph()
            add_body_paragraph(doc, stripped.lstrip("> ").strip(), first_line=False)
            index += 1
            continue
        para_buffer.append(stripped)
        index += 1
    flush_paragraph()


def build(expected_chapters: int = 16) -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    doc = Document()
    configure_document(doc)
    add_cover(doc)
    add_front_matter(doc)

    chapters = sorted(CHAPTER_DIR.glob("C[0-9][0-9]_*.md"))
    if len(chapters) != expected_chapters:
        raise RuntimeError(
            f"Expected {expected_chapters} chapter files, found {len(chapters)}"
        )
    for index, path in enumerate(chapters, start=1):
        add_markdown_file(doc, path, index)

    doc.save(OUTPUT)
    print(f"Saved {OUTPUT}")
    print(f"Chapters: {len(chapters)}")
    return OUTPUT


def main() -> None:
    global PROJECT, CHAPTER_DIR, OUTPUT_DIR, OUTPUT, DOCUMENT_TITLE, PROJECT_ID, VERSION
    parser = argparse.ArgumentParser(description="Build a proposal DOCX from Markdown chapters.")
    parser.add_argument("--project", default="XM26DEMO000001", help="Project directory name.")
    parser.add_argument("--document-title", default="技术服务方案")
    parser.add_argument("--version", default="V1.0")
    parser.add_argument("--expected-chapters", type=int, default=16)
    args = parser.parse_args()

    PROJECT_ID = args.project
    DOCUMENT_TITLE = args.document_title
    VERSION = args.version
    PROJECT = ROOT / "projects" / PROJECT_ID
    CHAPTER_DIR = PROJECT / "06_chapters"
    OUTPUT_DIR = PROJECT / "08_delivery"
    OUTPUT = OUTPUT_DIR / f"{PROJECT_TITLE}_{DOCUMENT_TITLE}_{VERSION}.docx"
    build(expected_chapters=args.expected_chapters)


if __name__ == "__main__":
    main()

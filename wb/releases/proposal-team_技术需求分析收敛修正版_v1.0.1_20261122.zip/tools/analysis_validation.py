from __future__ import annotations
import json
from pathlib import Path
from typing import Any

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = PACKAGE_ROOT / "contracts" / "analysis-baseline.schema.json"

def _load_json(path: Path, errors: list[str]) -> dict[str, Any] | None:
    try:
        data=json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data,dict):
            errors.append(f"{path.name}：根节点必须是 JSON 对象")
            return None
        return data
    except Exception as exc:
        errors.append(f"{path.name}：JSON 无法读取或格式错误：{exc}")
        return None

def _matches_type(value: Any, expected: str) -> bool:
    if expected=="object": return isinstance(value,dict)
    if expected=="array": return isinstance(value,list)
    if expected=="string": return isinstance(value,str)
    if expected=="boolean": return isinstance(value,bool)
    if expected=="integer": return isinstance(value,int) and not isinstance(value,bool)
    if expected=="number": return isinstance(value,(int,float)) and not isinstance(value,bool)
    if expected=="null": return value is None
    return True

def _resolve_ref(root: dict[str,Any], ref: str) -> dict[str,Any]:
    if not ref.startswith("#/"): raise ValueError(f"仅支持本地 Schema 引用：{ref}")
    value: Any=root
    for part in ref[2:].split("/"):
        value=value[part.replace("~1","/").replace("~0","~")]
    if not isinstance(value,dict): raise ValueError(f"Schema 引用目标不是对象：{ref}")
    return value

def _validate_schema(value: Any, rule: dict[str,Any], root: dict[str,Any], path: str, errors: list[str]) -> None:
    if "$ref" in rule:
        try: target=_resolve_ref(root,rule["$ref"])
        except Exception as exc:
            errors.append(f"{path}：Schema 引用无法解析：{exc}")
            return
        _validate_schema(value,target,root,path,errors)
        return
    if "const" in rule and value!=rule["const"]: errors.append(f"{path}：必须等于 {rule['const']!r}")
    if "enum" in rule and value not in rule["enum"]: errors.append(f"{path}：值不在允许范围内")
    expected=rule.get("type")
    if expected:
        types=expected if isinstance(expected,list) else [expected]
        if not any(_matches_type(value,t) for t in types):
            errors.append(f"{path}：类型不正确，要求 {types}，实际为 {type(value).__name__}")
            return
    if isinstance(value,dict):
        props=rule.get("properties",{})
        for key in rule.get("required",[]):
            if key not in value: errors.append(f"{path}：缺少必填字段 {key}")
        for key,child in props.items():
            if key in value and isinstance(child,dict): _validate_schema(value[key],child,root,f"{path}.{key}",errors)
        if rule.get("additionalProperties") is False:
            for key in value:
                if key not in props: errors.append(f"{path}：存在未定义字段 {key}")
    elif isinstance(value,list):
        item=rule.get("items")
        if isinstance(item,dict):
            for i,v in enumerate(value): _validate_schema(v,item,root,f"{path}[{i}]",errors)
    elif isinstance(value,str):
        if "minLength" in rule and len(value)<rule["minLength"]: errors.append(f"{path}：长度小于最小值")
        if "maxLength" in rule and len(value)>rule["maxLength"]: errors.append(f"{path}：长度超过最大值 {rule['maxLength']}")
    elif isinstance(value,(int,float)) and not isinstance(value,bool):
        if "minimum" in rule and value<rule["minimum"]: errors.append(f"{path}：数值小于最小值")

def _validate_contract(data: dict[str,Any], errors: list[str]) -> None:
    if not SCHEMA_PATH.is_file():
        errors.append(f"缺少 JSON Schema 文件：{SCHEMA_PATH}")
        return
    try:
        schema=json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
        _validate_schema(data,schema,schema,"$",errors)
    except Exception as exc:
        errors.append(f"JSON Schema 校验执行失败：{exc}")

def validate_project_identity(path: Path, errors: list[str], warnings: list[str]) -> dict|None:
    data=_load_json(path,errors)
    if data is None: return None
    if not str(data.get("workspace_id","")).strip(): errors.append("项目身份：workspace_id 不能为空")
    if not str(data.get("document_version","")).strip(): errors.append("项目身份：document_version 不能为空")
    seen=set()
    for i,f in enumerate(data.get("fields",[])):
        if not isinstance(f,dict):
            errors.append(f"项目身份 fields[{i}] 必须是对象")
            continue
        k=f.get("field_key")
        if not k: errors.append(f"项目身份 fields[{i}] 缺少 field_key")
        elif k in seen: errors.append(f"项目身份 field_key 重复：{k}")
        seen.add(k); st=f.get("status"); locked=f.get("locked")
        if st not in {"confirmed","conflict","unclear","not_found"}:
            errors.append(f"项目身份 {k} 的 status 无效：{st!r}")
            continue
        if st=="confirmed":
            if locked is not True: errors.append(f"项目身份 {k}：confirmed 必须 locked=true")
            for req in ("verbatim_value","source_file","source_location"):
                if f.get(req) in (None,""): errors.append(f"项目身份 {k}：缺少 {req}")
        else:
            if locked is not False: errors.append(f"项目身份 {k}：{st} 必须 locked=false")
            if st=="not_found" and any(f.get(x) not in (None,"") for x in ("verbatim_value","normalized_value")):
                warnings.append(f"项目身份 {k}：not_found 字段仍有值，请核对来源")
    return data

def validate_project_markdown_identity(project_dir:Path,identity:dict|None,errors:list[str],warnings:list[str])->None:
    md=project_dir/"00_control"/"PROJECT.md"
    if not md.exists(): return
    text=md.read_text(encoding="utf-8")
    labels={"tender_project_code":"招标项目编号（原文锁定）","tender_project_name":"招标项目名称（原文锁定）","workspace_id":"内部 workspace_id","document_version":"文档版本"}
    vals={}
    for line in text.splitlines():
        st=line.strip()
        for k,label in labels.items():
            prefix=f"- {label}："
            if st.startswith(prefix): vals[k]=st[len(prefix):].strip()
    if identity is None:
        warnings.append("PROJECT.md 存在，但 project_identity.json 未能读取")
        return
    if vals.get("workspace_id") and vals["workspace_id"]!=identity.get("workspace_id"): errors.append("PROJECT.md 的 workspace_id 与 project_identity.json 不一致")
    if vals.get("document_version") and vals["document_version"]!=identity.get("document_version"): errors.append("PROJECT.md 的 document_version 与 project_identity.json 不一致")
    for f in identity.get("fields",[]):
        k=f.get("field_key"); label=labels.get(k)
        if not label: continue
        shown=vals.get(k,""); st=f.get("status"); canonical=str(f.get("verbatim_value") or "").strip()
        if st=="confirmed" and (not shown or shown!=canonical): errors.append(f"PROJECT.md 的{label}与已确认值不一致")
        elif st in {"not_found","unclear","conflict"} and shown and shown not in {"待从招标原文提取","待确认","存在冲突","未找到"}:
            errors.append(f"PROJECT.md 的{label}在状态为 {st} 时不应填写推测值")

def _unique(items:list,key:str,label:str,errors:list[str])->set[str]:
    values=[]
    for i,x in enumerate(items):
        if not isinstance(x,dict):
            errors.append(f"{label}[{i}] 必须是对象")
            continue
        v=x.get(key)
        if not isinstance(v,str) or not v.strip(): errors.append(f"{label}[{i}].{key} 不能为空")
        else: values.append(v)
    if len(values)!=len(set(values)): errors.append(f"{label} 中 {key} 存在重复值")
    return set(values)

def _source_ref(ref:Any,label:str,source_ids:set[str],source_files:dict[str,str],errors:list[str])->None:
    if not isinstance(ref,dict):
        errors.append(f"{label}.source_ref 必须是对象")
        return
    file=str(ref.get("file","")).strip()
    location=str(ref.get("location","")).strip()
    if not file or not location:
        errors.append(f"{label}.source_ref 必须包含 file 和 location")
        return
    sid=ref.get("source_id")
    if sid:
        if sid not in source_ids:
            errors.append(f"{label}.source_ref 引用了不存在的 source_id：{sid}")
        elif source_files.get(sid)!=file:
            errors.append(f"{label}.source_ref 的文件与 source_manifest 中 source_id={sid} 对应文件不一致")
    elif file not in set(source_files.values()):
        errors.append(f"{label}.source_ref 的文件未登记在 source_manifest：{file}")

def validate_analysis_baseline(project_dir:Path,errors:list[str],warnings:list[str])->dict|None:
    folder=project_dir/"02_requirements"; path=folder/"analysis_baseline.json"; md=folder/"technical_analysis.md"
    if not path.exists():
        errors.append("缺少 analysis_baseline.json")
        return None
    data=_load_json(path,errors)
    if data is None: return None
    _validate_contract(data,errors)
    if data.get("schema_version")!="2.0": errors.append("schema_version 必须为 2.0")
    if data.get("analysis_scope")!="technical_service_only": errors.append("analysis_scope 必须为 technical_service_only")
    if data.get("scoring_scope")!="technical_service_solution_only": errors.append("scoring_scope 必须为 technical_service_solution_only")
    for k in ("services","requirements","scoring_items","implementation_constraints","design_notes","source_manifest"):
        if not isinstance(data.get(k),list):
            errors.append(f"{k} 必须是数组")
            data[k]=[]
    ctx=data.get("project_context")
    if not isinstance(ctx,dict): errors.append("project_context 必须是对象")
    else:
        if not isinstance(ctx.get("background"),str): errors.append("project_context.background 必须是字符串")
        if not isinstance(ctx.get("project_objectives"),list): errors.append("project_context.project_objectives 必须是数组")
    services=data["services"]; reqs=data["requirements"]; scores=data["scoring_items"]; constraints=data["implementation_constraints"]; notes=data["design_notes"]; manifest=data["source_manifest"]
    service_ids=_unique(services,"service_id","services",errors); req_ids=_unique(reqs,"requirement_id","requirements",errors); score_ids=_unique(scores,"scoring_id","scoring_items",errors); source_ids=_unique(manifest,"source_id","source_manifest",errors)
    source_files={str(x.get("source_id")):str(x.get("file","")).strip() for x in manifest if isinstance(x,dict) and x.get("source_id")}
    _unique(constraints,"constraint_id","implementation_constraints",errors); _unique(notes,"note_id","design_notes",errors)
    for i,x in enumerate(manifest):
        if not isinstance(x,dict): continue
        if not str(x.get("file","")).strip(): errors.append(f"source_manifest[{i}].file 不能为空")
        if x.get("parse_status") not in {"complete","partial","failed","not_applicable"}: errors.append(f"source_manifest[{i}].parse_status 无效")
        if not isinstance(x.get("technical_sections_reviewed"),list): errors.append(f"source_manifest[{i}].technical_sections_reviewed 必须是数组")
        if x.get("parse_status") in {"partial","failed"}: warnings.append(f"技术材料未完整解析：{x.get('file',x.get('source_id'))}")
    for i,x in enumerate(services):
        if not isinstance(x,dict): continue
        if not str(x.get("service_name","")).strip(): errors.append(f"services[{i}].service_name 不能为空")
        for r in x.get("source_refs",[]): _source_ref(r,f"services[{i}]",source_ids,source_files,errors)
    for i,x in enumerate(reqs):
        if not isinstance(x,dict): continue
        if x.get("requirement_type") not in {"explicit_requirement","technical_context","implementation_constraint"}: errors.append(f"requirements[{i}].requirement_type 无效")
        if not str(x.get("original_text","")).strip() or not str(x.get("normalized_requirement","")).strip(): errors.append(f"requirements[{i}] 缺少原文或规范化要求")
        sid=x.get("service_id")
        if sid and sid not in service_ids: errors.append(f"requirements[{i}] 引用了不存在的 service_id：{sid}")
        _source_ref(x.get("source_ref"),f"requirements[{i}]",source_ids,source_files,errors)
        for score in x.get("related_scoring_ids",[]):
            if score not in score_ids: errors.append(f"requirements[{i}] 引用了不存在的 scoring_id：{score}")
    for i,x in enumerate(scores):
        if not isinstance(x,dict): continue
        kind=x.get("kind"); counts=x.get("counts_toward_total"); score=x.get("max_score")
        if kind not in {"scored","descriptive_tier","ranking_only"}: errors.append(f"scoring_items[{i}].kind 无效")
        if counts is True and kind!="scored": errors.append(f"scoring_items[{i}]：非计分项不能计入技术评分小计")
        if kind=="scored":
            if not isinstance(score,(int,float)) or isinstance(score,bool): errors.append(f"scoring_items[{i}]：真实计分项必须有数值 max_score")
            if counts is not True: errors.append(f"scoring_items[{i}]：真实计分项 counts_toward_total 必须为 true")
        if x.get("parent_scoring_id") and x["parent_scoring_id"] not in score_ids: errors.append(f"scoring_items[{i}] 引用了不存在的 parent_scoring_id")
        _source_ref(x.get("source_ref"),f"scoring_items[{i}]",source_ids,source_files,errors)
        for rid in x.get("related_requirement_ids",[]):
            if rid not in req_ids: errors.append(f"scoring_items[{i}] 引用了不存在的 requirement_id：{rid}")
        focus=x.get("technical_response_focus")
        if isinstance(focus,str) and not focus.strip(): errors.append(f"scoring_items[{i}].technical_response_focus 不能为空")
    for i,x in enumerate(constraints):
        if not isinstance(x,dict): continue
        _source_ref(x.get("source_ref"),f"implementation_constraints[{i}]",source_ids,source_files,errors)
        for sid in x.get("affected_service_ids",[]):
            if sid not in service_ids: errors.append(f"implementation_constraints[{i}] 引用了不存在的 service_id：{sid}")
    for i,x in enumerate(notes):
        if not isinstance(x,dict): continue
        if x.get("note_type") not in {"professional_suggestion","assumption","user_confirmation"}: errors.append(f"design_notes[{i}].note_type 无效")
        for sid in x.get("affected_service_ids",[]):
            if sid not in service_ids: errors.append(f"design_notes[{i}] 引用了不存在的 service_id：{sid}")
    if not md.exists(): errors.append("缺少 technical_analysis.md")
    else:
        md_text=md.read_text(encoding="utf-8").strip()
        if not md_text:
            errors.append("technical_analysis.md 为空")
        else:
            compact_md="".join(md_text.split())
            def check_markdown_value(value:Any,label:str)->None:
                if isinstance(value,str) and value.strip() and "".join(value.split()) not in compact_md:
                    warnings.append(f"technical_analysis.md 未完整呈现 JSON 中的{label}：{value[:100]}")
            for objective in ctx.get("project_objectives",[]) if isinstance(ctx,dict) else []:
                check_markdown_value(objective,"项目目标")
            for service in services:
                if not isinstance(service,dict): continue
                check_markdown_value(service.get("service_name"),"采购服务名称")
                for item in service.get("deliverables",[]) if isinstance(service.get("deliverables"),list) else []:
                    check_markdown_value(item,f"服务 {service.get('service_id')} 的明确成果")
            for item in reqs:
                if isinstance(item,dict):
                    check_markdown_value(item.get("normalized_requirement"),f"需求 {item.get('requirement_id')}")
            for item in scores:
                if isinstance(item,dict):
                    check_markdown_value(item.get("technical_response_focus"),f"评分 {item.get('scoring_id')} 的评审关注点")
            for item in constraints:
                if isinstance(item,dict):
                    check_markdown_value(item.get("normalized_constraint"),f"约束 {item.get('constraint_id')}")
            warnings.append("自动校验只能检查字段结构、来源编号/文件对应关系及阅读版关键内容覆盖；不能证明原文摘录逐字准确，也不能自动判断规范化描述是否增加事实，仍须对照原始材料人工复核。")
    summary=data.get("validation_summary")
    if not isinstance(summary,dict): errors.append("validation_summary 必须是对象")
    else:
        for k in ("technical_scope_review","source_traceability","markdown_consistency"):
            v=summary.get(k)
            if v not in {"pass","warning","fail"}: errors.append(f"validation_summary.{k} 无效")
            elif v=="fail": errors.append(f"validation_summary.{k} 为 fail")
            elif v=="warning": warnings.append(f"validation_summary.{k} 需要复核")
        if not isinstance(summary.get("warnings"),list): errors.append("validation_summary.warnings 必须是数组")
        else: warnings.extend(str(v) for v in summary["warnings"])
    identity_ref=data.get("project_identity_ref")
    if identity_ref:
        p=Path(identity_ref)
        if not p.is_absolute(): p=project_dir/p
        if not p.exists(): warnings.append(f"project_identity_ref 无法定位：{identity_ref}")
        else:
            identity_path=project_dir/"00_control"/"project_identity.json"
            if identity_path.exists():
                a=_load_json(identity_path,errors); b=_load_json(p,errors)
                if a is not None and b is not None and a.get("workspace_id")!=b.get("workspace_id"): errors.append("项目身份快照 workspace_id 与 00_control 来源不一致")
    for name in ("project_understanding.md","service_requirements.csv","technical_scoring.csv","service_requirement_map.md","technical_priority_analysis.md","technical_constraints.md","ambiguities.md","analysis_coverage_check.md"):
        if (folder/name).exists(): warnings.append(f"发现旧版分析文件 {name}；请确认是否为历史残留，本阶段正式输出只允许两个文件")
    return data

def validate_project(project_dir:Path)->tuple[list[str],list[str]]:
    errors=[]; warnings=[]; identity_path=project_dir/"00_control"/"project_identity.json"; identity=None
    if identity_path.exists(): identity=validate_project_identity(identity_path,errors,warnings)
    else: warnings.append("未发现 00_control/project_identity.json")
    validate_project_markdown_identity(project_dir,identity,errors,warnings)
    validate_analysis_baseline(project_dir,errors,warnings)
    return errors,warnings

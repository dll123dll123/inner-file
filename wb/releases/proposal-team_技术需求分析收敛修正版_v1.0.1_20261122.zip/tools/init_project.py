from pathlib import Path
import argparse
import json
import re
import shutil
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = ROOT / "projects" / "_template"


def write_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description="Create a project workspace from the proposal template.")
    parser.add_argument("project_id", help="Stable internal workspace ID, e.g. PRJ-2026-001")
    parser.add_argument("--name", default="", help="Human-readable internal project name")
    parser.add_argument("--document-version", default="V1.0", help="Proposal document version, not tender project code")
    args = parser.parse_args()

    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{1,63}", args.project_id):
        raise SystemExit("Invalid project_id. Use 2-64 letters, digits, dot, underscore or hyphen.")
    if not args.document_version.strip():
        raise SystemExit("document-version must not be empty.")

    target = ROOT / "projects" / args.project_id
    if target.exists():
        raise SystemExit(f"Target already exists: {target}. No files changed.")
    if not TEMPLATE.is_dir():
        raise SystemExit(f"Project template not found: {TEMPLATE}")

    shutil.copytree(TEMPLATE, target)
    now = datetime.now(timezone.utc).isoformat()

    state_path = target / "00_control" / "STATE.json"
    state = json.loads(state_path.read_text(encoding="utf-8"))
    state["project_id"] = args.project_id
    state["project_name"] = args.name
    state["updated_at"] = now
    write_json(state_path, state)

    tasks_path = target / "00_control" / "TASKS.json"
    tasks = json.loads(tasks_path.read_text(encoding="utf-8"))
    tasks["project_id"] = args.project_id
    write_json(tasks_path, tasks)

    identity_path = target / "00_control" / "project_identity.json"
    identity = json.loads(identity_path.read_text(encoding="utf-8"))
    identity["schema_version"] = "1.2.2"
    identity["workspace_id"] = args.project_id
    identity["document_version"] = args.document_version
    # A newly created workspace has no verified tender facts yet.
    # Do not lock placeholder / not-found values.
    for field in identity.get("fields", []):
        if field.get("status") != "confirmed":
            field["locked"] = False
        if field.get("status") == "not_found":
            field["verbatim_value"] = None
            field["normalized_value"] = None
            field["source_file"] = ""
            field["source_location"] = ""
    write_json(identity_path, identity)

    project_doc = target / "00_control" / "PROJECT.md"
    content = project_doc.read_text(encoding="utf-8")
    content = content.replace("- 招标项目编号（原文锁定）：", "- 招标项目编号（原文锁定）：待从招标原文提取", 1)
    content = content.replace("- 招标项目名称（原文锁定）：", "- 招标项目名称（原文锁定）：待从招标原文提取", 1)
    content = content.replace("- 内部 workspace_id：", f"- 内部 workspace_id：{args.project_id}", 1)
    content = content.replace("- 文档版本：", f"- 文档版本：{args.document_version}", 1)
    project_doc.write_text(content, encoding="utf-8")

    print(f"Created project workspace: {target}")
    print(f"Initialized project identity: {identity_path}")
    print("Tender identity fields remain unlocked until source-backed confirmation.")

if __name__ == "__main__":
    main()

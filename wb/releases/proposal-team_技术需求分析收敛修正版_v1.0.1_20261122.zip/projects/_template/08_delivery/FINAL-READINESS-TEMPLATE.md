# 技术服务方案交付就绪检查报告

## 基本信息
- 招标项目名称：
- 招标项目编号：
- 项目工作区 ID：
- 文档版本：
- 检查日期：

## 一、技术方案交付状态
| 检查维度 | 状态 | 依据文件/检查结果 | 未完成事项 |
|---|---|---|---|
| 技术需求覆盖 | PASS / PASS_WITH_CONDITIONS / BLOCKED / FAILED | | |
| 技术方案评分响应 | PASS / PASS_WITH_CONDITIONS / BLOCKED / FAILED | | |
| 专业设计与正文一致性 | PASS / PASS_WITH_CONDITIONS / BLOCKED / FAILED | | |
| 企业技术事实与证据 | PASS / PASS_WITH_CONDITIONS / BLOCKED / FAILED | | |
| 技术审核 | PASS / PASS_WITH_CONDITIONS / BLOCKED / FAILED | | |
| DOCX/PDF 文档发布 | PASS / PASS_WITH_CONDITIONS / BLOCKED / FAILED | | |

## 二、技术问题与阻断事项
| blocker_id | 技术依据 | 缺失/未确认事项 | 影响 | 责任人 | 解除条件 | 状态 |
|---|---|---|---|---|---|---|

## 三、最终判断
- technical_document_status：
- review_status：
- document_publish_status：
- technical_proposal_readiness：READY / BLOCKED / NOT_VERIFIABLE

只有技术需求和评分响应完成、Critical 与未关闭 Major 问题已处理或经用户明确接受、文档发布检查通过，才能将技术服务方案标记为 READY。

本报告只判断技术服务方案是否完成，不判断完整投标文件是否具备提交条件。企业资格、人员选择、商务报价、保证金、签章和递交事项由用户通过其他流程处理。

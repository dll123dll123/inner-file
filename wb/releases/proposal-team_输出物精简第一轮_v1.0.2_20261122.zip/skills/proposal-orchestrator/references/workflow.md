# 技术服务方案工作流与阶段门槛 V1.2.3

阶段编号必须与 STATE、TASKS、执行日志和交付报告一致。系统只负责技术服务方案，不负责完整投标文件的商务、资格、报价和递交审查。

## 阶段 0：项目初始化与技术材料定位
识别项目输入文件并只读保存原件。只定位客户项目背景、采购技术服务、具体技术要求、技术方案评分、必要技术实施约束和用户提供的技术参考。不得把人员资格/评分、商务、企业资信、报价、合同商务或投标程序纳入分析。创建项目控制文件、TASKS/STATE 和身份引用。

## 阶段 1：技术服务需求理解
委派 `requirement_analyst`，只执行技术服务需求分析。必须且只输出：
- `02_requirements/analysis_baseline.json`：唯一权威结构化数据源，供后续所有 Agent 使用。
- `02_requirements/technical_analysis.md`：由 JSON 派生的人工阅读版本。

严格排除全部商务、企业资格/资信、企业业绩、人员选拔/个人资质/人员评分、报价付款、合同商务及投标程序。混合条款只保留直接影响技术服务内容、实施、质量或交付的部分。不生成 CSV、需求映射、优先级/深度矩阵、独立待确认事项或覆盖率报告。

执行 `python tools/validate_analysis.py <project_dir>`；错误阻断阶段完成。

门槛：客户项目背景、实际采购的技术服务、具体技术要求、技术服务方案评分及必要技术实施约束均准确提取，关键内容可追溯。只核验技术范围，不声称完成整本招标文件审查。

## 阶段 2：企业技术能力与证据整理
委派 knowledge_curator，只整理与相关技术服务有关的已验证技术能力、工具/产品能力和技术交付案例；人员选择、个人资质核验和人员评分不属于专家团职责。排除营业执照、财务、信用、公司资质、管理体系认证和一般商务业绩。区分已验证、待核验、拟设计和缺失。
正式输出仅为 03_knowledge/evidence_catalog.json 和由 JSON 派生的 03_knowledge/evidence_catalog.md。JSON 集中保存能力、产品工具、案例、证据记录、需求/评分关联及证据缺口，不生成独立 CSV 台账或 evidence_gaps.md。

## 阶段 3：专项服务专业设计
委派 solution_architect，根据 analysis_baseline.json 和企业技术证据，逐项设计采购服务并拆解具体技术工作项，说明目标、对象、方法、步骤、判断依据、工具/数据/权限、角色、风险控制、输出及验证闭环。服务管理流程和人员组织是支撑，不得取代技术内容。
正式输出仅为 04_design/solution_blueprint.json 和由其派生的 04_design/solution_blueprint.md。设计决策、假设风险、服务间关系及需求/评分追溯纳入两份成果。必要图表源文件放入 diagram_assets/。不默认生成独立专项设计文档、架构/流程目录、决策/风险报告或追溯 CSV。
门槛：核心服务都有具体工作项和专业方法；不同服务不套用同一泛化流程；技术评分重点落实到设计；企业事实与拟设计方案分开。

## 阶段 4：正式目录与章节任务规划
委派 `outline_planner`，以已批准的服务设计蓝图为核心输入。结构通常为“项目理解与总体思路—各项专项服务方案—其他必要支撑内容”，具体按项目调整。不得默认将项目启动、项目实施、项目管理、项目验收分别设为主体章节。章节任务书必须列明具体设计工作项、需求/评分映射、边界和验收标准。正式输出仅为 05_outline/outline.md 和 05_outline/chapter_plan.json；覆盖和依赖关系纳入 JSON，不生成 coverage_map.csv 或 dependency_map.md。

## 阶段 5：技术正文写作
按章节任务书分配 撰写专家。主体围绕客户采购的每项服务充分展开技术内容；保障性内容按需组织在后部或服务章节内部。不得空话重复、不得无依据承诺、不得为了简短删减有价值的技术内容。

## 阶段 6：独立技术方案审核
审核专家检查技术需求覆盖、技术评分、专业工作项、技术深度、证据真实性、服务边界、重复和一致性。商务资格、保证金、有效期、报价和递交格式不属于本阶段范围。
正式输出仅为 07_reviews/review_findings.json 和由 JSON 派生的 07_reviews/review_report.md。JSON 是唯一结构化问题清单；无问题时也生成空 findings 数组，不另生成 CSV 或重复汇总。

## 阶段 7：定向返工与整本技术方案集成验收
按 review_findings.json 中的问题定向返工，并在同一问题记录中更新状态和复核结果。核验服务范围、人员、周期、方法、职责、交付物、术语、评分映射、图表和跨章节一致性。仅生成 07_reviews/integration_report.md，不另建返工清单或问题汇总文件。未确认事项不得被写成已确认事实。

## 阶段 8：技术方案文档发布
只在 08_delivery/ 保存最终技术服务方案 DOCX 和用户需要的 PDF。临时文件、发布日志和单独发布检查报告不作为正式输出；发布检查结果通过任务回传和项目状态记录。检查章节顺序、标题、表格、图表、页眉页脚和格式。不得将发布成功表述为完整投标文件已就绪。

## 阶段 9：技术方案交付就绪
只检查技术服务方案内容、技术评分覆盖、审核状态、未决技术事项和文档发布状态。输出 `08_delivery/final_readiness_report.md`。不审查完整投标包的企业资格、商务、报价、保证金、签章和递交要求。

## 单步执行规则
用户明确要求只分析、只设计、只规划目录或只写指定章节时，仅执行对应阶段并在成果保存、状态更新和验收后停止。不得自动进入后续阶段。只有用户明确要求完整方案或全流程执行时，才自动继续。

## 项目写入安全与状态持久化
每次写入前执行 `tools/project_guard.py check-path`，实际写入统一通过 `tools/project_guard.py write`。角色目录白名单：requirement_analyst→02_requirements；knowledge_curator→03_knowledge；solution_architect→04_design；outline_planner→05_outline；proposal_writer→06_chapters；proposal_reviewer→07_reviews；word_publisher→08_delivery；coordinator→00_control/02_requirements/07_reviews/08_delivery。`01_input/` 只读。若运行环境允许绕过 Guard 直接写入，报告隔离未生效。

任务委派前登记 `ready`，执行中 `in_progress`，验收后更新完成/阻塞/失败状态。阶段完成必须有实际输出文件和验证证据。中断恢复执行 `project_guard.py recover`，遗留任务重新验收，不自动判完成。

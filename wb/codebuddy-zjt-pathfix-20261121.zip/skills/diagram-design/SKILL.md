---
name: diagram-design
description: 用于技术服务方案需要架构图、流程图、责任矩阵或数据流图时，当用户要求画技术图或使用 Mermaid 时使用。Use when a technical service proposal needs meaningful architecture, workflow, deployment, responsibility, data-flow, timeline, or relationship diagrams rather than decorative cards.
---

# WorkBuddy 适配说明

- 本 Skill 保留 Codex V1.2.3 的全部专业方法、执行步骤、质量标准和输出契约；以下正文未因平台迁移而删减。
- 参考资料读取指引：执行本 Skill 时，必须按任务需要读取本目录 `references/` 下的适用文件，不得仅凭本文件摘要替代模板、清单或方法。适用文件：`references/diagram-patterns.md`、`references/mermaid-conventions.md`。
- 工具路径约定：所有脚本位于专家团安装目录 `<package_root>/tools/`，必须通过该目录的绝对路径调用；项目输入、状态和成果统一使用 `<project_dir>/` 绝对路径。新项目位于 `<workspace_root>/projects/<project_id>`。不得从脚本位置推导项目目录，也不得把专家团安装目录当作项目目录。
- 平台专属文件：原 `agents/openai.yaml` 仅作为 V1.2.3 基线保存在 `source-v1.2.3/`，WorkBuddy 不读取；其展示名称、简短说明与隐式触发信息已并入本文件 description。
- 质量边界：不得为了适配平台减少输出文件、降低技术要求或跳过验收条件。


# 工具路径与项目输出

调用 `render_proposal_diagrams.mjs` 或 `render_proposal_v11_diagrams.mjs` 时，必须使用 `<package_root>/tools/` 下的脚本绝对路径，并显式传入 `--project-dir "<project_dir>"`。DOT、SVG、PNG 等源文件与渲染结果必须保存在当前项目目录，不得使用脚本默认项目路径。

# 目标
把复杂技术关系转化为准确、易读、可复核的图形。图形不是装饰，也不是把段落机械变成方框。

# 先判断是否需要图
适合图形：系统组件与连接关系；服务执行流程和判断路径；数据流、控制流和信任边界；部署拓扑和网络区域；组织职责和协同关系；实施阶段与里程碑；多维能力映射。
不适合图形：单一事实或短句；没有明确关系的文字堆叠；只为填充页面的卡片；图形无法比文字更清楚表达的内容。

# 设计步骤
1. 明确图形要回答的一个核心问题。
2. 确定图形类型：架构、流程、部署、数据流、泳道、矩阵、时间线或关系图。
3. 提取节点、分组、连接、方向、条件和边界。
4. 先验证技术关系，再考虑视觉排版。
5. 控制节点数量和文字长度，避免密集交叉线。
6. 使用一致的术语和图例。
7. 标注信任边界、人工审批、异常分支和外部依赖（适用时）。
8. 与正文核对，确保图文一致。
9. 输出源文件，并说明图中表达的关系和未覆盖范围。

# 视觉原则
- 简洁、专业、层级清楚。
- 优先使用结构、方向、分组、泳道、边界和连线表达逻辑。
- 避免所有节点都做成相同卡片。
- 颜色用于区分角色、状态或风险，不做装饰性渐变。
- 不使用含糊箭头或没有含义的连线。
- 不让图形暗示不存在的系统集成或自动化能力。
- 图内文字与正文术语一致。
- 面向正式客户文档时，确保黑白打印仍可辨认。

# 输出
默认输出 Mermaid 源文件（.mmd）或当前环境明确支持的可编辑源格式。只有确认渲染工具可用时才生成 PNG/SVG。渲染后检查字体、连线、裁切、布局和文字重叠。
文件命名：`<chapter_id>_<diagram_topic>.<ext>`。图形引用路径使用相对路径。

# 验收
图形必须能回答核心问题；节点和连线含义明确；无未经证实的组件、接口或流程；与正文一致；可编辑源文件已保存。

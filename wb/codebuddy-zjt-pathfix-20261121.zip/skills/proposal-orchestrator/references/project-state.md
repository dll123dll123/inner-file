# 项目状态文件规范

## 项目路径身份
新项目的 `00_control/project_identity.json` 必须记录 `workspace_root` 和 `project_dir` 两个绝对路径。新项目目录固定为 `<workspace_root>/projects/<project_id>`。恢复项目时优先读取并核验路径字段，不得根据专家团安装目录或工具脚本位置重新推导项目目录。旧版项目缺少路径字段时按原项目位置兼容，不自动迁移。

## STATE.json
保存项目当前阶段和总体状态。只记录当前事实，不写长篇分析。
- schema_version
- project_id
- project_name
- current_phase
- overall_status：not_started / in_progress / blocked / completed
- phase_status
- last_completed_task
- blocked_tasks
- approved_decision_refs
- updated_at

## TASKS.json
每项任务使用稳定 task_id，包含 title、agent_role、status、inputs、outputs、dependencies、acceptance_criteria、validation、owner、created_at、updated_at。

## 更新规则
1. 任务开始时更新为 in_progress。
2. 完成后先验证输出文件，再更新状态。
3. blocked 必须说明阻塞原因和解除条件。
4. 不删除历史任务；变更用新任务或追加变更记录。
5. 时间使用带时区的 ISO 8601。
6. 不用估算百分比伪造进度。
7. 招标分析的输入文件、版本和内容哈希（如可获得）应记录；输入未变化时复用已验收成果，不重复完整分析。
8. 新增澄清/补遗或替换招标文件时，只重跑受影响的需求、评分和内容规划，并记录影响范围。

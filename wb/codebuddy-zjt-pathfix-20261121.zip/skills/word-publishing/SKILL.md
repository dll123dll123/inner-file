---
name: word-publishing
description: 用于将已审核章节组装为 Word 技术服务方案并检查文档质量，当用户要求生成 DOCX、套用模板或发布检查时使用。Use when assembling approved Markdown proposal chapters into a customer-ready Word document, applying a supplied DOCX template, checking headings, numbering, tables, figures, references, and document integrity.
---

# WorkBuddy 适配说明

- 本 Skill 保留 Codex V1.2.3 的全部专业方法、执行步骤、质量标准和输出契约；以下正文未因平台迁移而删减。
- 参考资料读取指引：执行本 Skill 时，必须按任务需要读取本目录 `references/` 下的适用文件，不得仅凭本文件摘要替代模板、清单或方法。适用文件：`references/docx-preflight.md`。
- 工具路径约定：所有脚本位于专家团安装目录 `<package_root>/tools/`，必须通过该目录的绝对路径调用；项目输入、状态和成果统一使用 `<project_dir>/` 绝对路径。新项目位于 `<workspace_root>/projects/<project_id>`。不得从脚本位置推导项目目录，也不得把专家团安装目录当作项目目录。
- 平台专属文件：原 `agents/openai.yaml` 仅作为 V1.2.3 基线保存在 `source-v1.2.3/`，WorkBuddy 不读取；其展示名称、简短说明与隐式触发信息已并入本文件 description。
- 质量边界：不得为了适配平台减少输出文件、降低技术要求或跳过验收条件。


# 工具路径与项目输出

调用 `build_proposal_docx.py` 或 `build_proposal_v11_docx.py` 时，必须使用 `<package_root>/tools/` 下的脚本绝对路径，并显式传入 `--project-dir "<project_dir>"`。生成的 DOCX、PDF 和发布日志必须保存在当前项目 `08_delivery/`，不得使用脚本默认项目路径。

# 目标
将已审核的章节和图形资源整理为结构完整、可编辑、格式稳定的 Word 技术服务方案。发布流程不得改变已批准的技术内容。

# 前置条件
- 章节任务状态已达到发布门槛；
- Critical 和未关闭 Major 问题已处理或经用户明确接受；
- 章节顺序已批准；
- 已提供 Word 模板时，必须先检查模板结构和样式；
- 图形源文件及引用资源存在；
- 术语和编号已统一。

# 发布步骤
1. 清点最终章节清单，按批准目录排序。
2. 检查章节文件、图片和表格资源是否齐全。
3. 检查标题层级、编号和交叉引用。
4. 检查用户提供的 Word 模板：页面尺寸、页边距、页眉页脚、标题样式、正文样式、目录、表格样式。
5. 选择当前环境已安装且可用的 DOCX 处理工具；优先复用已有项目工具。
6. 将 Markdown 内容映射到 Word 样式，不把 Markdown 标记原样留在正文。
7. 插入图表并保持比例、清晰度和相对位置。
8. 生成目录（如模板要求），更新页码和交叉引用。
9. 检查表格分页、标题孤行、图片裁切、字体缺失、空白页和编号连续性。
10. 保存到 `08_delivery/`，保留中间文件和发布日志。
11. 重新打开或解析生成的 DOCX，验证正文、标题、表格、图片和目录确实存在。
12. 输出发布检查报告。

# 模板保护
不擅自改变用户模板的 Logo、页眉页脚、品牌色和页面设置。不为了美观大幅改写已批准内容。未经授权不覆盖原始模板或已发布版本。新版本使用新文件名或版本目录。

# 工具策略
优先使用已有 DOCX 工具和模板。如需编写 Python 工具，先检查依赖和现有实现。只有当前环境确实可用时才使用 python-docx 等库。不假定 Pandoc、LibreOffice 或特定渲染器已安装。如果无法可靠生成目录或保持模板格式，明确报告限制，不伪称保真。

# 发布验收
文档发布通过只表示技术文件的组装和文档质量检查通过，不代表资格、商务、报价、人员、业绩、证书或其他投标附件齐全，也不代表可以提交。阶段 9 的 `final_readiness_report.md` 由 Coordinator 单独生成并作最终提交判断。

文件可打开；章节顺序正确；标题层级和编号正确；目录与正文一致；表格、图片和图注完整；页眉页脚符合模板；无明显乱码、裁切、空白页和格式漂移；发布报告记录所执行的检查及未通过项。

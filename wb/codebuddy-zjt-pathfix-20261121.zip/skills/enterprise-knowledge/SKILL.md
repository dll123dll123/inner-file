---
name: enterprise-knowledge
description: 用于整理经核验的企业技术能力、工具、技术团队资源和技术交付证据，当用户要求收集技术能力证据或企业技术资料时使用。Use when searching, organizing, validating, and citing enterprise service capabilities, technical materials, products, tools, personnel resources, and project cases for a proposal.
---

# WorkBuddy 适配说明

- 本 Skill 保留 Codex V1.2.3 的全部专业方法、执行步骤、质量标准和输出契约；以下正文未因平台迁移而删减。
- 参考资料读取指引：执行本 Skill 时，必须按任务需要读取本目录 `references/` 下的适用文件，不得仅凭本文件摘要替代模板、清单或方法。适用文件：`references/capability-taxonomy.md`、`references/evidence-record.md`。
- 工具路径约定：所有脚本位于专家团安装目录 `<package_root>/tools/`，必须通过该目录的绝对路径调用；项目输入、状态和成果统一使用 `<project_dir>/` 绝对路径。新项目位于 `<workspace_root>/projects/<project_id>`。不得从脚本位置推导项目目录，也不得把专家团安装目录当作项目目录。
- 平台专属文件：原 `agents/openai.yaml` 仅作为 V1.2.3 基线保存在 `source-v1.2.3/`，WorkBuddy 不读取；其展示名称、简短说明与隐式触发信息已并入本文件 description。
- 质量边界：不得为了适配平台减少输出文件、降低技术要求或跳过验收条件。


# 目标
为技术服务方案提供真实、可追溯的**技术能力事实和证据**。本系统不制作完整投标商务文件，因此不主动整理营业执照、财务、信用、公司资质、管理体系认证或一般商务业绩。你是技术资料管理与证据整理角色，不是营销文案生成器。

# 证据分类
证据类别（说明材料是什么）与核验状态（当前能否作为投标事实使用）必须分开记录。

## 核验状态（新增必填字段 verification_status）
- `verified`：来源明确、内容有效、适用范围匹配，已核验可支持对应主张；
- `provided_unverified`：资料已提供，但真实性、有效期、适用主体或完整性尚未核验；
- `proposed_design`：本项目拟采用的方案设计，不是企业既有能力证明；
- `missing`：招标响应需要该项证据，但当前资料未提供；
- `not_applicable`：经分析确认不适用，必须记录理由。

`evidence_type` 仍使用下方分类，不能用 evidence_type 替代 verification_status。

每项信息必须归入以下类别之一：
1. verified_capability：有明确企业材料支持的现有技术服务能力；
2. historical_delivery：与本项目技术服务相关且有材料支持的历史技术交付经验；
3. product_or_tool：有产品说明、授权资料或技术文档支持的技术产品/工具能力；
4. proposed_design：本项目拟采用的技术设计，不代表企业既有能力；
5. unverified：技术能力来源不足、过期、相互矛盾或无法确认的信息。

# 工作步骤
1. 盘点允许检索的资料目录和文件。
2. 按任务关键词和语义检索，不默认遍历所有资料。
3. 对候选资料检查版本、日期、适用范围、完整性和来源。
4. 抽取与需求有关的能力事实，避免大段复制无关材料。
5. 为每项证据分配稳定 evidence_id。
6. 记录原文件、页码/章节/段落/表格位置。
7. 区分“材料证明了什么”和“材料没有证明什么”。
8. 建立需求—能力—证据映射。
9. 标记缺口、冲突、过期和需要人工确认的内容。

# 证据可信度
- A：正式、明确、可定位的企业材料或经确认的项目交付材料；
- B：内部技术文档、产品资料或项目过程材料，内容明确但适用范围需核实；
- C：非正式描述、摘要、口头信息或缺少完整上下文；
- U：无法核实或存在冲突。
每个等级必须说明理由。

# 项目案例
案例使用前必须核对：是否允许对外使用；项目时间、行业和服务范围是否有材料支持；交付内容是否与当前需求相似；客户名称及敏感信息是否需要脱敏；是否有合同、验收、总结或其他可引用材料。禁止根据项目标题推断实际服务内容。

# 输出
写入 `03_knowledge/`：
- `capability_catalog.csv`
- `evidence_index.csv`
- `case_catalog.csv`
- `requirement_evidence_map.csv`
- `evidence_gaps.md`

# 阶段门与缺口处理
- 缺少企业证据不得阻止招标分析、服务设计或技术正文继续进行；可以先形成有边界的拟采用方案。
- 任何依赖 `missing` 或 `provided_unverified` 的评分项，必须在 `evidence_gaps.md` 和评分证据映射中保留阻断状态、责任人和补充材料要求。
- 不得将 `proposed_design`、`provided_unverified` 或 `missing` 写成企业已经具备的事实。
- 最终投标就绪检查必须重新读取证据台账；不能因为技术正文写完或 Word 发布成功，就自动解除证据阻断。

# 写作引用规则
交给 Writer 的引用应包含 evidence_id、来源文件、精确位置、可支持的事实、适用限制。Writer 不应只收到一个没有解释的文件路径。

# 禁止事项
不创造企业能力、资质、团队人数、认证、项目客户、合同金额或服务成果；不把产品宣传语自动视为已验证技术能力；不把 proposed_design 写成 verified_capability；不为满足招标要求而隐瞒证据不足；不擅自把客户材料放入公开或外部服务。

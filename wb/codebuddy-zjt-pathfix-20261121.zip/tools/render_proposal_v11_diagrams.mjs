import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const { instance } = require("@viz-js/viz");
const sharp = require("sharp");

const projectArgIndex = process.argv.indexOf("--project-dir");
const projectArg = projectArgIndex >= 0 ? process.argv[projectArgIndex + 1] : null;
if (!projectArg || projectArg.startsWith("--") || !path.isAbsolute(projectArg)) {
  console.error("Usage: node <renderer.mjs> --project-dir <absolute-project-dir>");
  process.exit(2);
}
const root = path.resolve(projectArg);
const identityPath = path.join(root, "00_control", "project_identity.json");
if (!fs.existsSync(identityPath)) {
  throw new Error(`Project identity not found under selected project directory: ${root}`);
}
const identity = JSON.parse(fs.readFileSync(identityPath, "utf8"));
if (identity.workspace_id !== path.basename(root)) {
  throw new Error("Project directory name does not match project_identity.workspace_id");
}
if (identity.project_dir && path.resolve(identity.project_dir) !== root) {
  throw new Error("project_identity.project_dir does not match --project-dir");
}

const graphDefaults = `
  graph [bgcolor="white", pad="0.25", nodesep="0.38", ranksep="0.55", fontname="Microsoft YaHei", fontsize=12];
  node [shape="box", style="rounded,filled", fontname="Microsoft YaHei", fontsize=12, color="#6B7280", penwidth=1.1, margin="0.14,0.09"];
  edge [fontname="Microsoft YaHei", fontsize=10, color="#4B5563", arrowsize=0.7];
`;

const diagrams = [
  {
    name: "01_overall_service_architecture",
    dir: "04_design/architecture",
    dot: `
digraph architecture {
  ${graphDefaults}
  rankdir=TB;
  compound=true;
  subgraph cluster_customer {
    label="客户现有平台与授权边界"; color="#D1D5DB"; style="rounded,dashed"; fontcolor="#374151";
    C1 [label="业务系统、资产、\\n账号与日志", fillcolor="#F3F4F6"];
    C2 [label="已有安全平台\\n告警、终端、网络、漏洞与资产", fillcolor="#F3F4F6"];
    C3 [label="工单、联系人、变更\\n与应急预案", fillcolor="#F3F4F6"];
  }
  subgraph cluster_access {
    label="受控访问与数据交换"; color="#7DD3FC"; style="rounded"; fontcolor="#0C4A6E";
    A1 [label="个人账号、堡垒机\\n或只读视图", fillcolor="#E0F2FE", color="#0369A1"];
    A2 [label="客户批准的接口、\\n导出或工单", fillcolor="#E0F2FE", color="#0369A1"];
    A3 [label="受控终端与\\n批准的数据存储位置", fillcolor="#E0F2FE", color="#0369A1"];
  }
  subgraph cluster_ops {
    label="统一服务台与六能力域"; color="#86EFAC"; style="rounded"; fontcolor="#14532D";
    S1 [label="统一服务台\\n受理、分派、跟踪、升级、归档", fillcolor="#E8F5E9", color="#2E7D32"];
    S2 [label="资产与数据源基线", fillcolor="#E8F5E9", color="#2E7D32"];
    S3 [label="日常监测研判与工单", fillcolor="#E8F5E9", color="#2E7D32"];
    S4 [label="检查评估与漏洞闭环", fillcolor="#E8F5E9", color="#2E7D32"];
    S5 [label="重保值守、情报与溯源", fillcolor="#E8F5E9", color="#2E7D32"];
    S6 [label="应急响应与业务连续性", fillcolor="#E8F5E9", color="#2E7D32"];
    S7 [label="培训、演练与知识转移", fillcolor="#E8F5E9", color="#2E7D32"];
  }
  subgraph cluster_gov {
    label="治理、质量与合规"; color="#FDBA74"; style="rounded"; fontcolor="#7C2D12";
    G1 [label="项目负责人与技术负责人", fillcolor="#FFF7ED", color="#C2410C"];
    G2 [label="客户授权人与生产审批", fillcolor="#FFF7ED", color="#C2410C"];
    G3 [label="质量、满意度与整改", fillcolor="#FFF7ED", color="#C2410C"];
    G4 [label="保密、权限、审计与产品审查", fillcolor="#FFF7ED", color="#C2410C"];
  }
  C1 -> A1; C2 -> A1; C2 -> A2; C3 -> A2;
  A1 -> S3; A2 -> S4; A3 -> S7; C3 -> S1;
  S1 -> S2; S1 -> S3; S1 -> S4; S1 -> S5; S1 -> S6; S1 -> S7;
  S2 -> S3; S2 -> S4; S3 -> S6; S5 -> S6;
  S3 -> G3; S4 -> G3; S6 -> G3; S7 -> G3;
  G1 -> S1; G2 -> S6; G4 -> A1; G4 -> A3;
}
`,
  },
  {
    name: "02_service_organization",
    dir: "04_design/architecture",
    dot: `
digraph organization {
  ${graphDefaults}
  rankdir=LR;
  CUST [label="客户项目负责人、\\n安全负责人与业务接口", fillcolor="#F3F4F6"];
  PM [label="项目负责人", fillcolor="#FFF7ED", color="#C2410C"];
  TL [label="技术负责人", fillcolor="#FFF7ED", color="#C2410C"];
  SD [label="服务台与现场负责人", fillcolor="#E0F2FE", color="#0369A1"];
  MON [label="监测研判工程师", fillcolor="#E0F2FE", color="#0369A1"];
  VUL [label="漏洞与加固工程师", fillcolor="#E0F2FE", color="#0369A1"];
  MAJ [label="重保专家", fillcolor="#E0F2FE", color="#0369A1"];
  IR [label="应急与溯源人员", fillcolor="#E0F2FE", color="#0369A1"];
  TR [label="培训讲师与赛事支撑", fillcolor="#E0F2FE", color="#0369A1"];
  QA [label="质量保密负责人", fillcolor="#FFF7ED", color="#C2410C"];
  POOL [label="人员备份与专业资源池", fillcolor="#E8F5E9", color="#2E7D32", style="rounded,dashed"];
  CUST -> PM [label="目标、授权、验收"];
  CUST -> TL [label="安全审批与事件确认"];
  PM -> SD; PM -> TL; PM -> QA;
  TL -> MON; TL -> VUL; TL -> MAJ; TL -> IR; TL -> TR;
  SD -> MON [label="受理与分派"]; SD -> VUL [label="风险任务"]; SD -> MAJ [label="重保任务"];
  SD -> IR [label="事件升级"]; SD -> TR [label="培训任务"];
  MON -> SD [label="事件与证据"]; VUL -> SD [label="风险与复测"];
  MAJ -> SD [label="值守与复盘"]; IR -> SD [label="处置与恢复"]; TR -> SD [label="课程与测评"];
  QA -> PM [label="抽查与整改"]; POOL -> SD [label="批准后补充", style=dashed];
}
`,
  },
  {
    name: "01_daily_operations_loop",
    dir: "04_design/service_workflows",
    dot: `
digraph daily {
  ${graphDefaults}
  rankdir=TB;
  A [label="班前交接\\n未结事件、变更、人员与客户要求", fillcolor="#E8F5E9", color="#2E7D32"];
  B [label="确认任务单和工作时段", fillcolor="#E0F2FE", color="#0369A1"];
  C [label="接收告警、请求或客户报告\\n建立统一工单并分派", fillcolor="#E0F2FE", color="#0369A1"];
  D [label="属于事件、风险还是普通任务？", shape="diamond", fillcolor="#FFF7ED", color="#C2410C"];
  E [label="转事件初筛与研判\\n见C05", fillcolor="#E0F2FE", color="#0369A1"];
  F [label="转安全评估与漏洞闭环\\n见C06", fillcolor="#E0F2FE", color="#0369A1"];
  G [label="执行检查、运维、加固或报告任务", fillcolor="#E0F2FE", color="#0369A1"];
  H [label="更新状态、证据、责任和时限", fillcolor="#E0F2FE", color="#0369A1"];
  I [label="达到关闭条件？", shape="diamond", fillcolor="#FFF7ED", color="#C2410C"];
  J [label="班后交接、日报周报和问题台账", fillcolor="#E8F5E9", color="#2E7D32"];
  K [label="月度复盘与流程优化", fillcolor="#E8F5E9", color="#2E7D32"];
  A -> B -> C -> D;
  D -> E [label="事件"]; D -> F [label="风险"]; D -> G [label="普通任务"];
  E -> H; F -> H; G -> H; H -> I;
  I -> J [label="是或记录承接"];
  I -> H [label="否：保留未结"];
  J -> K;
  {rank=same; E; F; G;}
}
`,
  },
  {
    name: "02_monitoring_triage_workflow",
    dir: "04_design/service_workflows",
    dot: `
digraph triage {
  ${graphDefaults}
  rankdir=TB;
  A [label="告警、日志、投诉或客户报告", fillcolor="#F3F4F6"];
  B [label="是否在授权范围？", shape="diamond", fillcolor="#FFF7ED", color="#C2410C"];
  X [label="说明边界并转客户负责人", fillcolor="#E8F5E9", color="#2E7D32"];
  C [label="建立工单\\n记录原始时间、来源和数据", fillcolor="#E0F2FE", color="#0369A1"];
  D [label="去重、归一\\n关联资产、账号与历史活动", fillcolor="#E0F2FE", color="#0369A1"];
  E [label="证据是否充分？", shape="diamond", fillcolor="#FFF7ED", color="#C2410C"];
  F [label="继续观察、补充证据\\n或标记不确定", fillcolor="#E8F5E9", color="#2E7D32"];
  G [label="按C10唯一P1-P4基线初筛", fillcolor="#E0F2FE", color="#0369A1"];
  H [label="是否确认为安全事件？", shape="diamond", fillcolor="#FFF7ED", color="#C2410C"];
  I [label="记录结论并设置再评估条件", fillcolor="#E8F5E9", color="#2E7D32"];
  J [label="转应急响应并保留事件号\\n见C10", fillcolor="#E0F2FE", color="#0369A1"];
  K [label="复盘、规则优化和归档", fillcolor="#E8F5E9", color="#2E7D32"];
  A -> B; B -> X [label="否"]; B -> C [label="是"];
  C -> D -> E; E -> F [label="否"]; E -> G [label="是"];
  G -> H; H -> I [label="否"]; H -> J [label="是"]; I -> K; J -> K;
  G -> J [label="P1或重大升级", style=dashed];
}
`,
  },
  {
    name: "03_vulnerability_remediation_loop",
    dir: "04_design/service_workflows",
    engine: "neato",
    dot: `
digraph vulnerability {
  ${graphDefaults}
  graph [size="10.2,4.2!", splines="true", overlap="false"];
  node [width=1.55, height=0.62, fixedsize=false, pin=true];
  A [label="确认资产、授权\\n与测试窗口", pos="1,4!", fillcolor="#E8F5E9", color="#2E7D32"];
  B [label="巡检、扫描、配置核查\\n或人工发现", pos="3.1,4!", fillcolor="#E0F2FE", color="#0369A1"];
  C [label="形成候选风险清单", pos="5.2,4!", fillcolor="#E0F2FE", color="#0369A1"];
  D [label="按批准条件、频率\\n和停止条件验证", pos="7.3,4!", fillcolor="#E0F2FE", color="#0369A1"];
  E [label="结合资产、暴露和\\n业务影响定级", pos="9.4,4!", fillcolor="#E0F2FE", color="#0369A1"];
  F [label="客户确认风险\\n和修复优先级", pos="9.4,2.2!", fillcolor="#E0F2FE", color="#0369A1"];
  G [label="提出修复、加固、\\n补偿或临时控制", pos="7.3,2.2!", fillcolor="#E0F2FE", color="#0369A1"];
  H [label="客户实施变更\\n或安排修复", pos="5.2,2.2!", fillcolor="#E0F2FE", color="#0369A1"];
  I [label="按原风险条件复测", pos="3.1,2.2!", fillcolor="#E0F2FE", color="#0369A1"];
  J [label="消除、接受\\n或持续监控？", shape="diamond", pos="1,2.2!", fillcolor="#FFF7ED", color="#C2410C"];
  K [label="记录修复证据、\\n客户确认并关闭", pos="0.4,0.5!", fillcolor="#E8F5E9", color="#2E7D32"];
  L [label="记录责任人、期限\\n和残余风险", pos="3.0,0.5!", fillcolor="#FFF7ED", color="#C2410C"];
  A -> B -> C -> D -> E; E -> F -> G -> H -> I -> J;
  J -> K [label="消除"]; J -> L [label="接受/监控"]; L -> K; K -> F [style=dashed,label="趋势复盘"];
}
`,
  },
  {
    name: "04_major_assurance_cycle",
    dir: "04_design/service_workflows",
    engine: "neato",
    dot: `
digraph major {
  ${graphDefaults}
  graph [size="10.4,4.4!", splines="true", overlap="false"];
  node [width=1.7, height=0.65, fixedsize=false, pin=true];
  subgraph cluster_pre {
    label="重保准备"; color="#7DD3FC"; style="rounded"; fontcolor="#0C4A6E";
    P1 [label="范围、时间、地点、\\n联系人和审批链", pos="1,3.8!", fillcolor="#E0F2FE", color="#0369A1"];
    P2 [label="资产、暴露面和\\n数据源核验", pos="1,2.6!", fillcolor="#E0F2FE", color="#0369A1"];
    P3 [label="规则、日志、账号、\\n权限和预案检查", pos="1,1.4!", fillcolor="#E0F2FE", color="#0369A1"];
    P4 [label="排班、桌面演练\\n和准入决策", pos="1,0.2!", fillcolor="#E0F2FE", color="#0369A1"];
  }
  subgraph cluster_dur {
    label="重保值守"; color="#FDBA74"; style="rounded"; fontcolor="#7C2D12";
    D1 [label="持续监测与\\n威胁情报", pos="4.7,3.8!", fillcolor="#FFF7ED", color="#C2410C"];
    D2 [label="预警、研判\\n和最小验证", pos="4.7,2.6!", fillcolor="#FFF7ED", color="#C2410C"];
    D3 [label="专家保障、阻断、\\n应急和溯源", pos="4.7,1.4!", fillcolor="#FFF7ED", color="#C2410C"];
    D4 [label="日报、时间线\\n和客户沟通", pos="4.7,0.2!", fillcolor="#FFF7ED", color="#C2410C"];
  }
  subgraph cluster_post {
    label="重保收尾"; color="#86EFAC"; style="rounded"; fontcolor="#14532D";
    R1 [label="恢复确认、未结事项\\n和证据归档", pos="8.5,3.8!", fillcolor="#E8F5E9", color="#2E7D32"];
    R2 [label="复盘、规则优化\\n和风险清单", pos="8.5,2.6!", fillcolor="#E8F5E9", color="#2E7D32"];
    R3 [label="权限回收、总结\\n和下次准备建议", pos="8.5,1.4!", fillcolor="#E8F5E9", color="#2E7D32"];
  }
  P1 -> P2 -> P3 -> P4 -> D1 -> D2 -> D3 -> D4 -> R1 -> R2 -> R3;
  R3 -> P1 [style=dashed, label="下一轮"];
}
`,
  },
  {
    name: "05_emergency_response_workflow",
    dir: "04_design/service_workflows",
    engine: "neato",
    dot: `
digraph emergency {
  ${graphDefaults}
  graph [size="10.4,5.0!", splines="true", overlap="false"];
  node [width=1.65, height=0.62, fixedsize=false, pin=true];
  A [label="有效报告进入统一服务台\\n建立事件号与响应计时", pos="1.0,4.4!", fillcolor="#F3F4F6"];
  B [label="确认授权、范围\\n和事件类型", pos="3.5,4.4!", fillcolor="#E0F2FE", color="#0369A1"];
  C [label="采集证据并确认\\n影响与业务可用性", pos="6.1,4.4!", fillcolor="#E0F2FE", color="#0369A1"];
  F [label="需要生产阻断、\\n隔离或配置操作？", shape="diamond", pos="8.8,4.4!", fillcolor="#FFF7ED", color="#C2410C"];
  G [label="继续分析、监测\\n或加固", pos="8.8,2.9!", fillcolor="#E0F2FE", color="#0369A1"];
  H [label="审批、业务影响\\n和回退方案齐备？", shape="diamond", pos="6.3,2.9!", fillcolor="#FFF7ED", color="#C2410C"];
  I [label="提交建议并等待决策", pos="4.0,2.9!", fillcolor="#E8F5E9", color="#2E7D32"];
  J [label="最小影响执行\\n并双人复核", pos="1.8,2.9!", fillcolor="#E0F2FE", color="#0369A1"];
  K [label="恢复验证和业务确认\\n关闭条件确认", pos="4.8,1.4!", fillcolor="#E0F2FE", color="#0369A1"];
  M [label="客户确认关闭\\n复盘归档和改进", pos="4.8,0.3!", fillcolor="#E8F5E9", color="#2E7D32"];
  A -> B -> C -> F;
  F -> G [label="否"]; F -> H [label="是"];
  H -> I [label="否"]; I -> H; H -> J [label="是"];
  G -> K; J -> K; K -> M;
}
`,
  },
  {
    name: "06_training_knowledge_transfer",
    dir: "04_design/service_workflows",
    engine: "neato",
    dot: `
digraph training {
  ${graphDefaults}
  graph [size="10.4,4.2!", splines="true", overlap="false"];
  node [width=1.7, height=0.62, fixedsize=false, pin=true];
  A [label="对象、岗位、目标\\n和基础预评估", pos="0.8,3.7!", fillcolor="#E8F5E9", color="#2E7D32"];
  B [label="课程与演练\\n方案配置", pos="2.9,3.7!", fillcolor="#E0F2FE", color="#0369A1"];
  C [label="课件、案例、练习\\n和测试账号审核", pos="5.0,3.7!", fillcolor="#E0F2FE", color="#0369A1"];
  D [label="是否需要赛事平台？", shape="diamond", pos="7.1,3.7!", fillcolor="#FFF7ED", color="#C2410C"];
  E [label="现场授课、练习和答疑", pos="9.2,4.2!", fillcolor="#E0F2FE", color="#0369A1"];
  F [label="隔离平台、赛题、\\n评分和停止条件", pos="9.2,2.7!", fillcolor="#E0F2FE", color="#0369A1"];
  G [label="签到、测评、满意度\\n和问题记录", pos="7.1,1.8!", fillcolor="#E0F2FE", color="#0369A1"];
  H [label="知识转移材料与检查表", pos="4.8,1.8!", fillcolor="#E8F5E9", color="#2E7D32"];
  I [label="培训总结和改进建议", pos="2.4,1.8!", fillcolor="#E8F5E9", color="#2E7D32"];
  J [label="赛后数据清理、\\n账号回收和资源交接", pos="9.2,0.8!", fillcolor="#E8F5E9", color="#2E7D32"];
  A -> B -> C -> D; D -> E [label="否"]; D -> F [label="是"];
  E -> G; F -> G; G -> H -> I; F -> J; J -> I;
}
`,
  },
];

async function main() {
  const viz = await instance();
  for (const item of diagrams) {
    const dir = path.join(root, item.dir);
    fs.mkdirSync(dir, { recursive: true });
    const dotPath = path.join(dir, `${item.name}.dot`);
    const svgPath = path.join(dir, `${item.name}.svg`);
    const pngPath = path.join(dir, `${item.name}.png`);
    fs.writeFileSync(dotPath, `${item.dot.trim()}\n`, "utf8");
    const svg = viz.renderString(item.dot, {
      format: "svg",
      engine: item.engine ?? "dot",
    });
    fs.writeFileSync(svgPath, svg, "utf8");
    await sharp(Buffer.from(svg), { density: 180 })
      .resize({ width: 2200, withoutEnlargement: false })
      .png()
      .toFile(pngPath);
    console.log(`rendered ${path.relative(root, pngPath)}`);
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

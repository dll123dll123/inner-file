from pathlib import Path
import argparse
import json
import re
import shutil
from datetime import datetime, timezone

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE = PACKAGE_ROOT / "projects" / "_template"

def write_json(path: Path, data: dict) -> None:
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def resolve_workspace_root(raw: str) -> Path:
    supplied = Path(raw).expanduser()
    if not supplied.is_absolute():
        raise SystemExit("--workspace-root must be an absolute path.")
    if supplied.is_symlink():
        raise SystemExit("--workspace-root must not be a symbolic link.")
    workspace = supplied.resolve(strict=True)
    if not workspace.is_dir():
        raise SystemExit(f"Workspace root is not a directory: {workspace}")
    try:
        workspace.relative_to(PACKAGE_ROOT)
    except ValueError:
        pass
    else:
        raise SystemExit("Workspace root must not be the expert package directory or one of its subdirectories.")
    return workspace

def main():
    parser = argparse.ArgumentParser(description="Create a project under the current WorkBuddy workspace using the expert package as a read-only template source.")
    parser.add_argument("project_id", help="Stable internal workspace ID, e.g. PRJ-2026-001")
    parser.add_argument("--workspace-root", required=True, help="Absolute path of the current WorkBuddy workspace.")
    parser.add_argument("--name", default="", help="Human-readable internal project name")
    parser.add_argument("--document-version", default="V1.0", help="Proposal document version, not tender project code")
    args = parser.parse_args()

    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{1,63}", args.project_id):
        raise SystemExit("Invalid project_id. Use 2-64 letters, digits, dot, underscore or hyphen.")
    if not args.document_version.strip():
        raise SystemExit("document-version must not be empty.")

    workspace_root = resolve_workspace_root(args.workspace_root)
    if not TEMPLATE.is_dir():
        raise SystemExit(f"Project template not found in expert package: {TEMPLATE}")
    projects_root = workspace_root / "projects"
    if projects_root.is_symlink():
        raise SystemExit(f"Workspace projects directory must not be a symbolic link: {projects_root}")
    projects_root.mkdir(exist_ok=True)
    projects_root = projects_root.resolve(strict=True)
    if projects_root.parent != workspace_root:
        raise SystemExit("Resolved projects directory is not directly under workspace root.")

    target = projects_root / args.project_id
    if target.exists() or target.is_symlink():
        raise SystemExit(f"Target already exists: {target}. No files changed.")
    shutil.copytree(TEMPLATE, target)
    target = target.resolve(strict=True)
    now = datetime.now(timezone.utc).isoformat()

    state_path = target / "00_control" / "STATE.json"
    state = json.loads(state_path.read_text(encoding="utf-8"))
    state["project_id"] = args.project_id
    state["project_name"] = args.name
    state["updated_at"] = now
    write_json(state_path, state)

    tasks_path = target / "00_control" / "TASKS.json"
    tasks = json.loads(tasks_path.read_text(encoding="utf-8"))
    tasks["project_id"] = args.project_id
    write_json(tasks_path, tasks)

    identity_path = target / "00_control" / "project_identity.json"
    identity = json.loads(identity_path.read_text(encoding="utf-8"))
    identity["schema_version"] = "1.2.3"
    identity["workspace_id"] = args.project_id
    identity["workspace_root"] = str(workspace_root)
    identity["project_dir"] = str(target)
    identity["document_version"] = args.document_version
    for field in identity.get("fields", []):
        if field.get("status") != "confirmed":
            field["locked"] = False
        if field.get("status") == "not_found":
            field["verbatim_value"] = None
            field["normalized_value"] = None
            field["source_file"] = ""
            field["source_location"] = ""
    write_json(identity_path, identity)

    project_doc = target / "00_control" / "PROJECT.md"
    content = project_doc.read_text(encoding="utf-8")
    content = content.replace("- 招标项目编号（原文锁定）：", "- 招标项目编号（原文锁定）：待从招标原文提取", 1)
    content = content.replace("- 招标项目名称（原文锁定）：", "- 招标项目名称（原文锁定）：待从招标原文提取", 1)
    content = content.replace("- 内部 workspace_id：", f"- 内部 workspace_id：{args.project_id}", 1)
    content = content.replace("- 文档版本：", f"- 文档版本：{args.document_version}", 1)
    project_doc.write_text(content, encoding="utf-8")

    print(f"Created project workspace: {target}")
    print(f"Workspace root: {workspace_root}")
    print(f"Initialized project identity: {identity_path}")
    print("Project files are stored in the current workspace, not in the expert package.")
    print("Tender identity fields remain unlocked until source-backed confirmation.")

if __name__ == "__main__":
    main()

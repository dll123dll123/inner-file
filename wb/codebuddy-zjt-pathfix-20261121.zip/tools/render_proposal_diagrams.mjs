import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

const require = createRequire(import.meta.url);
const { instance } = require("@viz-js/viz");
const sharp = require("sharp");

const projectArgIndex = process.argv.indexOf("--project-dir");
const projectArg = projectArgIndex >= 0 ? process.argv[projectArgIndex + 1] : null;
if (!projectArg || projectArg.startsWith("--") || !path.isAbsolute(projectArg)) {
  console.error("Usage: node <renderer.mjs> --project-dir <absolute-project-dir>");
  process.exit(2);
}
const root = path.resolve(projectArg);
const identityPath = path.join(root, "00_control", "project_identity.json");
if (!fs.existsSync(identityPath)) {
  throw new Error(`Project identity not found under selected project directory: ${root}`);
}
const identity = JSON.parse(fs.readFileSync(identityPath, "utf8"));
if (identity.workspace_id !== path.basename(root)) {
  throw new Error("Project directory name does not match project_identity.workspace_id");
}
if (identity.project_dir && path.resolve(identity.project_dir) !== root) {
  throw new Error("project_identity.project_dir does not match --project-dir");
}

const commonGraph = `
  graph [bgcolor="white", pad="0.25", nodesep="0.35", ranksep="0.55", fontname="Microsoft YaHei", fontsize=12];
  node [shape="box", style="rounded,filled", fontname="Microsoft YaHei", fontsize=12, color="#6B7280", penwidth=1.1, margin="0.14,0.09"];
  edge [fontname="Microsoft YaHei", fontsize=10, color="#4B5563", arrowsize=0.7];
`;

const diagrams = [
  {
    name: "01_overall_service_architecture",
    dir: "04_design/architecture",
    dot: `
digraph architecture {
  ${commonGraph}
  rankdir=TB;
  compound=true;

  subgraph cluster_customer {
    label="客户生产与现有平台层（具体对象以现状确认）";
    color="#D1D5DB"; style="rounded,dashed"; fontcolor="#374151";
    C1 [label="业务系统、数据与账号", fillcolor="#F3F4F6"];
    C2 [label="现有安全平台\\n告警、日志、终端、边界、资产", fillcolor="#F3F4F6"];
    C3 [label="工单、资产库与联系人", fillcolor="#F3F4F6"];
  }

  subgraph cluster_access {
    label="授权访问与数据交换边界";
    color="#7DD3FC"; style="rounded"; fontcolor="#0C4A6E";
    A1 [label="受控账号、堡垒机\\n或只读视图", fillcolor="#E0F2FE", color="#0369A1"];
    A2 [label="审批后的导出与接口", fillcolor="#E0F2FE", color="#0369A1"];
    A3 [label="受控终端与批准渠道", fillcolor="#E0F2FE", color="#0369A1"];
  }

  subgraph cluster_ops {
    label="服务运营层";
    color="#86EFAC"; style="rounded"; fontcolor="#14532D";
    S1 [label="统一服务台\\n受理、分派、跟踪、关闭", fillcolor="#E8F5E9", color="#2E7D32"];
    S2 [label="监测研判与事件闭环", fillcolor="#E8F5E9", color="#2E7D32"];
    S3 [label="检查评估、漏洞与加固", fillcolor="#E8F5E9", color="#2E7D32"];
    S4 [label="重保值守与威胁情报", fillcolor="#E8F5E9", color="#2E7D32"];
    S5 [label="应急响应与溯源", fillcolor="#E8F5E9", color="#2E7D32"];
    S6 [label="培训、演练与赛事支撑", fillcolor="#E8F5E9", color="#2E7D32"];
    S7 [label="报告与知识沉淀", fillcolor="#E8F5E9", color="#2E7D32"];
  }

  subgraph cluster_governance {
    label="治理、质量与合规层";
    color="#FDBA74"; style="rounded"; fontcolor="#7C2D12";
    G1 [label="项目负责人与技术负责人", fillcolor="#FFF7ED", color="#C2410C"];
    G2 [label="客户审批与业务决策", fillcolor="#FFF7ED", color="#C2410C"];
    G3 [label="质量管理与满意度", fillcolor="#FFF7ED", color="#C2410C"];
    G4 [label="保密、权限与审计", fillcolor="#FFF7ED", color="#C2410C"];
  }

  C2 -> A1 [label="只读或授权获取"];
  C2 -> A2 [label="审批后导出"];
  C1 -> A1 [label="授权访问"];
  C3 -> A2 [label="任务和资产上下文"];
  A1 -> S2;
  A2 -> S3;
  A3 -> S6;
  C3 -> S1;
  S1 -> S2;
  S1 -> S3;
  S1 -> S4;
  S1 -> S6;
  S2 -> S5;
  S4 -> S5;
  S3 -> S7;
  S5 -> S7;
  S6 -> S7;
  S7 -> G3;
  G1 -> S1;
  G1 -> S2;
  G1 -> S4;
  G2 -> S5 [label="授权、变更与业务影响"];
  G4 -> A1 [label="访问审计与保密"];
  G4 -> S7 [label="交付复核"];
}
`,
  },
  {
    name: "02_service_organization",
    dir: "04_design/architecture",
    dot: `
digraph organization {
  ${commonGraph}
  rankdir=LR;

  CUST [label="客户项目管理与\\n安全负责人", fillcolor="#F3F4F6"];
  PM [label="项目负责人", fillcolor="#FFF7ED", color="#C2410C"];
  TL [label="技术负责人", fillcolor="#FFF7ED", color="#C2410C"];
  QA [label="质量与保密负责人", fillcolor="#FFF7ED", color="#C2410C"];
  SD [label="服务台与现场负责人", fillcolor="#E0F2FE", color="#0369A1"];
  MON [label="监测研判人员", fillcolor="#E0F2FE", color="#0369A1"];
  VUL [label="漏洞与加固工程师", fillcolor="#E0F2FE", color="#0369A1"];
  IR [label="应急响应与\\n溯源人员", fillcolor="#E0F2FE", color="#0369A1"];
  MAJ [label="重保专家", fillcolor="#E0F2FE", color="#0369A1"];
  TRAIN [label="培训讲师与\\n赛事支撑", fillcolor="#E0F2FE", color="#0369A1"];
  BACKUP [label="后备人员与\\n远程支持库", fillcolor="#E8F5E9", color="#2E7D32", style="rounded,dashed"];

  CUST -> PM [label="目标、授权、验收"];
  CUST -> TL [label="安全审批与事件确认"];
  PM -> SD;
  PM -> TL;
  PM -> QA;
  TL -> MON;
  TL -> VUL;
  TL -> IR;
  TL -> MAJ;
  TL -> TRAIN;
  SD -> MON [label="受理与分派"];
  SD -> VUL [label="任务与风险闭环"];
  SD -> IR [label="事件升级"];
  SD -> MAJ [label="重保任务"];
  SD -> TRAIN [label="培训任务"];
  MON -> SD [label="研判结论"];
  VUL -> SD [label="报告与复测"];
  IR -> SD [label="处置与复盘"];
  MAJ -> SD [label="值守与总结"];
  TRAIN -> SD [label="课件与测评"];
  QA -> PM [label="抽查与整改"];
  BACKUP -> SD [label="经批准后补充", style="dashed"];
}
`,
  },
  {
    name: "01_event_response_workflow",
    dir: "04_design/service_workflows",
    dot: `
digraph event_response {
  ${commonGraph}
  rankdir=TB;
  T [label="事件报告、告警或客户请求", fillcolor="#F3F4F6"];
  S1 [label="服务台受理并生成编号", fillcolor="#E0F2FE", color="#0369A1"];
  A [label="是否属于授权范围？", shape="diamond", fillcolor="#FFF7ED", color="#C2410C"];
  X [label="说明边界并转交客户负责人", fillcolor="#E8F5E9", color="#2E7D32"];
  C [label="分级并收集资产、账号、\\n日志和时间证据", fillcolor="#E0F2FE", color="#0369A1"];
  J [label="能否确认攻击行为？", shape="diamond", fillcolor="#FFF7ED", color="#C2410C"];
  O [label="继续观察、补充证据或关闭为低风险", fillcolor="#E8F5E9", color="#2E7D32"];
  I [label="评估影响并形成处置或监测方案", fillcolor="#E0F2FE", color="#0369A1"];
  P [label="需要生产阻断、隔离、账号或配置变更？", shape="diamond", fillcolor="#FFF7ED", color="#C2410C"];
  R [label="执行分析、加固建议和监测措施", fillcolor="#E0F2FE", color="#0369A1"];
  H [label="客户是否已授权并获得审批？", shape="diamond", fillcolor="#FFF7ED", color="#C2410C"];
  AP [label="提交影响与回退方案，等待批准", fillcolor="#E8F5E9", color="#2E7D32"];
  ACT [label="按最小影响原则执行并双人复核", fillcolor="#E0F2FE", color="#0369A1"];
  V [label="恢复与关闭验证", fillcolor="#E0F2FE", color="#0369A1"];
  Z [label="客户确认、复盘归档和改进登记", fillcolor="#E8F5E9", color="#2E7D32"];
  ESC [label="重大升级：项目负责人与技术负责人\\n立即介入资源协调", fillcolor="#FEE2E2", color="#B91C1C"];

  T -> S1;
  S1 -> A;
  A -> X [label="否"];
  A -> C [label="是"];
  C -> J;
  J -> O [label="否"];
  J -> I [label="是"];
  I -> P;
  P -> R [label="否"];
  P -> H [label="是"];
  H -> AP [label="否"];
  AP -> H;
  H -> ACT [label="是"];
  ACT -> V;
  R -> V;
  V -> Z;
  C -> ESC [label="重大升级"];
  ESC -> I;
}
`,
  },
  {
    name: "02_vulnerability_remediation_loop",
    dir: "04_design/service_workflows",
    engine: "neato",
    dot: `
digraph vulnerability_loop {
  ${commonGraph}
  graph [size="10.2,4.2!", splines="true", overlap="false"];
  node [width=1.55, height=0.62, fixedsize=false, pin=true];

  A [label="确认授权资产\\n和测试边界", pos="1,4!", fillcolor="#E8F5E9", color="#2E7D32"];
  B [label="巡检、扫描\\n或人工检查", pos="3.1,4!", fillcolor="#E0F2FE", color="#0369A1"];
  C [label="形成候选\\n风险清单", pos="5.2,4!", fillcolor="#E0F2FE", color="#0369A1"];
  D [label="最小必要验证\\n并标注证据", pos="7.3,4!", fillcolor="#E0F2FE", color="#0369A1"];
  E [label="结合资产、暴露面\\n和业务影响定级", pos="9.4,4!", fillcolor="#E0F2FE", color="#0369A1"];
  F [label="客户确认风险\\n和修复优先级", pos="9.4,2.2!", fillcolor="#E0F2FE", color="#0369A1"];
  G [label="提出加固或\\n修复建议", pos="7.3,2.2!", fillcolor="#E0F2FE", color="#0369A1"];
  H [label="客户实施变更\\n或安排修复", pos="5.2,2.2!", fillcolor="#E0F2FE", color="#0369A1"];
  I [label="按原风险条件复测", pos="3.1,2.2!", fillcolor="#E0F2FE", color="#0369A1"];
  J [label="风险是否消除\\n或接受？", shape="diamond", pos="1,2.2!", fillcolor="#FFF7ED", color="#C2410C"];
  K [label="记录证据、客户确认\\n并关闭", pos="0.4,0.5!", fillcolor="#E8F5E9", color="#2E7D32"];
  L [label="更新风险、责任人和期限\\n进入下一轮整改", pos="3.0,0.5!", fillcolor="#FFF7ED", color="#C2410C"];

  A -> B -> C -> D -> E;
  E -> F;
  F -> G -> H -> I -> J;
  J -> K [label="是"];
  J -> L [label="否"];
  L -> G [style=dashed, label="继续跟踪", constraint=false];
}
`,
  },
  {
    name: "03_major_event_assurance_cycle",
    dir: "04_design/service_workflows",
    dot: `
digraph major_assurance {
  ${commonGraph}
  rankdir=LR;
  compound=true;

  subgraph cluster_pre {
    label="重保准备";
    color="#7DD3FC"; style="rounded"; fontcolor="#0C4A6E";
    P1 [label="范围、时间、\\n联系人和审批链", fillcolor="#E0F2FE", color="#0369A1"];
    P2 [label="资产、暴露面\\n和数据源核对", fillcolor="#E0F2FE", color="#0369A1"];
    P3 [label="规则、日志、\\n账号和权限检查", fillcolor="#E0F2FE", color="#0369A1"];
    P4 [label="应急预案、联系人和\\n桌面演练", fillcolor="#E0F2FE", color="#0369A1"];
  }
  subgraph cluster_during {
    label="重保值守";
    color="#FDBA74"; style="rounded"; fontcolor="#7C2D12";
    D1 [label="持续监测与\\n情报生成", fillcolor="#FFF7ED", color="#C2410C"];
    D2 [label="预警、研判\\n和小型验证", fillcolor="#FFF7ED", color="#C2410C"];
    D3 [label="事件分级、\\n处置与升级", fillcolor="#FFF7ED", color="#C2410C"];
    D4 [label="值守日报、\\n时间线和客户沟通", fillcolor="#FFF7ED", color="#C2410C"];
  }
  subgraph cluster_post {
    label="重保收尾";
    color="#86EFAC"; style="rounded"; fontcolor="#14532D";
    R1 [label="恢复确认、未结事项\\n和证据归档", fillcolor="#E8F5E9", color="#2E7D32"];
    R2 [label="复盘、规则优化\\n和风险清单", fillcolor="#E8F5E9", color="#2E7D32"];
    R3 [label="重保总结和\\n下次准备建议", fillcolor="#E8F5E9", color="#2E7D32"];
  }

  P1 -> P2 -> P3 -> P4;
  P4 -> D1;
  D1 -> D2 -> D3 -> D4;
  D4 -> R1;
  R1 -> R2 -> R3;
  R3 -> P1 [style=dashed, label="下一次重保"];
  {rank=same; P1; D1; R1;}
  {rank=same; P2; D2; R2;}
  {rank=same; P3; D3; R3;}
  {rank=same; P4; D4;}
}
`,
  },
];

async function main() {
  const viz = await instance();
  for (const item of diagrams) {
    const dir = path.join(root, item.dir);
    fs.mkdirSync(dir, {recursive: true});
    const dotPath = path.join(dir, `${item.name}.dot`);
    const svgPath = path.join(dir, `${item.name}.svg`);
    const pngPath = path.join(dir, `${item.name}.png`);
    fs.writeFileSync(dotPath, `${item.dot.trim()}\n`, "utf8");
    const svg = viz.renderString(item.dot, {
      format: "svg",
      engine: item.engine ?? "dot",
    });
    fs.writeFileSync(svgPath, svg, "utf8");
    await sharp(Buffer.from(svg), {density: 180})
      .resize({width: 2200, withoutEnlargement: false})
      .png()
      .toFile(pngPath);
    console.log(`rendered ${path.relative(root, pngPath)}`);
  }
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

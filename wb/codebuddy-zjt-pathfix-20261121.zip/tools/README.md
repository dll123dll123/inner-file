# 工具层

本版本包含项目初始化和基础架构校验工具，不包含完整 PDF/DOCX 解析、企业语义检索、图形渲染或 Word 发布引擎。

## validate_scaffold.py
使用 Python 标准库检查关键目录、Agent TOML、Skill frontmatter、JSON 文件和项目模板。
运行：`python "<package_root>/tools/validate_scaffold.py"`

## init_project.py
从专家团安装目录的 `projects/_template/` 读取只读模板，在 WorkBuddy 当前工作区下创建项目。必须显式传入当前工作区绝对路径，默认拒绝覆盖已存在目录。
运行：`python "<package_root>/tools/init_project.py" PRJ-2026-001 --workspace-root "D:\\投标工作区" --name "项目名称"`。项目目录为 `D:\\投标工作区\\projects\\PRJ-2026-001`。

## 后续工具接口规划
- document-extract：解析 PDF/DOCX/XLSX 并保留来源位置；
- knowledge-search：按项目授权范围检索企业资料；
- project-state：校验和更新项目状态、任务状态；
- diagram-render：渲染 Mermaid 或其他可编辑图形源；
- word-publish：按指定 DOCX 模板合并章节和图形。

实现这些工具前，先检查当前环境、依赖和现有代码，避免重复建设。

## validate_analysis.py
校验指定项目的 `project_identity.json`、`analysis_baseline.json`、评分父子关系与计分叶子项、需求/评分映射，以及 CSV 派生视图与基线的一致性。错误会返回非零退出码；评分总分与叶子分值不一致会产生警告，需结合招标原文人工判断。
运行：`python "<package_root>/tools/validate_analysis.py" "<project_dir>"`

## analysis_validation.py
供 `validate_analysis.py` 和自动化测试复用的校验逻辑，不建议直接作为命令运行。

## project_guard.py（V1.2.2）

项目级写入授权与状态持久化工具。所有 Agent 项目输出必须先执行 `check-path`，正式写入必须使用 `write`；Coordinator 通过 `task-upsert`、`task-status`、`phase-status` 更新 TASKS/STATE，任务/阶段完成需要输出文件和验证证据。中断恢复使用 `recover`，遗留 in_progress 任务回到 ready 并要求重新验收。

示例：
```bash
python "<package_root>/tools/project_guard.py" check-path --project-dir "<project_dir>" --expected-project-id PRJ-001 --role proposal_writer --path 06_chapters/C01.md
python "<package_root>/tools/project_guard.py" write --project-dir "<project_dir>" --expected-project-id PRJ-001 --role proposal_writer --path 06_chapters/C01.md --source "<staged_file>"
python "<package_root>/tools/project_guard.py" recover --project-dir "<project_dir>" --expected-project-id PRJ-001
```

注意：Guard 是项目级协作式写入约束，不是操作系统文件系统隔离；WorkBuddy 不提供按成员的文件系统硬隔离。若运行环境允许绕过 Guard 的任意直接文件写入，不得宣称已经实现硬隔离。

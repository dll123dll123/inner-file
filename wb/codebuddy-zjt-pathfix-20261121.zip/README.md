# 网络安全技术服务方案专家团（WorkBuddy 适配版）

本包由 Codex Security Proposal Skills **V1.2.3** 迁移适配而来，完整保留原方法论、阶段流程、输出契约与质量要求。WorkBuddy 仅承担运行机制适配。

## 组成

- 1 个主理人：`proposal-team-lead`（承接原 Coordinator）
- 6 个专业专家：`requirement-analyst`、`knowledge-curator`、`solution-architect`、`outline-planner`、`proposal-writer`、`proposal-reviewer`
- 9 个 Skill：原 9 个 Skill 的适配版，正文方法论未删减
- 6 个 JSON Schema contracts
- `tools/`：7 个 Python 工具 + 2 个 Node 渲染脚本
- `projects/_template/`：18 个项目控制与阶段目录文件
- `avatars/`：占位头像，可替换

## 使用边界

本系统只生成投标文件中的**技术服务方案部分**，不审查企业资格、商务、报价、保证金、签章与递交要求。

## 路径与解释器

- `package_root` 是专家团安装目录，只存放 Agent、Skill、工具和只读模板；它不是项目工作目录。
- `workspace_root` 是 WorkBuddy 当前会话的工作区绝对路径。新项目统一创建在 `<workspace_root>/projects/<project_id>`；项目状态、中间文件和最终成果均写入该项目目录。
- 所有工具脚本从 `<package_root>/tools/` 使用绝对路径调用；所有项目文件使用 `<project_dir>/` 绝对路径。若 WorkBuddy 未提供可靠的当前工作区路径，先询问用户，不得猜测。
- Python 固定使用系统 Python 3.14.2：`C:\Users\h36919\AppData\Local\Programs\Python\Python314\python.exe`。
- Node 图形渲染脚本依赖 `@viz-js/viz` 与 `sharp`，当前环境未安装；本包保留原有脚本与依赖说明，未安装依赖。

## 写入隔离说明

WorkBuddy 不提供按专家成员的文件系统硬隔离。写入约束依靠主理人编排与 `tools/project_guard.py` 执行，必须通过实际越权写入测试验证。若可绕过，不得宣称硬隔离已实现。

## 来源基线

原始未修改资产位于 `write-skill-wb/source-v1.2.3/`，其中 `enterprise-library/` 单独作为只读资料库保留。

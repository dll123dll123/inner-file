from __future__ import annotations
import csv
import json
from pathlib import Path
from typing import Any

PRIORITIES = {"P0", "P1", "P2", "P3"}
DEPTHS = {"D4", "D3", "D2", "D1", "E"}


def _load_json(path: Path, errors: list[str]) -> dict[str, Any] | None:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            errors.append(f"{path.name}: root must be a JSON object")
            return None
        return data
    except Exception as exc:
        errors.append(f"{path.name}: invalid/unreadable JSON: {exc}")
        return None


def _csv_rows(path: Path, errors: list[str]) -> list[dict[str, str]] | None:
    try:
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                errors.append(f"{path.name}: missing CSV header")
                return None
            return list(reader)
    except Exception as exc:
        errors.append(f"{path.name}: invalid/unreadable CSV: {exc}")
        return None


def validate_project_identity(path: Path, errors: list[str], warnings: list[str]) -> dict | None:
    data = _load_json(path, errors)
    if data is None:
        return None
    if not str(data.get("workspace_id", "")).strip():
        errors.append("project_identity: workspace_id must be non-empty")
    if not str(data.get("document_version", "")).strip():
        errors.append("project_identity: document_version must be non-empty")
    seen = set()
    for i, field in enumerate(data.get("fields", [])):
        key = field.get("field_key")
        if not key:
            errors.append(f"project_identity.fields[{i}]: field_key is required")
        elif key in seen:
            errors.append(f"project_identity: duplicate field_key {key}")
        seen.add(key)
        status, locked = field.get("status"), field.get("locked")
        if status not in {"confirmed", "conflict", "unclear", "not_found"}:
            errors.append(f"project_identity.{key}: invalid status {status!r}")
            continue
        if status == "confirmed":
            if locked is not True:
                errors.append(f"project_identity.{key}: confirmed field must be locked=true")
            for required in ("verbatim_value", "source_file", "source_location"):
                if field.get(required) in (None, ""):
                    errors.append(f"project_identity.{key}: confirmed field missing {required}")
        else:
            if locked is not False:
                errors.append(f"project_identity.{key}: {status} field must be locked=false")
            if status == "not_found" and any(field.get(k) not in (None, "") for k in ("verbatim_value", "normalized_value")):
                warnings.append(f"project_identity.{key}: not_found field contains a value; verify provenance")
    return data


def validate_analysis_baseline(project_dir: Path, errors: list[str], warnings: list[str]) -> dict | None:
    baseline_path = project_dir / "02_requirements" / "analysis_baseline.json"
    if not baseline_path.exists():
        warnings.append("analysis_baseline.json not present; baseline validation skipped")
        return None
    data = _load_json(baseline_path, errors)
    if data is None:
        return None

    requirements = data.get("requirements", [])
    scoring = data.get("scoring_items", [])
    decisions = data.get("response_decisions", [])
    service_mode = data.get("analysis_scope") == "technical_service_only" or "service_mappings" in data
    mappings = data.get("service_mappings", []) if service_mode else data.get("chapter_mappings", [])
    source_manifest = data.get("source_manifest", [])
    source_ids = [x.get("source_id") for x in source_manifest]
    if len(source_ids) != len(set(source_ids)):
        errors.append("analysis_baseline: duplicate source_id in source_manifest")
    known_source_ids = {x for x in source_ids if x}

    for collection_name, collection, id_key in (
        ("requirements", requirements, "requirement_id"),
        ("scoring_items", scoring, "scoring_id"),
    ):
        for item in collection:
            source_ref = item.get("source_ref") or {}
            source_id = source_ref.get("source_id") if isinstance(source_ref, dict) else None
            if source_id and source_id not in known_source_ids:
                errors.append(f"analysis_baseline.{collection_name}.{item.get(id_key)}: source_ref references unknown source_id {source_id}")

    req_ids = [x.get("requirement_id") for x in requirements]
    score_ids = [x.get("scoring_id") for x in scoring]
    for label, ids in (("requirement_id", req_ids), ("scoring_id", score_ids)):
        if None in ids or "" in ids:
            errors.append(f"analysis_baseline: empty {label}")
        if len(ids) != len(set(ids)):
            errors.append(f"analysis_baseline: duplicate {label}")

    req_set, score_set = set(req_ids), set(score_ids)
    all_item_ids = req_set | score_set

    # Validate response decisions and enforce a single canonical decision per item.
    decision_map = {}
    for i, item in enumerate(decisions):
        item_id = item.get("item_id")
        if item_id not in all_item_ids:
            errors.append(f"analysis_baseline.response_decisions[{i}]: unknown item_id {item_id!r}")
        if item_id in decision_map:
            errors.append(f"analysis_baseline: duplicate response_decision for {item_id}")
        decision_map[item_id] = item
        if item.get("response_priority") not in PRIORITIES:
            errors.append(f"analysis_baseline.{item_id}: invalid response_priority")
        if item.get("writing_depth") not in DEPTHS:
            errors.append(f"analysis_baseline.{item_id}: invalid writing_depth")

    # Validate requirement/scoring item-level priority/depth when present against the canonical decision.
    for item_type, items, id_key in (("requirement", requirements, "requirement_id"), ("scoring", scoring, "scoring_id")):
        for item in items:
            item_id = item.get(id_key)
            decision = decision_map.get(item_id)
            if not decision:
                is_actionable = item_type == "requirement" or (
                    item_type == "scoring" and item.get("kind") == "scored" and item.get("counts_toward_total") is True
                )
                if is_actionable:
                    warnings.append(f"analysis_baseline: {item_type} {item_id} has no response_decision")
                continue
            for field in ("response_priority", "writing_depth"):
                if item.get(field) is not None and item.get(field) != decision.get(field):
                    errors.append(f"analysis_baseline: {item_id} {field} differs between item and response_decisions")

    # Validate scoring hierarchy, parent references, cycles, and arithmetic using scored leaves only.
    score_by_id = {x.get("scoring_id"): x for x in scoring if x.get("scoring_id")}
    children = {sid: [] for sid in score_by_id}
    for item in scoring:
        sid, parent = item.get("scoring_id"), item.get("parent_scoring_id")
        if parent:
            if parent not in score_by_id:
                errors.append(f"scoring {sid}: unknown parent_scoring_id {parent}")
            else:
                children[parent].append(sid)
    for sid in score_by_id:
        visited, cur = set(), sid
        while cur:
            if cur in visited:
                errors.append(f"scoring hierarchy cycle detected at {sid}")
                break
            visited.add(cur)
            cur = score_by_id.get(cur, {}).get("parent_scoring_id")

    scored_leaves = []
    for sid, item in score_by_id.items():
        is_leaf = len(children[sid]) == 0
        if item.get("kind") == "scored" and item.get("counts_toward_total") is True and is_leaf:
            score = item.get("max_score")
            if not isinstance(score, (int, float)):
                errors.append(f"scoring {sid}: scored leaf must have numeric max_score")
            else:
                scored_leaves.append((sid, float(score)))
        if item.get("kind") in {"descriptive_tier", "ranking_only", "eligibility"} and item.get("counts_toward_total") is True:
            errors.append(f"scoring {sid}: non-scored kind must not count toward total")
        if item.get("level") == "total" and item.get("counts_toward_total") is True:
            errors.append(f"scoring {sid}: total row must not itself count toward total")

    total_items = [x for x in scoring if x.get("level") == "total" and isinstance(x.get("max_score"), (int, float))]
    if total_items and data.get("scoring_scope") != "technical_only":
        leaf_sum = sum(v for _, v in scored_leaves)
        for total in total_items:
            expected = float(total["max_score"])
            # Compare only if this total is root or has all counted leaves in its descendant tree.
            descendants = set()
            stack = list(children.get(total["scoring_id"], []))
            while stack:
                child = stack.pop()
                descendants.add(child)
                stack.extend(children.get(child, []))
            if descendants:
                relevant = [v for sid, v in scored_leaves if sid in descendants]
                actual = sum(relevant)
            else:
                actual = leaf_sum
            if abs(actual - expected) > 1e-6:
                warnings.append(f"scoring total {total['scoring_id']}: scored leaf sum {actual:g} != stated total {expected:g}; retain source discrepancy for human review")

    # Validate service mappings for technical-only baselines; retain legacy chapter mappings.
    mapped_items = set()
    primary_counts = {}
    mapping_key = "service_id" if service_mode else "chapter_id"
    mapping_label = "service_mappings" if service_mode else "chapter_mappings"
    allowed_roles = {"primary", "supporting", "cross_reference"} if service_mode else {"primary", "supporting", "attachment", "cross_reference"}
    for i, mapping in enumerate(mappings):
        item_id = mapping.get("item_id")
        if item_id not in all_item_ids:
            errors.append(f"{mapping_label}[{i}]: unknown item_id {item_id!r}")
        if not str(mapping.get(mapping_key, "")).strip():
            errors.append(f"{mapping_label}[{i}]: {mapping_key} is empty")
        mapped_items.add(item_id)
        if mapping.get("mapping_role") == "primary":
            primary_counts[item_id] = primary_counts.get(item_id, 0) + 1
        if mapping.get("mapping_role") not in allowed_roles:
            errors.append(f"{mapping_label}[{i}]: invalid mapping_role")
    for item_id, count in primary_counts.items():
        if count > 1:
            errors.append(f"analysis_baseline: {item_id} has {count} primary chapter mappings; use one primary and supporting mappings")
    for item in requirements:
        rid = item.get("requirement_id")
        if item.get("response_priority") in {"P0", "P1"} and rid not in mapped_items:
            warnings.append(f"high-priority requirement {rid} has no chapter mapping")
    for item in scoring:
        sid = item.get("scoring_id")
        if item.get("kind") == "scored" and item.get("counts_toward_total") is True and len(children.get(sid, [])) == 0 and sid not in mapped_items:
            warnings.append(f"scored leaf item {sid} has no chapter/attachment mapping")

    summary = data.get("validation_summary", {})
    actual_unmapped_requirements = sum(1 for x in requirements if x.get("requirement_id") not in mapped_items)
    actual_unmapped_scoring = sum(1 for x in scoring if x.get("kind") == "scored"
                                  and x.get("counts_toward_total") is True
                                  and len(children.get(x.get("scoring_id"), [])) == 0
                                  and x.get("scoring_id") not in mapped_items)
    if isinstance(summary.get("unmapped_requirements"), int) and summary["unmapped_requirements"] != actual_unmapped_requirements:
        warnings.append(f"validation_summary.unmapped_requirements={summary['unmapped_requirements']} but actual={actual_unmapped_requirements}")
    if isinstance(summary.get("unmapped_scoring_items"), int) and summary["unmapped_scoring_items"] != actual_unmapped_scoring:
        warnings.append(f"validation_summary.unmapped_scoring_items={summary['unmapped_scoring_items']} but actual={actual_unmapped_scoring}")

    # Project identity reference must point to an existing file when expressed as a project-relative path.
    identity_ref = data.get("project_identity_ref")
    if identity_ref:
        ref_path = Path(identity_ref)
        if not ref_path.is_absolute():
            ref_path = project_dir / ref_path
        if not ref_path.exists():
            warnings.append(f"project_identity_ref does not resolve: {identity_ref}")
        else:
            control_identity = project_dir / "00_control" / "project_identity.json"
            if control_identity.exists():
                control_data = _load_json(control_identity, errors)
                ref_data = _load_json(ref_path, errors)
                if control_data is not None and ref_data is not None:
                    if control_data.get("workspace_id") != ref_data.get("workspace_id"):
                        errors.append("project identity snapshot workspace_id differs from 00_control source")
                    canonical = {
                        x.get("field_key"): (x.get("verbatim_value"), x.get("source_file"),
                                             x.get("source_location"), x.get("status"), x.get("locked"))
                        for x in control_data.get("fields", [])
                    }
                    snapshot = {
                        x.get("field_key"): (x.get("verbatim_value"), x.get("source_file"),
                                             x.get("source_location"), x.get("status"), x.get("locked"))
                        for x in ref_data.get("fields", [])
                    }
                    if canonical != snapshot:
                        errors.append("project identity snapshot differs from 00_control/project_identity.json")

    # Canonical response-priority/depth view must exactly match baseline decisions.
    priority_path = project_dir / "02_requirements" / "writing_priority_matrix.csv"
    if not priority_path.exists():
        if not service_mode:
            errors.append("writing_priority_matrix.csv missing; canonical priority/depth view is required")
    else:
        rows = _csv_rows(priority_path, errors) or []
        seen = set()
        expected = {str(x.get("item_id")): x for x in decisions}
        item_forms = {str(x.get("requirement_id")): x.get("response_form", decision_map.get(str(x.get("requirement_id")), {}).get("response_form", [])) for x in requirements}
        item_forms.update({str(x.get("scoring_id")): x.get("response_form", decision_map.get(str(x.get("scoring_id")), {}).get("response_form", [])) for x in scoring})
        for row_num, row in enumerate(rows, start=2):
            item_id = row.get("item_id", "")
            if not item_id or item_id in seen:
                errors.append(f"writing_priority_matrix.csv row {row_num}: missing or duplicate item_id {item_id!r}")
                continue
            seen.add(item_id); base = expected.get(item_id)
            if base is None:
                errors.append(f"writing_priority_matrix.csv row {row_num}: unknown item_id {item_id}")
                continue
            for field in ("item_type", "response_priority", "writing_depth"):
                if row.get(field, "") != str(base.get(field, "")):
                    errors.append(f"writing_priority_matrix.csv {item_id}: {field} differs from analysis_baseline")
            expected_form = ";".join(item_forms.get(item_id, [])) if isinstance(item_forms.get(item_id, []), list) else str(item_forms.get(item_id, ""))
            if row.get("response_form", "") != expected_form:
                errors.append(f"writing_priority_matrix.csv {item_id}: response_form differs from analysis_baseline")
        if seen != set(expected):
            errors.append(f"writing_priority_matrix.csv item coverage differs from baseline; missing={sorted(set(expected)-seen)[:10]}, extra={sorted(seen-set(expected))[:10]}")

    # Canonical service mapping view for V1.2.3; legacy chapter mapping view remains supported.
    if service_mode:
        plan_path = project_dir / "02_requirements" / "service_requirement_map.csv"
        if plan_path.exists():
            rows = _csv_rows(plan_path, errors) or []
            def service_mapping_key(x):
                return (str(x.get("item_id", "")), str(x.get("service_id", "")), str(x.get("mapping_role", "")))
            expected_map = {service_mapping_key(x): x for x in mappings}
            actual_map = {}
            for row_num, row in enumerate(rows, start=2):
                key = service_mapping_key(row)
                if not all(key) or key in actual_map:
                    errors.append(f"service_requirement_map.csv row {row_num}: missing or duplicate mapping {key}")
                    continue
                actual_map[key] = row
                decision = decision_map.get(key[0], {})
                for field in ("response_priority", "writing_depth"):
                    if row.get(field, "") != str(decision.get(field, "")):
                        errors.append(f"service_requirement_map.csv {key[0]}->{key[1]}: {field} differs from analysis_baseline")
            if set(actual_map) != set(expected_map):
                errors.append(f"service_requirement_map.csv mappings differ from baseline; missing={list(set(expected_map)-set(actual_map))[:10]}, extra={list(set(actual_map)-set(expected_map))[:10]}")
    else:
        plan_path = project_dir / "02_requirements" / "proposal_content_plan_matrix.csv"
        if not plan_path.exists():
            errors.append("proposal_content_plan_matrix.csv missing; canonical chapter-plan mapping view is required")
        else:
            rows = _csv_rows(plan_path, errors) or []
            def mapping_key(x):
                return (str(x.get("item_id", "")), str(x.get("chapter_id", "")), str(x.get("mapping_role", "")))
            expected_map = {mapping_key(x): x for x in mappings}
            actual_map = {}
            for row_num, row in enumerate(rows, start=2):
                key = mapping_key(row)
                if not all(key) or key in actual_map:
                    errors.append(f"proposal_content_plan_matrix.csv row {row_num}: missing or duplicate mapping {key}")
                    continue
                actual_map[key] = row
                decision = decision_map.get(key[0], {})
                for field in ("response_priority", "writing_depth"):
                    expected_value = decision.get(field, "")
                    if row.get(field, "") != str(expected_value):
                        errors.append(f"proposal_content_plan_matrix.csv {key[0]}->{key[1]}: {field} differs from analysis_baseline")
            if set(actual_map) != set(expected_map):
                errors.append(f"proposal_content_plan_matrix.csv mappings differ from baseline; missing={list(set(expected_map)-set(actual_map))[:10]}, extra={list(set(actual_map)-set(expected_map))[:10]}")

    # Compare derived CSVs to baseline where corresponding columns exist.
    requirement_view_items = []
    for item in requirements:
        decision = decision_map.get(item.get("requirement_id"), {})
        requirement_view_items.append({**item,
            "response_priority": decision.get("response_priority", item.get("response_priority")),
            "writing_depth": decision.get("writing_depth", item.get("writing_depth"))})
    req_view = project_dir / "02_requirements" / ("service_requirements.csv" if service_mode else "requirements_matrix.csv")
    _validate_derived_csv(req_view,
                          requirement_view_items, "requirement_id", "service_requirements" if service_mode else "requirements_matrix", errors, warnings)
    scoring_view_items = []
    for item in scoring:
        if item.get("kind") == "scored" and item.get("counts_toward_total") is True:
            decision = decision_map.get(item.get("scoring_id"), {})
            scoring_view_items.append({**item,
                "response_priority": decision.get("response_priority", item.get("response_priority")),
                "writing_depth": decision.get("writing_depth", item.get("writing_depth"))})
    score_view = project_dir / "02_requirements" / ("technical_scoring.csv" if service_mode else "scoring_strategy_matrix.csv")
    _validate_derived_csv(score_view,
                          scoring_view_items, "scoring_id", "technical_scoring" if service_mode else "scoring_strategy_matrix", errors, warnings)
    return data


def _validate_derived_csv(path: Path, items: list[dict], id_key: str, label: str,
                          errors: list[str], warnings: list[str]) -> None:
    if not path.exists():
        warnings.append(f"{label}.csv not present; derived-view consistency not checked")
        return
    rows = _csv_rows(path, errors)
    if rows is None:
        return
    by_id = {str(x.get(id_key)): x for x in items}
    seen = set()
    for row_num, row in enumerate(rows, start=2):
        item_id = row.get(id_key) or row.get("item_id") or row.get("scoring_id") or row.get("requirement_id")
        if not item_id:
            errors.append(f"{label}.csv row {row_num}: missing {id_key}")
            continue
        if item_id in seen:
            errors.append(f"{label}.csv: duplicate {id_key} {item_id}")
        seen.add(item_id)
        base = by_id.get(item_id)
        if base is None:
            errors.append(f"{label}.csv row {row_num}: {item_id} absent from analysis_baseline")
            continue
        compare_fields = [("response_priority", "response_priority"), ("writing_depth", "writing_depth")]
        if id_key == "scoring_id":
            compare_fields.extend([("parent_scoring_id", "parent_scoring_id"), ("max_score", "max_score")])
        for col, canonical in compare_fields:
            if row.get(col) not in (None, "") and base.get(canonical) not in (None, ""):
                left, right = row[col], str(base[canonical])
                if col == "max_score":
                    try:
                        same = abs(float(left) - float(right)) <= 1e-6
                    except ValueError:
                        same = False
                else:
                    same = left == right
                if not same:
                    errors.append(f"{label}.csv {item_id}: {col} differs from analysis_baseline")
    missing = set(by_id) - seen
    if missing:
        warnings.append(f"{label}.csv is missing {len(missing)} baseline items: {', '.join(sorted(missing)[:10])}")



def validate_project_markdown_identity(project_dir: Path, identity: dict | None, errors: list[str], warnings: list[str]) -> None:
    """Cross-check the human-readable PROJECT.md identity snapshot against canonical JSON."""
    md = project_dir / "00_control" / "PROJECT.md"
    if not md.exists():
        return
    text = md.read_text(encoding="utf-8")
    labels = {
        "tender_project_code": "招标项目编号（原文锁定）",
        "tender_project_name": "招标项目名称（原文锁定）",
        "workspace_id": "内部 workspace_id",
        "document_version": "文档版本",
    }
    values = {}
    for line in text.splitlines():
        stripped = line.strip()
        for key, label in labels.items():
            prefix = f"- {label}："
            if stripped.startswith(prefix):
                values[key] = stripped[len(prefix):].strip()
    if identity is None:
        warnings.append("PROJECT.md exists but canonical project_identity.json could not be loaded")
        return
    if values.get("workspace_id") and values["workspace_id"] != identity.get("workspace_id"):
        errors.append("PROJECT.md internal workspace_id differs from project_identity.json")
    if values.get("document_version") and values["document_version"] != identity.get("document_version"):
        errors.append("PROJECT.md document_version differs from project_identity.json")
    for field in identity.get("fields", []):
        key = field.get("field_key")
        label = labels.get(key)
        if not label:
            continue
        shown = values.get(key, "")
        status = field.get("status")
        canonical = str(field.get("verbatim_value") or "").strip()
        if status == "confirmed":
            if not shown or shown != canonical:
                errors.append(f"PROJECT.md {label} differs from confirmed project_identity.json value")
        elif status in {"not_found", "unclear", "conflict"}:
            if shown and shown not in {"待从招标原文提取", "待确认", "存在冲突", "未找到"}:
                errors.append(f"PROJECT.md {label} contains a value while canonical identity status is {status}")

def validate_project(project_dir: Path) -> tuple[list[str], list[str]]:
    errors, warnings = [], []
    identity_path = project_dir / "00_control" / "project_identity.json"
    identity = None
    if identity_path.exists():
        identity = validate_project_identity(identity_path, errors, warnings)
    else:
        warnings.append("00_control/project_identity.json not present")
    validate_project_markdown_identity(project_dir, identity, errors, warnings)
    validate_analysis_baseline(project_dir, errors, warnings)
    return errors, warnings

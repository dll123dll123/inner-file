from pathlib import Path
import argparse
import sys
from analysis_validation import validate_project

def main():
    parser = argparse.ArgumentParser(description="Validate tender analysis baseline and project identity.")
    parser.add_argument("project_dir", type=Path, help="Project workspace directory")
    args = parser.parse_args()
    project_dir = args.project_dir.resolve()
    if not project_dir.is_dir():
        raise SystemExit(f"Project directory not found: {project_dir}")
    errors, warnings = validate_project(project_dir)
    print(f"Project: {project_dir}")
    print(f"Errors: {len(errors)}")
    print(f"Warnings: {len(warnings)}")
    for item in errors:
        print("ERROR:", item)
    for item in warnings:
        print("WARNING:", item)
    return 1 if errors else 0

if __name__ == "__main__":
    sys.exit(main())

# 主理人调度 / 原生召唤 / 六成员协作 证据

测试时间：2026-11-20
本文件记录本轮「原生专家团召唤与六成员协作」的逐项排查实测证据。

## 一、配置层排查（全部正常）

| 排查项 | 结果 | 实测证据 |
|---|---|---|
| 隔离配置存在 | PASS | `...\write-skill-wb\_isolated_config` 存在 |
| proposal-team 已注册 | PASS | `marketplace.json` 的 `plugins[]` 含 `proposal-team`（source `./plugins/proposal-team`），`.created-by-session` 标记存在 |
| 专家团配置完整 | PASS | 隔离包内 `agents/` = 7 个 MD（主理人 + 6 成员），`skills/` = 9 个目录 |
| 启动脚本存在 | PASS | `launch_isolated_workbuddy.ps1` 内嵌实测 EXE 路径与隔离配置路径，进程级 `WORKBUDDY_CONFIG_DIR` |

## 二、原生召唤能力排查（按用户指定顺序逐项实测）

| # | 排查步骤 | 实测结果 |
|---|---|---|
| 1 | 隔离配置是否被客户端实际读取 | **否**。当前会话 `WORKBUDDY_CONFIG_DIR=C:\Users\h36919\.workbuddy`（真实配置）。启动隔离实例后，隔离目录仍只有 `plugins/`，无 `logs/`、无 `app/`，证明客户端从未读取隔离配置。 |
| 2 | 注册目录及 marketplace.json | 正常（见第一节）。注册层无问题。 |
| 3 | 是否需要刷新专家列表 | 无法验证：无 UI 操作能力，且隔离配置未被任何运行中实例加载，刷新也看不到该专家团。 |
| 4 | 账号下可见性 | 无法验证：专家团只在未加载的隔离配置中，当前账号的真实配置 `my-experts` 为空。 |
| 5 | 召唤入口是否存在 / 权限限制 | 当前 Agent 会话工具集中无「召唤专家团/新建会话/切换专家」入口；`search_plugins` 仅覆盖 connector/expert，无 computer-use 插件可装。 |
| 6 | 是否支持独立隔离实例 | **不支持（实测）**：见第三节。 |

## 三、独立隔离实例启动实测（决定性证据）

在无 UI 操作能力的前提下，用进程级环境变量实测能否启动第二个隔离实例：

```
启动前: WorkBuddy 进程数 = 10，PID = 38312,36696,14648,44096,37844,2900,37300,9108,15944,40136
操作:   $env:WORKBUDDY_CONFIG_DIR = <isolated_config>; Start-Process WorkBuddy.exe -PassThru
启动进程: PID 6180
启动后: WorkBuddy 进程数 = 10（未增加）
新进程数 = 0
PID 6180 是否存活 = False（已退出）
```

所有运行进程的 `--user-data-dir` 均为 `C:\Users\h36919\.workbuddy\app`（唯一值），隔离目录未生成 `app/` 或 `logs/`。真实配置日志 `main.log`/`daemon.log` 在启动时刻 14:49 更新，说明新进程参数被转发给已有单一实例后退出。

**结论**：WorkBuddy 采用单实例机制，第二个实例无法以隔离配置独立运行；在不关闭现有进程（用户明确禁止强杀）的前提下，无法让任何客户端进程加载隔离配置。

## 四、UI 操作能力排查

- 工具检索「computer use / 桌面控制 / 截图点击 / 浏览器操作 / GUI 自动化」：无任何可用工具。
- `workbuddy-computer-use` / `workbuddy-browser-use` skill 未在当前会话可用列表中；本机未安装对应插件。
- `search_plugins`（type=expert/connector）无法用于安装 computer-use 类工具。
- 因此即使有隔离实例，也无法在 UI 中点击「专家中心 → 召唤」。

## 五、六成员协作判定

| 项目 | 状态 | 说明 |
|---|---|---|
| 原生召唤主理人 proposal-team-lead | BLOCKED | 无召唤工具 + 隔离配置未被加载 + 无法独立启动隔离实例 |
| 主理人接收/拆分任务 | BLOCKED | 依附于原生召唤 |
| 六个成员真实调用记录 | BLOCKED | 依附于原生召唤；按用户边界不得用普通 Agent 派生代替 |
| 六个成员加载对应 Skill | BLOCKED | 同上 |
| 六份 `*_result.md` 独立产物 | 未生成 | 成员未被真实唤醒，不伪造文件 |
| 成员回传 / 主理人核验汇总 | BLOCKED | 无实际记录 |

## 六、卡点与所需用户操作

**卡在哪一步**：隔离配置无法被任何运行中的客户端加载（单实例锁 + 禁止强杀），且当前 Agent 会话无原生召唤工具与桌面 UI 控制能力。

**已尝试**：配置层全检、进程级环境变量启动隔离实例（实测失败）、UI 工具能力检索、search_plugins 探查。

**实际表现/错误**：启动进程 PID 6180 立即退出，进程数不变，隔离目录无运行时产物，真实配置日志在启动时刻更新。

**需要的用户操作**（二选一）：
1. 完全退出所有 WorkBuddy 进程（含托盘），运行 `launch_isolated_workbuddy.ps1` 以隔离配置启动客户端，在 UI 中召唤「网络安全技术服务方案专家团」并按第四节任务执行；或
2. 授权将 `proposal-team` 注册到真实用户配置的 `my-experts`（当前为空，不覆盖任何专家），刷新专家列表后召唤。

## 七、边界声明

- 未将会话缺少 Agent 调用工具等同于「WorkBuddy 产品不支持专家团」——产品配置层、注册层证据完整， blockage 在当前会话环境与单实例机制。
- 未用普通 Agent 派代替原生召唤，未伪造六份成员产物与调用日志。
- 未修改 Skill 正文、references、Agent MD、plugin.json、专家团配置或原始迁移包。

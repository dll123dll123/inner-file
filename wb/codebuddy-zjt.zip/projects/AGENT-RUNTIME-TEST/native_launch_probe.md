# 原生启动探测 · 原始命令输出记录

时间：2026-11-20
用途：本轮「必要的原生调用日志证据」——记录隔离实例启动实测的原始输出，未加工。

## 1. 隔离配置注册检查（原始输出节选）

```
iso_exists=True
marketplace_json_exists=True
{
  "name": "my-experts",
  "plugins": [{ "name": "proposal-team",
                "source": "./plugins/proposal-team", ... }]
}
plugin_dir_exists=True
session_marker=True
agents=7
skills=9
launch_script_exists=True
workbuddyExe = 'C:\Users\h36919\AppData\Local\Programs\WorkBuddy\WorkBuddy.exe'
isolatedConfig = '...\write-skill-wb\_isolated_config'
```

## 2. 进程 user-data-dir 检查（原始输出节选）

```
process_count=10
distinct user-data-dir:
  C:\Users\h36919\.workbuddy\app      （唯一值）
```

## 3. 隔离实例启动实测（原始输出）

```
before_count=10
before_pids=38312,36696,14648,44096,37844,2900,37300,9108,15944,40136
$env:WORKBUDDY_CONFIG_DIR = <isolated_config>
Start-Process WorkBuddy.exe -PassThru
launched_pid=6180
after_count=10
new_process_count=0
launched_pid_alive=False
```

## 4. 启动后配置目录与日志（原始输出节选）

```
isolated config contents:
  plugins    (LastWriteTime 2026/11/19 16:40:29)
isolated_logs_created=False
isolated_app_created=False
real config newest logs:
  daemon.log    2026/11/20 14:49:56
  renderer.log  2026/11/20 14:49:56
  main.log      2026/11/20 14:49:54
```

## 解读

启动进程 6180 立即退出（`alive=False`），进程总数不变（10→10，新进程 0）；隔离目录未生成任何运行时产物；真实配置日志在启动时刻更新。据此判断：WorkBuddy 单实例机制将新进程参数转发至已有（真实配置）实例后退出，隔离配置未被任何客户端加载。

## 边界

- 未强制结束任何现有 WorkBuddy 进程。
- 未修改系统级/用户级环境变量（仅进程级设置并在命令结束清除）。
- 未修改真实用户配置、未重新安装专家团、未修改 Skill/Agent/plugin 配置。

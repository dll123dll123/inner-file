# 项目控制区

本目录保存项目身份、阶段状态、任务、决策和全局术语。项目身份锁定文件是招标原文基础信息的唯一事实源。

## 核心文件
- `PROJECT.md`：项目说明和用户确认事项。
- `project_identity.json`：招标项目名称、招标项目编号、采购人、截止时间、服务期限等原文事实及来源定位；内部 workspace_id 与招标项目编号分开。
- `STATE.json`：当前阶段和阶段状态。
- `TASKS.json`：任务、依赖、输入、输出、验收标准和执行状态。
- `DECISIONS.md`：用户确认的重大决策。
- `GLOBAL_TERMS.md`：跨章节统一术语。
- `CHANGELOG.md`：分析基线、方案和正文变更记录。

不要在项目身份锁定文件未建立前批量写作。招标项目编号和项目名称不得因文档版本或内部工作区命名而改写。


## 项目身份锁定
- `workspace_id` 是内部工作区编号，由初始化脚本写入；它不是招标项目编号。
- `document_version` 是投标文档版本，不属于招标项目编号。
- 招标项目编号、项目名称、采购人、截止时间、服务期限等字段，只有在存在原文值、来源文件和来源位置且 `status=confirmed` 时才允许 `locked=true`。
- `not_found`、`unclear`、`conflict` 状态必须保持 `locked=false`；不得将占位符或推测值锁定。
- 身份字段确认后由 Orchestrator 统一更新；其他 Agent 只读引用。
- `EXECUTION_AUDIT.jsonl`：由 `project_guard.py` 追加记录受控写入、任务状态、阶段状态和中断恢复事件。该文件是追加式审计记录，不得由 Agent 覆盖或删除。

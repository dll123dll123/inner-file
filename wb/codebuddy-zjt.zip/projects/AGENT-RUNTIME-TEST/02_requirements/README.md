# 02_requirements

本目录只保存**技术服务方案相关的招标需求分析成果**，不是整本招标文件分析或完整投标策略。

规范化事实源：
- `analysis_baseline.json`：技术服务需求、技术评分、服务归属、优先级、展开深度和技术不确定项的唯一事实源。

主要成果：
- `project_understanding.md`：与技术服务有关的客户背景、采购目标和需求理解。
- `service_requirements.csv`：原子化技术服务需求及原文定位。
- `technical_scoring.csv`：技术评分原文、档次、满分条件和写作响应。
- `service_requirement_map.md`：按客户采购服务归纳目标、范围、明确工作项、约束、交付和评分关注点；不是正式目录。
- `technical_priority_analysis.md`：技术服务内容的优先级和展开深度。
- `technical_constraints.md`：影响技术服务设计和实施的约束。
- `ambiguities.md`：技术服务相关不确定项、处理建议和状态。
- `analysis_coverage_check.md`：仅核验技术需求和技术评分覆盖。

不生成公司资质/商务分析、投标保证金、投标有效期、报价、完整投标文件结构或正式章节映射。最终目录由 Outline Planner 在专业服务设计完成后生成。

所有 CSV/Markdown 视图必须与 `analysis_baseline.json` 保持一致。完成后运行 `python tools/validate_analysis.py projects/<workspace_id>`；错误阻断阶段完成。报告不得声称完成整本招标文件审查。

# 最终投标就绪检查报告

## 基本信息
- 招标项目名称：
- 招标项目编号：
- 项目工作区 ID：
- 文档版本：
- 检查日期：

## 一、分项状态
| 状态维度 | 状态 | 依据文件/检查结果 | 未完成事项 |
|---|---|---|---|
| 技术方案内容 | PASS / PASS_WITH_CONDITIONS / BLOCKED / FAILED | | |
| DOCX/PDF 文档发布 | PASS / PASS_WITH_CONDITIONS / BLOCKED / FAILED | | |
| 资格与企业资质材料 | PASS / BLOCKED / NOT_APPLICABLE | | |
| 人员、证书、社保与履历 | PASS / BLOCKED / NOT_APPLICABLE | | |
| 业绩、案例与证明 | PASS / BLOCKED / NOT_APPLICABLE | | |
| 商务、报价、偏离与承诺 | PASS / BLOCKED / NOT_APPLICABLE | | |
| 签章、格式、递交要求 | PASS / BLOCKED / NOT_APPLICABLE | | |

## 二、外部阻断清单
| blocker_id | 招标依据 | 缺失/未确认事项 | 影响 | 责任人 | 解除条件 | 状态 |
|---|---|---|---|---|---|---|

## 三、最终判断
- technical_document_status：
- document_publish_status：
- bid_package_status：
- submission_readiness：READY / BLOCKED / NOT_VERIFIABLE

只有所有 P0 资格/否决要求和必要证明均已满足、招标时效已确认、Critical 问题已关闭，才能标记 `READY`。技术方案通过或 Word 生成成功不等于完整投标包可提交。

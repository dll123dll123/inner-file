# 技术服务需求记录字段

每条记录只描述一个与技术服务方案直接相关的要求。

- `requirement_id`：稳定编号，如 R-001。
- `requirement_type`：`explicit_requirement` / `technical_context` / `design_input`。
- `service_id`、`service_name`：所属采购服务；尚无法归属时留空并说明。
- `original_text`：精确原文摘录，不跨越无关段落。
- `normalized_requirement`：忠实于原文的简明表达。
- `conditions`：对象、范围、数量、频率、时间、例外和前置条件。
- `source_ref`：文件、页码、章节、表格及行列等定位。
- `related_scoring_ids`：直接相关的技术评分编号；无关联时为空并说明。
- `response_priority`：P1/P2/P3，仅评价技术方案响应优先级。
- `writing_depth`：D4/D3/D2/D1，仅评价技术方案展开深度。
- `uncertainty_flag`：是否存在影响理解或设计的不确定性。
- `notes`：专业分析建议与招标明确要求必须区分。

不设置企业资格、商务响应、投标有效性、报价或最终章节编号字段。

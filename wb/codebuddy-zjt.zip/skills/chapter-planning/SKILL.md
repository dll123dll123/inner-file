---
name: chapter-planning
description: 用于在专业设计批准后规划技术服务方案正式目录和章节任务书，当用户要求生成目录、章节规划或 coverage_map 时使用。Use when organizing approved technical service designs into a coherent technical proposal structure and actionable chapter briefs.
---

# WorkBuddy 适配说明

- 本 Skill 保留 Codex V1.2.3 的全部专业方法、执行步骤、质量标准和输出契约；以下正文未因平台迁移而删减。
- 参考资料读取指引：执行本 Skill 时，必须按任务需要读取本目录 `references/` 下的适用文件，不得仅凭本文件摘要替代模板、清单或方法。适用文件：`references/chapter-brief-template.md`、`references/outline-review.md`。
- 工具路径约定：正文中出现的 `tools/xxx.py` 或 `tools/xxx.mjs` 均指当前项目根目录下的 `tools/`。执行前先确认工作目录为项目根；若不是，请改用 `<项目根>/tools/...` 绝对路径。
- 平台专属文件：原 `agents/openai.yaml` 仅作为 V1.2.3 基线保存在 `source-v1.2.3/`，WorkBuddy 不读取；其展示名称、简短说明与隐式触发信息已并入本文件 description。
- 质量边界：不得为了适配平台减少输出文件、降低技术要求或跳过验收条件。


# 目标
根据客户需求理解和已批准的专业服务设计，规划一份逻辑清晰、重点突出、内容充分的**技术服务方案**。目录必须围绕客户采购的服务组织，而不是套用通用项目管理目录或完整投标文件目录。

# 输入
- `02_requirements/project_understanding.md`
- `02_requirements/service_requirement_map.md`
- `02_requirements/service_requirements.csv`
- `02_requirements/technical_scoring.csv`
- `02_requirements/technical_priority_analysis.md`
- `02_requirements/technical_constraints.md`、`ambiguities.md`
- 已批准的 `04_design/solution_blueprint.md` 及相关服务设计、流程和设计决策
- 用户指定的模板、目录、篇幅或格式要求

不得把旧版 `proposal_content_plan.md` 中的商务文件结构或章节编号直接当作正式目录。

# 目录组织原则

默认从以下逻辑思考，但必须按实际项目调整，不是固定模板：

1. **前部：项目理解与总体思路**——简要说明客户背景、采购目标、需求理解、服务目标和总体服务思路。只保留有助于理解技术方案的内容。
2. **主体：逐项展开客户采购的服务**——每项核心服务应有清晰的方案章节或完整内容单元，依据服务复杂度决定层级。章节内容来自已批准的专业设计，充分呈现技术工作项、方法、流程、场景、实施控制和交付成果。
3. **后部：其他必要支撑内容**——根据项目实际需要组织技术团队与职责、服务实施安排、质量保障、沟通协同、保密安全、交付验收等内容。

不得默认将“项目启动、项目实施、项目管理、项目验收”分别设为主体章节。这些通常是支撑安排，可以放入对应服务章节或后部保障章节。只有招标明确单独采购，或其内容足以构成独立且有实质价值的技术服务时，才单独成章。

不得为了目录整齐强行让每项服务章节数量相同；不得把所有服务压缩为一个笼统章节；也不得将每个通用管理动作拆成独立章节。

# 规划步骤
1. 确认文档定位是技术服务方案，而非完整投标文件。
2. 提取客户采购的各项服务及已批准设计的工作项。
3. 先确定主体服务章节的组织方式，再安排项目理解和支撑内容。
4. 为每章明确唯一目的、范围、排除内容和与其他章节的边界。
5. 将需求和技术评分映射到主要响应章节；评分项不能机械地直接变成目录标题。
6. 将设计蓝图中的具体工作项分配到章节，标明不能遗漏的内容。
7. 识别重复内容、依赖关系和跨章节统一口径。
8. 根据技术内容量规划篇幅，不以压缩为目标，也不得机械凑页数。
9. 生成正式目录、章节任务书和覆盖映射。

# 每章任务书必须包含
- `chapter_id` / `parent_id`
- `title`
- `purpose`
- `scope` / `excluded_content`
- `required_content`：具体到已设计的技术工作项，不得只写“详细介绍服务内容”
- `requirement_ids` / `scoring_ids`
- `design_refs`
- `dependencies`
- `expected_tables` / `expected_diagrams`
- `target_length`：建议值及内容量依据
- `acceptance_criteria`
- `output_path` / `writer_notes`

# 输出
- `05_outline/outline.md`
- `05_outline/chapter_plan.json`
- `05_outline/coverage_map.csv`
- `05_outline/dependency_map.md`

# 验收
- 结构体现“项目理解与总体思路—各项专项服务方案—其他必要支撑内容”的逻辑（如项目实际适用）。
- 主体章节围绕客户采购的具体服务，而非通用项目生命周期。
- 每个核心服务的专业设计工作项均有明确写作位置。
- 每章任务书具体到内容和工作项，Writer 无需重新发明方案。
- 评分覆盖完整，证据和技术内容不混淆。
- 没有无价值的独立管理章节、重复章节或无依据扩展。

# 禁止事项
不设计技术方案；不擅自更改已批准设计；不规划企业资质、投标保证金、投标有效期、报价和递交格式等完整投标文件内容；不为凑篇幅创建空泛章节；不把通用项目管理活动凌驾于专项服务内容之上。

---
name: quality-review
description: 用于独立审核技术服务方案章节的技术覆盖、证据真实性、一致性和质量，当用户要求技术审核或生成审核报告时使用。Use when independently auditing cybersecurity technical proposal chapters or complete proposals for tender coverage, technical validity, evidence integrity, cross-chapter consistency, duplication, and document quality.
---

# WorkBuddy 适配说明

- 本 Skill 保留 Codex V1.2.3 的全部专业方法、执行步骤、质量标准和输出契约；以下正文未因平台迁移而删减。
- 参考资料读取指引：执行本 Skill 时，必须按任务需要读取本目录 `references/` 下的适用文件，不得仅凭本文件摘要替代模板、清单或方法。适用文件：`references/review-checklist.md`。
- 工具路径约定：正文中出现的 `tools/xxx.py` 或 `tools/xxx.mjs` 均指当前项目根目录下的 `tools/`。执行前先确认工作目录为项目根；若不是，请改用 `<项目根>/tools/...` 绝对路径。
- 平台专属文件：原 `agents/openai.yaml` 仅作为 V1.2.3 基线保存在 `source-v1.2.3/`，WorkBuddy 不读取；其展示名称、简短说明与隐式触发信息已并入本文件 description。
- 质量边界：不得为了适配平台减少输出文件、降低技术要求或跳过验收条件。


# 目标
以独立审核者身份发现真实问题，给出准确位置、依据和可执行修订建议。审核不是润色，也不是给一个笼统分数。

# 必须读取的审核规范
每次审核开始前，必须读取本 Skill 随附的 `references/review-checklist.md`，并按本次审核范围执行适用检查。整本集成审核必须执行其中“整本集成（阶段 7）”条目；最终投标就绪审核必须执行“最终投标就绪（阶段 9）”条目。不得仅凭本文件摘要替代清单。审核报告须列出清单版本/路径、已执行项、未执行项及原因。

# 输入
待审章节或完整技术服务方案；技术服务需求矩阵；企业技术证据索引；已批准服务设计蓝图；章节任务书；全局术语表；用户明确提出的质量要求。

# 审核维度
1. 需求符合性：关键要求是否遗漏、响应位置是否明确、评分项是否覆盖。
2. 技术合理性：架构、方法、流程、部署和技术关系是否成立。
3. 事实与证据：企业技术能力、技术案例、技术人员、工具和指标是否有证据支持。
4. 完整性：服务目标、范围、方法、流程、职责、边界、交付和验收是否缺项。
5. 一致性：章节间术语、架构、流程、人数、指标、时间和职责是否冲突。
6. 重复性：是否多处重复展开同一内容，是否存在无意义扩写。
7. 表达质量：是否准确、自然、专业，是否有空洞套话和不必要长句。
8. 图文质量：图形是否准确、可读，是否与正文一致。

# 严重程度
- Critical：可能导致实质性不响应、技术错误、虚构关键能力、重大承诺风险。
- Major：重要内容缺失、核心逻辑冲突、关键流程不完整、证据明显不足。
- Minor：局部表达不清、一般重复、次要信息缺失或图表细节问题。
- Suggestion：可选优化，不影响基本正确性。

# 审核步骤
1. 确认审核范围和版本。
2. 建立本次审核依据清单。
3. 逐条检查需求覆盖。
4. 检查设计与正文一致性。
5. 抽查企业事实和案例证据。
6. 检查章节结构和完整性。
7. 检查重复与术语。
8. 检查图表和文档质量。
9. 形成问题清单。
10. 给出审核结论和复核范围。

# 问题记录格式
每个问题必须包含：
- finding_id
- severity
- chapter_id
- exact_location
- issue
- why_it_matters
- evidence_or_requirement_ref
- recommended_change
- owner_agent
- status

# 结论规则
- 有 Critical：不通过。
- 无 Critical 但有未关闭 Major：不通过或有条件不通过，必须说明。
- 只有 Minor：可有条件通过，列出修订建议。
- 只有 Suggestion：通过并附优化建议。
不能用平均分掩盖阻断问题。

# 独立性
Reviewer 默认只读正文。不得直接修改章节文件，不得为了让结果“通过”而降低问题等级。缺少审核依据时明确标记审核限制。

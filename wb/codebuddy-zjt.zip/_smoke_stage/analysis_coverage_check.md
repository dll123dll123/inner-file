# 分析覆盖检查

仅覆盖 01_input/simulated_tender.md 中的技术需求与评分段，不声称完成整本招标文件覆盖。

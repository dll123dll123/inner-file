# launch_isolated_workbuddy.ps1
# Purpose : Start WorkBuddy with an isolated WORKBUDDY_CONFIG_DIR so the locally
#           registered "proposal-team" expert team becomes visible in the UI.
# Scope   : Process-level env var only. Does NOT change system/user env vars,
#           does NOT touch the real user config, does NOT kill any process.
# Note    : ASCII-only messages to stay readable under Windows PowerShell 5.1.

$ErrorActionPreference = 'Stop'

# Verified from running processes on this machine (ProductVersion 5.11.3.0).
# No path guessing: this is the single WorkBuddy.exe found under the user profile.
$workbuddyExe = 'C:\Users\h36919\AppData\Local\Programs\WorkBuddy\WorkBuddy.exe'

# Isolated config root that already contains the registered proposal-team.
$isolatedConfig = 'C:\Users\h36919\Desktop\agent\doubao-dir\write-skill-wb\_isolated_config'
$marketplaceJson = Join-Path $isolatedConfig 'plugins\marketplaces\my-experts\.codebuddy-plugin\marketplace.json'

Write-Host '=== WorkBuddy isolated-config launcher ==='

# Preconditions
if (-not (Test-Path -LiteralPath $workbuddyExe)) {
    Write-Error "WorkBuddy EXE not found: $workbuddyExe"
    exit 1
}
if (-not (Test-Path -LiteralPath $marketplaceJson)) {
    Write-Error "Isolated registration not found: $marketplaceJson"
    exit 1
}
Write-Host "[OK] EXE      : $workbuddyExe"
Write-Host "[OK] Config   : $isolatedConfig"
Write-Host "[OK] Marketplace entry present."

# Guard: do not force-kill anything. Ask the user to quit cleanly first.
$running = @(Get-Process -Name 'WorkBuddy' -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) {
    $pids = ($running | ForEach-Object { $_.Id }) -join ', '
    Write-Host ''
    Write-Host "[ACTION REQUIRED] $($running.Count) WorkBuddy process(es) are still running (PID: $pids)." -ForegroundColor Yellow
    Write-Host 'Please quit WorkBuddy completely from the UI (all windows + tray icon -> Exit),' -ForegroundColor Yellow
    Write-Host 'then run this script again. This script never terminates a process for you.' -ForegroundColor Yellow
    Write-Host ''
    exit 2
}

# Process-level environment variable only. Child process inherits it; nothing persistent is changed.
$env:WORKBUDDY_CONFIG_DIR = $isolatedConfig
Write-Host "[OK] Set process-level WORKBUDDY_CONFIG_DIR (this session only)."

# Launch using the verified EXE path.
Start-Process -FilePath $workbuddyExe
Write-Host '[OK] WorkBuddy launched with the isolated config.'
Write-Host ''
Write-Host 'Next steps in the WorkBuddy UI:'
Write-Host '  1) Expert Center -> My Experts -> "Cybersecurity Proposal Team" (network-security proposal team).'
Write-Host '  2) Summon it, then run the Phase 2 requirement-analysis task in the acceptance report.'
Write-Host '  3) If the team does not appear, confirm the running instance is using the isolated config.'

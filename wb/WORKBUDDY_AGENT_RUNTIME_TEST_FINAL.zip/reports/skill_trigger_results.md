# 9 个 Skill 触发 / 加载 / 执行验证结果

测试项目：`AGENT-RUNTIME-TEST`（隔离配置内的独立临时项目，未触碰 PHASE2-001）
测试时间：2026-11-20
验证范围：仅运行机制（触发、加载、执行、产物），不评价专业内容质量。

## 0. 三类调用的判定口径（重要）

本报告严格区分三类情形，不混为一谈：

| 类别 | 定义 | 本次判定 |
|---|---|---|
| **自动触发** | 自然语言任务下，WorkBuddy 依据 Skill 的 `description` 自动匹配并加载 | **FAIL（9/9）** |
| **手动指定调用** | 在指令中明确给出 `SKILL.md` 绝对路径，由执行体读取并按其中方法执行 | **PASS（9/9）** |
| **仅读取文件** | 只读 `SKILL.md` 不执行任何任务 | 未采用；每个测试均有实际最小执行动作 |

**关键证据**：9 个 Skill 均未注册到当前会话的运行时 Skill 表。实测用 Skill 工具按名称调用 `requirement-analysis` 等 9 个名称，全部返回 `Error: Can not find skill: "<name>". Also checked for slash command "/<name>" but not found.`；运行时用户 Skill 目录与工作区 Skill 目录中均无这 9 个业务 Skill（它们仅存在于隔离配置的专家团包 `proposal-team/skills/` 内）。因此**自动触发在当前会话条件下不成立**。

## 1. 逐 Skill 结果表

| # | Skill | 自动触发 | 实际加载（手动指定路径） | 实际执行 | 测试产物 |
|---|---|---|---|---|---|
| 1 | requirement-analysis | FAIL（未注册） | PASS（读取 SKILL.md + 2 个 references） | PASS（提取 3 条技术服务需求，关联 2 项评分） | `_evidence/skill_artifacts/requirement-analysis_result.md`（1584 B） |
| 2 | enterprise-knowledge | FAIL（未注册） | PASS（SKILL.md + 2 个 references） | PASS（提取 2 条带来源技术证据） | `enterprise-knowledge_result.md`（1635 B） |
| 3 | solution-design | FAIL（未注册） | PASS（SKILL.md + 2 个 references） | PASS（逐项服务方法/输出/机制设计） | `solution-design_result.md`（1904 B） |
| 4 | chapter-planning | FAIL（未注册） | PASS（SKILL.md + 2 个 references） | PASS（生成 5 章目录） | `chapter-planning_result.md`（1169 B） |
| 5 | chapter-writing | FAIL（未注册） | PASS（SKILL.md + 3 个 references） | PASS（写约 200 字安全监测章节） | `chapter-writing_result.md`（970 B） |
| 6 | diagram-design | FAIL（未注册） | PASS（SKILL.md + 2 个 references） | PASS（生成事件响应 Mermaid 图） | `diagram-design_result.md`（1402 B） |
| 7 | quality-review | FAIL（未注册） | PASS（SKILL.md + 1 个 references） | PASS（输出 3 个分级问题 + 结论） | `quality-review_result.md`（2995 B） |
| 8 | word-publishing | FAIL（未注册） | PASS（SKILL.md + 1 个 references） | PASS（生成 23 项发布检查记录） | `word-publishing_result.md`（1964 B） |
| 9 | proposal-orchestrator | FAIL（未注册） | PASS（SKILL.md + 3 个 references） | PASS（生成阶段任务拆分表） | `proposal-orchestrator_result.md`（2334 B） |

产物路径前缀均为：
`C:\Users\h36919\Desktop\agent\doubao-dir\write-skill-wb\_isolated_config\plugins\marketplaces\my-experts\plugins\proposal-team\projects\AGENT-RUNTIME-TEST\`

## 2. 加载与执行证据

- 每个产物文件头部均有「证据头」区块，记录：`skill_name`、`SKILL.md` 绝对路径、实际读取的 references 文件名列表、模拟输入路径。
- 主理人侧独立核验：9/9 产物文件真实存在、非空（970–2995 字节）、含证据头，未采信执行体的口头回传。
- 每个执行体均完成一个最小任务并落盘，不是仅读取文件。
- 执行体使用独立派生上下文（相当于每个 Skill 一个新会话上下文），避免了先前加载上下文的干扰。

## 3. 结论

- **自动触发：FAIL** —— 9 个业务 Skill 未注册到当前会话运行时 Skill 表，Skill 工具按名称调用全部报 `Can not find skill`。这是平台加载机制限制，不是 Skill 正文问题。
- **手动加载 + 实际执行：PASS（9/9）** —— 明确指定 `SKILL.md` 路径后，9 个 Skill 均可被读取、引用 references、执行最小任务并生成产物。
- **说明**：手动加载测试采用普通 Agent 派生提供独立上下文，这是当前会话可执行的验证方式；它证明 Skill 正文可用，但不证明 WorkBuddy 原生按 `description` 自动触发的能力。后者需在已加载专家团的隔离客户端中实测。

# word-publishing Skill 运行能力验证 — 文档发布检查记录

## 证据头（Evidence Header）

- **skill_name**: word-publishing
- **SKILL.md 绝对路径**: `C:\Users\h36919\Desktop\agent\doubao-dir\write-skill-wb\_isolated_config\plugins\marketplaces\my-experts\plugins\proposal-team\skills\word-publishing\SKILL.md`
- **实际读取的 references 文件列表**:
  - `references/docx-preflight.md`（SKILL.md 第 9 行指定的适用文件）
- **模拟输入路径**: `C:\Users\h36919\Desktop\agent\doubao-dir\write-skill-wb\_isolated_config\plugins\marketplaces\my-experts\plugins\proposal-team\projects\AGENT-RUNTIME-TEST\01_input\simulated_input.md`
- **执行性质**: 手动指定 SKILL.md 路径 + 实际执行的最小任务；全部输入为合成数据，非真实客户项目。

---

## 文档发布检查项清单（最小任务）

依据 SKILL.md 的「前置条件 / 发布步骤 / 发布验收」与 `references/docx-preflight.md`，针对本次模拟输入（安全监测技术服务方案）整理。本次仅产出检查记录，不生成 DOCX、不安装依赖。

### A. 发布前检查（对应 docx-preflight.md + SKILL.md 前置条件）
1. 模板是否为最终版本，且未被擅自覆盖。
2. 封面、目录、正文、附件结构是否明确划分。
3. 是否存在统一的标题样式（标题层级样式是否规范化）。
4. 是否有页眉页脚与页码规则，是否符合模板。
5. 图片是否有源文件，清晰度是否满足要求。
6. 表格是否需要重复标题行。
7. 是否存在横向页面或特殊分节。
8. 目录为自动目录还是固定目录，是否与模板要求一致。
9. 是否有客户指定字体或版式（字体缺失检查）。
10. 是否有禁止修改的内容（Logo、品牌色、页面设置等模板保护项）。
11. 章节文件、图片、表格资源是否齐全；章节顺序是否按批准目录排列。
12. 术语与编号是否已统一；Critical 及未关闭 Major 问题是否已处理或经明确接受。

### B. 文档质量检查（对应 SKILL.md 发布步骤 3、9）
13. 标题层级是否正确，编号是否连续。
14. 交叉引用是否准确、可跳转。
15. 表格分页是否正常，表头孤行是否存在。
16. 图片比例、清晰度、相对位置是否保持，是否存在裁切。
17. 是否存在空白页或明显格式漂移。
18. 目录与正文标题是否一致，页码是否更新。
19. 正文是否有乱码，Markdown 标记是否已正确映射为 Word 样式而非原样残留。

### C. 发布后抽检（对应 docx-preflight.md「发布后抽检」）
20. 随机抽查：封面、目录、每章首尾、含表格页面、含图片页面、分页复杂页面、附件。

### D. 本次模拟输入的重点一致性核对项
21. 招标需求片段中的「7×24 小时安全监测」「30 分钟内首次响应」「每月安全监测分析报告」等要求在正文中的术语与编号是否前后一致。
22. 技术评分片段（方案完整性 5 分、事件响应流程 5 分）对应章节是否齐备、层级清晰。
23. 企业技术资料（资料 A 集中采集/告警归并、资料 B 7×24 值守/平均 20 分钟响应）与方案陈述是否无矛盾、引用完整。

---

## 执行说明

- 是否实际执行了任务而不只是读文件：**是**——已依据 SKILL.md 方法与 docx-preflight.md 清单，实际产出针对模拟输入的「文档发布检查项清单」这一检查记录产物（共 23 项）；按任务约束，本次未生成 DOCX、未安装任何依赖，仅完成检查记录的最小任务。

## 验收边界声明

本检查记录仅代表文档组装与文档质量检查层面的方法执行，不代表资格、商务、报价、人员、业绩、证书等投标附件齐全，也不代表可提交；阶段 9 的 `final_readiness_report.md` 由 Coordinator 另行生成并作最终提交判断。

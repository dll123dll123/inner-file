# 证据 B：运行环境与召唤能力证据

时间：2026-11-20

## 1. 当前会话配置指向

- 环境变量 `WORKBUDDY_CONFIG_DIR` = `C:\Users\h36919\.workbuddy`（真实用户配置，**非**隔离配置 `_isolated_config`）。
- 含义：隔离配置目录 `...\write-skill-wb\_isolated_config` 未被当前运行中的客户端进程加载，其中注册的 `proposal-team` 专家团对当前会话不可见。

## 2. 召唤工具检索结果

通过工具检索查询「召唤专家团 / 新建会话 / 切换专家 / 召唤专家」等能力，返回的工具仅有：
- `skill_management`（列出/禁用已安装 Skill）
- `suggest_plugin_install`（推荐插件/专家候选）
- `search_and_install_skills`（搜索/安装 Skill）

**无任何**可触发产品原生专家团召唤、新建专家会话或切换当前专家的工具。CLI 侧 `codebuddy` / `workbuddy` 命令在本环境不可用。

## 3. 主理人与六成员调用判定

| 项目 | 判定 | 依据 |
|---|---|---|
| 原生专家团召唤 proposal-team-lead | BLOCKED | 无召唤工具；排除 UI 操作后 agent 侧无法触发 |
| 主理人派生 6 个专业成员 | BLOCKED | 依附于原生召唤；按本次执行边界「不得用普通 Agent 派生代替」，故不执行、不伪造 |
| 六成员写文件 / 回传 / 主理人汇总 | BLOCKED | 依附于上述，无实际记录 |

## 4. 已完成部分的可核验性

- 9 个 Skill 手动加载测试使用独立派生上下文，每个产物文件均含证据头（skill_name、SKILL.md 绝对路径、references 列表、模拟输入路径）。
- 主理人对 9 个产物做了独立文件核验：9/9 存在、非空（970–2995 字节）、含证据头，未采信执行体口头回传。

## 5. 边界遵守

- 未修改任何 SKILL.md、references、Agent MD、plugin.json、专家团配置。
- 未修改 PHASE2-001；仅新建独立测试项目 AGENT-RUNTIME-TEST。
- 未安装依赖；未访问真实客户项目或密钥。
- 未用派生产物冒充六个专业成员的工作；未伪造召唤记录。
